Arrow Puzzle - Android Studio project (Kotlin, no external libraries)
Open the folder in Android Studio, wait for Gradle sync, press Run.
