Arrow Puzzle - Android Studio project (Kotlin, no external libraries)
1) Android Studio > Open > select the ArrowPuzzle folder
2) Wait for Gradle sync (it downloads the wrapper automatically) then press Run
