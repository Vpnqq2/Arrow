package com.example.arrowpuzzle

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.widget.TextView

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()

fun Context.pill(text: String, sp: Float = 18f): TextView = TextView(this).apply {
    this.text = text
    setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
    setTextColor(0xFF2B3A67.toInt()); typeface = Typeface.DEFAULT_BOLD
    gravity = Gravity.CENTER
    setPadding(dp(14), dp(8), dp(14), dp(8))
    background = GradientDrawable().apply {
        cornerRadius = dp(14).toFloat(); setColor(0xFFF0F4FA.toInt()); setStroke(dp(1), 0xFFD5DCE8.toInt())
    }
}
