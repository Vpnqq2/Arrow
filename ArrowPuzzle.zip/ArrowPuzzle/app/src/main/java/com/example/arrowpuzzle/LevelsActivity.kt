package com.example.arrowpuzzle

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.GridView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.min

class LevelTile(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var n = 1; private var tileState = 0; private var st = 0

    fun bind(n: Int, unlocked: Int, stars: Int) {
        this.n = n; st = stars
        tileState = when { n < unlocked -> 1; n == unlocked -> 2; else -> 0 }
        background = (if (tileState == 2) GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(C.GRAD1, C.GRAD2))
        else GradientDrawable().apply { setColor(if (tileState == 1) Color.WHITE else 0xFFE3E9F6.toInt()) })
            .apply { cornerRadius = 18 * d }
        elevation = if (tileState == 0) 0f else 3 * d
        invalidate()
    }

    override fun onMeasure(w: Int, h: Int) { val s = MeasureSpec.getSize(w); setMeasuredDimension(s, s) }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f
        p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.DEFAULT_BOLD
        if (tileState == 0) {
            p.color = C.MUTED; p.style = Paint.Style.FILL
            c.drawRoundRect(cx - 12 * d, cy - 2 * d, cx + 12 * d, cy + 16 * d, 4 * d, 4 * d, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 3.5f * d
            c.drawArc(RectF(cx - 8 * d, cy - 16 * d, cx + 8 * d, cy + 6 * d), 180f, 180f, false, p)
            return
        }
        p.color = if (tileState == 2) Color.WHITE else C.INK; p.textSize = 24 * d
        c.drawText("$n", cx, cy + (if (tileState == 1) 2 else 8) * d, p)
        if (tileState == 1) for (i in 0..2) {
            p.color = if (i < st) C.GOLD else 0xFFDDE3F2.toInt()
            c.drawPath(starPath(cx + (i - 1) * 17 * d, cy + 20 * d, 7 * d), p)
        }
    }
}

class LevelsActivity : Activity() {
    private lateinit var prefs: Prefs
    private lateinit var adapter: BaseAdapter

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        styleBars(); prefs = Prefs(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = bgGradient(); setPadding(dp(16), dp(16), dp(16), 0)
        }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val back = IconButton(this, Ic.BACK).apply { setOnClickListener { finish() } }
        top.addView(back, LinearLayout.LayoutParams(dp(48), dp(48)))
        top.addView(TextView(this).apply {
            text = "Select Level"; textSize = 22f; typeface = Typeface.DEFAULT_BOLD; setTextColor(C.INK); gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(0, -2, 1f))
        val (pill, tv) = coinPill(); tv.text = "${prefs.coins}"
        top.addView(pill)
        root.addView(top)

        val grid = GridView(this).apply {
            numColumns = 4; horizontalSpacing = dp(12); verticalSpacing = dp(12)
            stretchMode = GridView.STRETCH_COLUMN_WIDTH; setPadding(dp(4), dp(20), dp(4), dp(20)); clipToPadding = false
            selector = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
        }
        adapter = object : BaseAdapter() {
            override fun getCount() = min(500, maxOf(prefs.unlocked + 12, 40))
            override fun getItem(i: Int) = i + 1
            override fun getItemId(i: Int) = i.toLong()
            override fun getView(i: Int, v: View?, p: ViewGroup?): View {
                val t = (v as? LevelTile) ?: LevelTile(this@LevelsActivity)
                t.bind(i + 1, prefs.unlocked, prefs.stars(i + 1)); return t
            }
        }
        grid.adapter = adapter
        grid.setOnItemClickListener { _, _, i, _ ->
            if (i + 1 <= prefs.unlocked)
                startActivity(Intent(this, GameActivity::class.java).putExtra("level", i + 1))
            else { Sfx.tone(260f, 140f, 160); Toast.makeText(this, "Complete previous levels to unlock", Toast.LENGTH_SHORT).show() }
        }
        root.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    override fun onResume() { super.onResume(); adapter.notifyDataSetChanged() }
}
