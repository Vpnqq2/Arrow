package com.example.arrowpuzzle

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.os.Bundle
import android.view.View
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import kotlin.math.pow

class SplashActivity : Activity() {
    private var started = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = C.INK; window.navigationBarColor = C.INK
        val v = SplashView(this)
        setContentView(v)
        ValueAnimator.ofFloat(0f, 2.5f).apply {
            duration = 2500; interpolator = LinearInterpolator()
            addUpdateListener { v.t = it.animatedValue as Float }
            addListener(object : AnimatorListenerAdapter() { override fun onAnimationEnd(a: Animator) { go() } })
            start()
        }
    }

    private fun go() {
        if (started || isFinishing) return
        started = true
        startActivity(Intent(this, MainActivity::class.java))
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }
}

class SplashView(ctx: Context) : View(ctx) {
    var t = 0f; set(v) { field = v; invalidate() }
    private val d = ctx.resources.displayMetrics.density
    private val logo = BitmapFactory.decodeResource(ctx.resources, R.drawable.logo_white)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val over = OvershootInterpolator(1.6f)

    private fun seg(a: Float, b: Float) = ((t - a) / (b - a)).coerceIn(0f, 1f)
    private fun easeOut(x: Float) = 1f - (1f - x).pow(3)

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        c.drawColor(C.INK)
        val cy = h * .40f
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(w / 2, cy, w * .9f, Color.argb((90 * easeOut(seg(0f, 1f))).toInt(), 70, 90, 150), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p); p.shader = null

        // logo pop-in
        val half = 78 * d
        val sc = .55f + .45f * over.getInterpolation(seg(0f, .8f))
        p.alpha = (255 * seg(0f, .4f)).toInt()
        c.drawBitmap(logo, null, RectF(w / 2 - half * sc, cy - half * sc, w / 2 + half * sc, cy + half * sc), p)
        p.alpha = 255

        // pulse ring
        val k = seg(.5f, 1.5f)
        if (k > 0f && k < 1f) {
            p.style = Paint.Style.STROKE; p.strokeWidth = 2 * d; p.color = Color.argb(((1 - k) * 90).toInt(), 255, 255, 255)
            c.drawCircle(w / 2, cy, half * (1.05f + .9f * easeOut(k)), p)
            p.style = Paint.Style.FILL
        }

        // title
        p.textAlign = Paint.Align.CENTER
        val base = cy + half + 62 * d
        var a = seg(.6f, 1.1f)
        p.typeface = Typeface.create("sans-serif-black", Typeface.NORMAL); p.letterSpacing = .06f; p.textSize = 36 * d
        p.color = Color.WHITE; p.alpha = (255 * a).toInt()
        c.drawText("ARROW", w / 2, base + (1 - easeOut(a)) * 14 * d, p)
        a = seg(.8f, 1.3f)
        p.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL); p.letterSpacing = .16f; p.textSize = 34 * d
        p.color = Color.WHITE; p.alpha = (255 * a).toInt()
        c.drawText("PUZZLE", w / 2, base + 36 * d + (1 - easeOut(a)) * 14 * d, p)
        a = seg(1.1f, 1.7f)
        p.typeface = medium(); p.letterSpacing = .55f - .2f * easeOut(a); p.textSize = 11 * d
        p.color = 0xFFB4BCCF.toInt(); p.alpha = (255 * a).toInt()
        c.drawText("THINK  •  AIM  •  SOLVE", w / 2, base + 64 * d, p)
        p.alpha = 255; p.letterSpacing = 0f

        // loading bar
        val bw = 120 * d; val bh = 3 * d; val by = h - 80 * d
        p.color = 0x33FFFFFF
        c.drawRoundRect(w / 2 - bw / 2, by, w / 2 + bw / 2, by + bh, bh, bh, p)
        p.color = Color.WHITE
        c.drawRoundRect(w / 2 - bw / 2, by, w / 2 - bw / 2 + bw * easeOut(seg(.3f, 2.3f)), by + bh, bh, bh, p)
    }
}
