package com.example.arrowpuzzle

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.animation.OvershootInterpolator
import android.widget.LinearLayout
import android.widget.TextView

object Popup {
    class Btn(val text: String, val primary: Boolean = false, val onClick: () -> Unit = {})

    fun show(act: Activity, title: String, sub: String? = null, stars: Int = -1, content: View? = null,
             cancelable: Boolean = true, buttons: List<Btn>): Dialog {
        val d = Dialog(act)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(act.dp(24), act.dp(26), act.dp(24), act.dp(20))
            background = GradientDrawable().apply { cornerRadius = act.dp(30).toFloat(); setColor(Color.WHITE) }
        }
        box.addView(TextView(act).apply {
            text = title; textSize = 24f; typeface = Typeface.DEFAULT_BOLD; setTextColor(C.INK); gravity = Gravity.CENTER
        })
        if (stars >= 0) box.addView(StarsView(act, stars), LinearLayout.LayoutParams(-2, -2).apply { topMargin = act.dp(10) })
        if (sub != null) box.addView(TextView(act).apply {
            text = sub; textSize = 15f; setTextColor(C.MUTED); gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = act.dp(8) })
        if (content != null) box.addView(content, LinearLayout.LayoutParams(-1, -2).apply { topMargin = act.dp(10) })
        for (b in buttons) {
            val v = if (b.primary) act.gradBtn(b.text, C.BLUE, C.VIOLET, 17f) else act.softBtn(b.text, 15f)
            v.setOnClickListener { Sfx.tone(700f, 700f, 40); d.dismiss(); b.onClick() }
            box.addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = act.dp(12) })
        }
        d.setContentView(box); d.setCancelable(cancelable)
        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        box.scaleX = .8f; box.scaleY = .8f; box.alpha = 0f
        d.show()
        d.window?.setLayout(act.dp(320), ViewGroup.LayoutParams.WRAP_CONTENT)
        box.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(260).setInterpolator(OvershootInterpolator(1.4f)).start()
        return d
    }
}
