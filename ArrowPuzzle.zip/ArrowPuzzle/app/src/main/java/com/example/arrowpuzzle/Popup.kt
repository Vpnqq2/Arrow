package com.example.arrowpuzzle

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.animation.OvershootInterpolator
import android.widget.LinearLayout
import android.widget.TextView

object Popup {
    class Btn(val text: String, val primary: Boolean = false, val icon: Ic? = null, val onClick: () -> Unit = {})

    fun show(act: Activity, title: String, sub: String? = null, stars: Int = -1, icon: Ic? = null,
             content: View? = null, cancelable: Boolean = true, buttons: List<Btn>): Dialog {
        val d = Dialog(act)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(act.dp(24), act.dp(24), act.dp(24), act.dp(22))
            background = GradientDrawable().apply { cornerRadius = act.dp(26).toFloat(); setColor(Color.WHITE) }
        }
        if (icon != null) {
            val ic = IconView(act, icon, Color.WHITE, 26f).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(C.INK) }
            }
            box.addView(ic, LinearLayout.LayoutParams(act.dp(60), act.dp(60)))
        }
        box.addView(TextView(act).apply {
            text = title; textSize = 26f; typeface = medium(); setTextColor(C.INK); gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = act.dp(if (icon != null) 12 else 0) })
        if (stars >= 0) box.addView(StarsView(act, stars), LinearLayout.LayoutParams(-2, -2).apply { topMargin = act.dp(8) })
        if (sub != null) box.addView(TextView(act).apply {
            text = sub; textSize = 15f; setTextColor(C.MUTED); gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = act.dp(6) })
        if (content != null) box.addView(content, LinearLayout.LayoutParams(-1, -2).apply { topMargin = act.dp(12) })
        for (b in buttons) {
            val v = RowBtn(act, b.icon, b.text, null, if (b.primary) BtnStyle.DARK else BtnStyle.CARD,
                divider = b.icon != null, center = b.icon == null, titleSp = 17f, radiusDp = 16, iconDp = 20f, minHDp = 48, cellDp = 36)
            v.setOnClickListener { Sfx.tone(700f, 700f, 40); d.dismiss(); b.onClick() }
            box.addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = act.dp(12) })
        }
        d.setContentView(box); d.setCancelable(cancelable)
        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        box.scaleX = .85f; box.scaleY = .85f; box.alpha = 0f
        d.show()
        d.window?.setLayout(act.dp(285), ViewGroup.LayoutParams.WRAP_CONTENT)
        d.window?.setDimAmount(0.45f)
        box.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(260).setInterpolator(OvershootInterpolator(1.4f)).start()
        return d
    }
}
