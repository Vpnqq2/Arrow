package com.example.arrowpuzzle

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

object C {
    val INK = 0xFF1E2A4A.toInt(); val MUTED = 0xFF8A94B0.toInt()
    val BG1 = 0xFFF5F8FF.toInt(); val BG2 = 0xFFE9F0FE.toInt()
    val GRAD1 = 0xFF3D8BFF.toInt(); val GRAD2 = 0xFFAA4DFF.toInt()
    val BLUE = 0xFF2F7BFF.toInt(); val VIOLET = 0xFF8A5CFF.toInt()
    val GREEN = 0xFF1CC57A.toInt(); val RED = 0xFFFF4D5E.toInt()
    val GOLD = 0xFFFFC93C.toInt(); val AMBER = 0xFFFDB92E.toInt()
    val PALETTE = intArrayOf(0xFF1E2A4A.toInt(), 0xFF2F7BFF.toInt(), 0xFFFF4D5E.toInt(),
        0xFF10C99B.toInt(), 0xFFA855F7.toInt(), 0xFFFFB300.toInt())
}

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()
fun medium(): Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
fun bgGradient() = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(C.BG1, C.BG2))

fun View.pressable() {
    setOnTouchListener { v, e ->
        when (e.action) {
            MotionEvent.ACTION_DOWN -> v.animate().scaleX(.95f).scaleY(.95f).setDuration(80).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
        }
        false
    }
}

fun Context.coinPill(onPlus: (() -> Unit)? = null): Pair<View, TextView> {
    val tv = TextView(this).apply { setTextColor(C.INK); typeface = medium(); setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f) }
    val row = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(6), dp(5), dp(if (onPlus != null) 5 else 16), dp(5))
        background = GradientDrawable().apply { cornerRadius = dp(40).toFloat(); setColor(Color.WHITE) }
        elevation = dp(3).toFloat()
    }
    row.addView(CoinView(this), LinearLayout.LayoutParams(dp(24), dp(24)))
    row.addView(tv, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(10); rightMargin = dp(if (onPlus != null) 14 else 0) })
    if (onPlus != null) {
        val plus = IconView(this, Ic.PLUS, Color.WHITE, 12f).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(C.GREEN) }
            setOnClickListener { onPlus() }; pressable()
        }
        row.addView(plus, LinearLayout.LayoutParams(dp(24), dp(24)))
    }
    return Pair(row, tv)
}

fun Activity.styleBars() {
    window.statusBarColor = C.BG1; window.navigationBarColor = C.BG2
    var f = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
    if (Build.VERSION.SDK_INT >= 26) f = f or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
    window.decorView.systemUiVisibility = f
}
