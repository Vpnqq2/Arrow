package com.example.arrowpuzzle

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

object C {
    val INK = 0xFF1F2A44.toInt(); val MUTED = 0xFF7A86A6.toInt()
    val BG1 = 0xFFF4F7FF.toInt(); val BG2 = 0xFFD8E3FF.toInt()
    val BLUE = 0xFF4F7CFF.toInt(); val VIOLET = 0xFF8A5CFF.toInt()
    val GREEN = 0xFF2ECC9A.toInt(); val RED = 0xFFFF5470.toInt()
    val GOLD = 0xFFFFC93C.toInt(); val ORANGE = 0xFFFF8A3C.toInt()
    val PALETTE = intArrayOf(0xFF1F2A44.toInt(), 0xFF4F7CFF.toInt(), 0xFFFF6B6B.toInt(),
        0xFF2ECC9A.toInt(), 0xFFFFA630.toInt(), 0xFF9B5DE5.toInt())
}

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()

fun bgGradient() = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(C.BG1, C.BG2))

fun View.pressable() {
    setOnTouchListener { v, e ->
        when (e.action) {
            MotionEvent.ACTION_DOWN -> v.animate().scaleX(.94f).scaleY(.94f).setDuration(80).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
        }
        false
    }
}

fun Context.gradBtn(text: String, c1: Int, c2: Int, sp: Float = 18f): TextView = TextView(this).apply {
    this.text = text
    setTextSize(TypedValue.COMPLEX_UNIT_SP, sp); setTextColor(Color.WHITE)
    typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; letterSpacing = 0.05f
    setPadding(dp(20), dp(15), dp(20), dp(15))
    background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(c1, c2)).apply { cornerRadius = dp(20).toFloat() }
    elevation = dp(6).toFloat(); pressable()
}

fun Context.softBtn(text: String, sp: Float = 16f): TextView = TextView(this).apply {
    this.text = text
    setTextSize(TypedValue.COMPLEX_UNIT_SP, sp); setTextColor(C.INK)
    typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
    setPadding(dp(16), dp(14), dp(16), dp(14))
    background = GradientDrawable().apply { cornerRadius = dp(20).toFloat(); setColor(Color.WHITE); setStroke(dp(1), 0xFFD5DCE8.toInt()) }
    elevation = dp(3).toFloat(); pressable()
}

fun Context.coinPill(): Pair<View, TextView> {
    val tv = TextView(this).apply { setTextColor(C.INK); typeface = Typeface.DEFAULT_BOLD; setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f) }
    val row = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), dp(7), dp(14), dp(7))
        background = GradientDrawable().apply { cornerRadius = dp(18).toFloat(); setColor(Color.WHITE) }
        elevation = dp(3).toFloat()
    }
    val coin = View(this).apply {
        background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(C.GOLD, 0xFFFFA000.toInt())).apply { shape = GradientDrawable.OVAL }
    }
    row.addView(coin, LinearLayout.LayoutParams(dp(20), dp(20)).apply { rightMargin = dp(6) })
    row.addView(tv)
    return Pair(row, tv)
}

fun Activity.styleBars() {
    window.statusBarColor = C.BG1; window.navigationBarColor = C.BG2
    var f = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
    if (Build.VERSION.SDK_INT >= 26) f = f or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
    window.decorView.systemUiVisibility = f
}
