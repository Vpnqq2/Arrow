package com.example.arrowpuzzle

import android.app.Activity
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView

/** Monochrome navy theme - the navy is the same colour as the arrows. */
object C {
    val INK = 0xFF1E2A4A.toInt(); val INK2 = 0xFF2B3759.toInt()
    val MUTED = 0xFF7C8598.toInt(); val LINE = 0xFFE4E8EF.toInt()
    val BG1 = 0xFFF7F9FC.toInt(); val BG2 = 0xFFEDF0F5.toInt()
    val RED = 0xFFFF4D5E.toInt(); val GOLD = 0xFFFFC93C.toInt(); val HINT = 0xFFFFB300.toInt()
    val BLUE = 0xFF2F7BFF.toInt()
    val PALETTE = intArrayOf(0xFF1E2A4A.toInt(), 0xFFFFC93C.toInt(), 0xFFFF4D5E.toInt(), 0xFF8A94B0.toInt(), 0xFF2F7BFF.toInt())
}

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()
fun medium(): Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
fun bgGradient() = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(C.BG1, C.BG2))

/** Flat surface: no shadow, just a hairline border. */
fun Context.surface(radiusDp: Int, fill: Int = Color.WHITE) = GradientDrawable().apply {
    cornerRadius = dp(radiusDp).toFloat(); setColor(fill); setStroke(maxOf(1, dp(1)), C.LINE)
}

fun View.pressable() {
    setOnTouchListener { v, e ->
        when (e.action) {
            MotionEvent.ACTION_DOWN -> v.animate().scaleX(.96f).scaleY(.96f).setDuration(80).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
        }
        false
    }
}

fun Context.coinPill(onPlus: (() -> Unit)? = null): Pair<View, TextView> {
    val tv = TextView(this).apply { setTextColor(Color.WHITE); typeface = medium(); setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f) }
    val row = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(5), dp(5), dp(if (onPlus != null) 5 else 16), dp(5))
        background = GradientDrawable().apply { cornerRadius = dp(40).toFloat(); setColor(C.INK); setStroke(dp(2), Color.WHITE) }
    }
    val star = IconView(this, Ic.STAR, C.INK, 15f).apply {
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE) }
    }
    row.addView(star, LinearLayout.LayoutParams(dp(28), dp(28)))
    row.addView(View(this).apply { setBackgroundColor(0x44FFFFFF) },
        LinearLayout.LayoutParams(maxOf(1, dp(1)), dp(18)).apply { setMargins(dp(10), 0, dp(10), 0) })
    row.addView(tv, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(if (onPlus != null) 14 else 0) })
    if (onPlus != null) {
        val plus = IconView(this, Ic.PLUS, C.INK, 12f).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE) }
            setOnClickListener { onPlus() }; pressable()
        }
        row.addView(plus, LinearLayout.LayoutParams(dp(28), dp(28)))
    }
    return Pair(row, tv)
}

fun Context.styleSwitch(sw: Switch) {
    val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
    sw.thumbTintList = ColorStateList(states, intArrayOf(C.INK, 0xFFB6BDCC.toInt()))
    sw.trackTintList = ColorStateList(states, intArrayOf(0x661E2A4A, 0x33B6BDCC))
}

fun Activity.styleBars() {
    window.statusBarColor = C.BG1; window.navigationBarColor = C.BG2
    var f = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
    if (Build.VERSION.SDK_INT >= 26) f = f or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
    window.decorView.systemUiVisibility = f
}
