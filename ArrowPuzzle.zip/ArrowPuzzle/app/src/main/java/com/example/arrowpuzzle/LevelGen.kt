package com.example.arrowpuzzle

import kotlin.math.*
import kotlin.random.Random

/** dir: 0=up 1=right 2=down 3=left. cells: tail -> head */
class Arrow(val cells: List<Pair<Int, Int>>, val dir: Int)
class Level(val w: Int, val h: Int, val arrows: List<Arrow>, val mask: Array<BooleanArray>)

/**
 * Levels are geometric shapes (arrow, heart, ring, ...) completely filled with long winding arrows that
 * hug each other. Each candidate is checked by "peeling" (always solvable) and the hardest of several
 * candidates (deepest dependency chain, fewest arrows free at the start) is kept.
 */
object LevelGen {
    val DX = intArrayOf(0, 1, 0, -1)
    val DY = intArrayOf(-1, 0, 1, 0)
    private val SHAPES = listOf("arrow", "heart", "diamond", "circle", "house", "cross", "triangle", "ring", "hexagon", "octagon")

    fun make(seed: Long, n: Int, shapeIdx: Int = n - 1): Level {
        val tries = if (n < 3) 4 else if (n < 40) 40 else 24
        var best: Level? = null; var bs = -1e9
        for (k in 0 until tries) {
            val (lv, sc) = attempt(seed + k * 101L, n, shapeIdx)
            if (best == null || sc > bs) { bs = sc; best = lv }
        }
        return best!!
    }

    private fun maskOf(name: String, w: Int, h: Int): Array<BooleanArray> = Array(h) { y ->
        BooleanArray(w) { x ->
            val u = (x + .5) / w * 2 - 1; val v = (y + .5) / h * 2 - 1; val r = hypot(u, v)
            when (name) {
                "diamond" -> abs(u) + abs(v) <= 1
                "circle" -> r <= 1
                "ring" -> r >= .38 && r <= 1
                "cross" -> abs(u) <= .36 || abs(v) <= .36
                "triangle" -> abs(u) <= (v + 1) / 2
                "hexagon" -> abs(u) * .5 + abs(v) * .866 <= .866 && abs(u) <= 1
                "octagon" -> abs(u) + abs(v) <= 1.45
                "arrow" -> (v <= .05 && abs(u) <= (v + 1) / 1.05) || (v > .05 && abs(u) <= .4)
                "house" -> (v < -.1 && abs(u) <= (v + 1) * 1.1 / .9) || (v >= -.1 && abs(u) <= .78)
                "heart" -> { val x1 = u * 1.25; val y1 = -v * 1.25 + .1; (x1 * x1 + y1 * y1 - 1).pow(3) - x1 * x1 * y1.pow(3) <= 0 }
                else -> true
            }
        }
    }

    private fun attempt(seed: Long, n: Int, shapeIdx: Int): Pair<Level, Double> {
        val rnd = Random(seed)
        val size = min(20, 6 + n / 5); val w = size; val h = (size * 1.25).toInt()
        val shape = SHAPES[((shapeIdx % SHAPES.size) + SHAPES.size) % SHAPES.size]
        val mask = maskOf(shape, w, h)
        val maxL = min(40, 3 + n); val minL = max(2, maxL / 3)
        val paths = tile(mask, w, h, rnd, minL, maxL)
        var orient: IntArray
        var guard = 0
        while (true) {
            val res = peel(paths, w, h, rnd)
            orient = res.first
            val stuck = res.second
            if (stuck.isEmpty()) break
            guard++
            val longs = stuck.filter { paths[it].size >= 4 }
            if (longs.isNotEmpty() && guard < 400) {
                val i = longs[rnd.nextInt(longs.size)]; val p = paths[i]
                val k = 2 + rnd.nextInt(p.size - 3)
                paths[i] = p.subList(0, k).toList(); paths.add(p.subList(k, p.size).toList())
            } else {
                val i = stuck[rnd.nextInt(stuck.size)]
                for (c in paths[i]) mask[c / w][c % w] = false
                paths.removeAt(i); orient = IntArray(0)
                if (paths.isEmpty()) break
            }
        }
        if (paths.isEmpty() || orient.size != paths.size) return Pair(Level(w, h, emptyList(), mask), -1e9)
        val fin = paths.mapIndexed { i, p -> if (orient[i] == 0) p else p.reversed() }

        // hardness metrics: rounds of simultaneous removal, arrows free at the start
        val occ = IntArray(w * h) { -1 }
        fin.forEachIndexed { i, p -> p.forEach { occ[it] = i } }
        val rem = BooleanArray(fin.size) { true }
        var left = fin.size; var rounds = 0; var first = 0
        while (left > 0) {
            val fr = (0 until fin.size).filter { rem[it] && rayFree(fin[it], 0, occ, it, w, h) }
            if (fr.isEmpty()) break
            if (rounds == 0) first = fr.size
            for (i in fr) { for (c in fin[i]) occ[c] = -1; rem[i] = false; left-- }
            rounds++
        }
        val arrows = fin.map { p ->
            val a = p[p.size - 2]; val b = p[p.size - 1]
            val dx = b % w - a % w; val dy = b / w - a / w
            val dir = when { dy < 0 -> 0; dx > 0 -> 1; dy > 0 -> 2; else -> 3 }
            Arrow(p.map { Pair(it % w, it / w) }, dir)
        }
        return Pair(Level(w, h, arrows, mask), rounds * 4.0 - first * 2.0 + arrows.size * 0.2)
    }

    private fun tile(mask: Array<BooleanArray>, w: Int, h: Int, rnd: Random, minL: Int, maxL: Int): MutableList<List<Int>> {
        val free = BooleanArray(w * h)
        var count = 0
        for (y in 0 until h) for (x in 0 until w) if (mask[y][x]) { free[y * w + x] = true; count++ }
        fun nf(c: Int): Int {
            var k = 0
            for (d in 0..3) {
                val nx = c % w + DX[d]; val ny = c / w + DY[d]
                if (nx in 0 until w && ny in 0 until h && free[ny * w + nx]) k++
            }
            return k
        }
        val paths = ArrayList<MutableList<Int>>()
        while (count > 0) {
            var start = -1; var bk = Int.MAX_VALUE
            for (c in 0 until w * h) if (free[c]) {
                val k = nf(c) * 1000 + rnd.nextInt(1000)
                if (k < bk) { bk = k; start = c }
            }
            val path = arrayListOf(start); free[start] = false; count--
            val target = minL + rnd.nextInt(maxL - minL + 1)
            var last = -1
            while (path.size < target) {
                val cur = path[path.size - 1]
                val opts = ArrayList<Int>()
                for (d in 0..3) {
                    val nx = cur % w + DX[d]; val ny = cur / w + DY[d]
                    if (nx in 0 until w && ny in 0 until h && free[ny * w + nx]) opts.add(d)
                }
                if (opts.isEmpty()) break
                val d: Int = if (last in opts && rnd.nextFloat() < .5f) last else {
                    if (rnd.nextFloat() < .75f)
                        opts.minByOrNull { dd -> nf((cur / w + DY[dd]) * w + cur % w + DX[dd]) * 1000 + rnd.nextInt(1000) }!!
                    else opts[rnd.nextInt(opts.size)]
                }
                last = d
                val nxt = (cur / w + DY[d]) * w + cur % w + DX[d]
                path.add(nxt); free[nxt] = false; count--
            }
            paths.add(path)
        }
        val out = ArrayList<MutableList<Int>>()
        val singles = ArrayList<Int>()
        for (p in paths) if (p.size == 1) singles.add(p[0]) else out.add(p)
        for (c in singles) {
            var done = false
            for (p in out) {
                if (abs(p[p.size - 1] % w - c % w) + abs(p[p.size - 1] / w - c / w) == 1) { p.add(c); done = true; break }
                if (abs(p[0] % w - c % w) + abs(p[0] / w - c / w) == 1) { p.add(0, c); done = true; break }
            }
            if (!done) mask[c / w][c % w] = false
        }
        return out.map { it.toList() }.toMutableList()
    }

    private fun rayFree(p: List<Int>, orient: Int, occ: IntArray, me: Int, w: Int, h: Int): Boolean {
        val b = if (orient == 0) p[p.size - 1] else p[0]
        val a = if (orient == 0) p[p.size - 2] else p[1]
        val dx = b % w - a % w; val dy = b / w - a / w
        var x = b % w + dx; var y = b / w + dy
        while (x in 0 until w && y in 0 until h) {
            val o = occ[y * w + x]
            if (o != -1 && o != me) return false
            x += dx; y += dy
        }
        return true
    }

    /** Removes arrows one by one, choosing head ends that start blocked, so the puzzle has deep dependencies. */
    private fun peel(paths: List<List<Int>>, w: Int, h: Int, rnd: Random): Pair<IntArray, List<Int>> {
        val n = paths.size
        val occ = IntArray(w * h) { -1 }
        paths.forEachIndexed { i, p -> p.forEach { occ[it] = i } }
        val blocked0 = Array(n) { i -> BooleanArray(2) { o -> !rayFree(paths[i], o, occ, i, w, h) } }
        val rem = BooleanArray(n) { true }
        val orient = IntArray(n)
        var left = n
        while (left > 0) {
            val cand = ArrayList<Int>()
            for (i in 0 until n) if (rem[i]) for (o in 0..1) if (rayFree(paths[i], o, occ, i, w, h)) cand.add(i * 2 + o)
            if (cand.isEmpty()) break
            val pref = cand.filter { blocked0[it / 2][it % 2] }
            val pool = if (pref.isNotEmpty()) pref else cand
            val pick = pool[rnd.nextInt(pool.size)]
            val i = pick / 2
            for (c in paths[i]) occ[c] = -1
            rem[i] = false; orient[i] = pick % 2; left--
        }
        return Pair(orient, (0 until n).filter { rem[it] })
    }
}
