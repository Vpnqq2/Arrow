package com.example.arrowpuzzle

import kotlin.random.Random

/** dir: 0=up 1=right 2=down 3=left. cells: tail -> head */
class Arrow(val cells: List<Pair<Int, Int>>, val dir: Int)
class Level(val w: Int, val h: Int, val arrows: List<Arrow>)

object LevelGen {
    val DX = intArrayOf(0, 1, 0, -1)
    val DY = intArrayOf(-1, 0, 1, 0)

    /**
     * Every arrow is placed only if its exit ray is free at placement time,
     * so removing arrows in reverse placement order always solves the level.
     */
    fun make(seed: Long, difficulty: Int): Level {
        val w = (4 + difficulty / 7).coerceAtMost(10)
        val h = (w * 1.4).toInt()
        val maxLen = (3 + difficulty / 6).coerceAtMost(10)
        val rnd = Random(seed)
        val occ = Array(h) { BooleanArray(w) }
        val list = ArrayList<Arrow>()
        repeat(w * h * 25) {
            val sx = rnd.nextInt(w); val sy = rnd.nextInt(h)
            if (occ[sy][sx]) return@repeat
            val cells = arrayListOf(Pair(sx, sy))
            val target = 2 + rnd.nextInt(maxLen - 1)
            var dir = -1
            while (cells.size < target) {
                val (cx, cy) = cells.last()
                val opts = (0..3).filter { d ->
                    val nx = cx + DX[d]; val ny = cy + DY[d]
                    nx in 0 until w && ny in 0 until h && !occ[ny][nx] && Pair(nx, ny) !in cells
                }.shuffled(rnd)
                if (opts.isEmpty()) break
                dir = if (dir in opts && rnd.nextFloat() < 0.6f) dir else opts[0]
                cells.add(Pair(cx + DX[dir], cy + DY[dir]))
            }
            if (cells.size < 2) return@repeat
            val (hx, hy) = cells.last()
            var x = hx + DX[dir]; var y = hy + DY[dir]
            var free = true
            while (x in 0 until w && y in 0 until h) {
                if (occ[y][x] || Pair(x, y) in cells) { free = false; break }
                x += DX[dir]; y += DY[dir]
            }
            if (!free) return@repeat
            cells.forEach { occ[it.second][it.first] = true }
            list.add(Arrow(cells, dir))
        }
        return Level(w, h, list)
    }
}
