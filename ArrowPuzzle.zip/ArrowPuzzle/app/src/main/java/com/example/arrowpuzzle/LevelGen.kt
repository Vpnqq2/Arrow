package com.example.arrowpuzzle

import kotlin.math.*
import kotlin.random.Random

/** dir: 0=up 1=right 2=down 3=left. cells: tail -> head */
class Arrow(val cells: List<Pair<Int, Int>>, val dir: Int)
class Level(val w: Int, val h: Int, val arrows: List<Arrow>, val mask: Array<BooleanArray>)

/**
 * Levels are geometric shapes (arrow, heart, ring, ...) completely filled with rectilinear arrows
 * (long straight runs, staircases, coils) that hug each other.
 * Rules guaranteed by the generator:
 *  - an arrow's exit ray never crosses its own body;
 *  - every level is solvable (checked by peeling arrows one by one);
 *  - among several candidates the hardest is kept (deepest dependency chain, fewest arrows free at start).
 */
object LevelGen {
    val DX = intArrayOf(0, 1, 0, -1)
    val DY = intArrayOf(-1, 0, 1, 0)
    private val SHAPES = listOf("arrow", "heart", "diamond", "circle", "house", "cross", "triangle", "ring", "hexagon", "octagon")

    fun make(seed: Long, n: Int, shapeIdx: Int = n - 1): Level {
        val tries = if (n < 3) 6 else if (n < 30) 30 else if (n < 60) 18 else 12
        var best: Level? = null; var bs = -1e9
        for (k in 0 until tries) {
            val (lv, sc) = attempt(seed + k * 101L, n, shapeIdx)
            if (best == null || sc > bs) { bs = sc; best = lv }
        }
        return best!!
    }

    private fun maskOf(name: String, w: Int, h: Int): Array<BooleanArray> = Array(h) { y ->
        BooleanArray(w) { x ->
            val u = (x + .5) / w * 2 - 1; val v = (y + .5) / h * 2 - 1; val r = hypot(u, v)
            when (name) {
                "diamond" -> abs(u) + abs(v) <= 1
                "circle" -> r <= 1
                "ring" -> r >= .38 && r <= 1
                "cross" -> abs(u) <= .36 || abs(v) <= .36
                "triangle" -> abs(u) <= (v + 1) / 2
                "hexagon" -> abs(u) * .5 + abs(v) * .866 <= .866 && abs(u) <= 1
                "octagon" -> abs(u) + abs(v) <= 1.45
                "arrow" -> (v <= .05 && abs(u) <= (v + 1) / 1.05) || (v > .05 && abs(u) <= .4)
                "house" -> (v < -.1 && abs(u) <= (v + 1) * 1.1 / .9) || (v >= -.1 && abs(u) <= .78)
                "heart" -> { val x1 = u * 1.25; val y1 = -v * 1.25 + .1; (x1 * x1 + y1 * y1 - 1).pow(3) - x1 * x1 * y1.pow(3) <= 0 }
                else -> true
            }
        }
    }

    private fun attempt(seed: Long, n: Int, shapeIdx: Int): Pair<Level, Double> {
        val rnd = Random(seed)
        val size = min(22, 5 + n * 2 / 5); val w = size; val h = (size * 1.25).toInt()
        val shape = SHAPES[((shapeIdx % SHAPES.size) + SHAPES.size) % SHAPES.size]
        val mask = maskOf(shape, w, h)
        val maxL = min(18, 4 + n / 3); val minL = 3
        val runMax = min(12, 3 + n / 5)
        val paths = tile(mask, w, h, rnd, minL, maxL, runMax)
        var orient: IntArray
        var guard = 0
        while (true) {
            val res = peel(paths, w, h, rnd)
            orient = res.first
            val stuck = res.second
            if (stuck.isEmpty()) break
            guard++
            val longs = stuck.filter { paths[it].size >= 4 }
            if (longs.isNotEmpty() && guard < 400) {
                val i = longs[rnd.nextInt(longs.size)]; val p = paths[i]
                val k = 2 + rnd.nextInt(p.size - 3)
                paths[i] = p.subList(0, k).toList(); paths.add(p.subList(k, p.size).toList())
            } else {
                val i = stuck[rnd.nextInt(stuck.size)]
                for (c in paths[i]) mask[c / w][c % w] = false
                paths.removeAt(i); orient = IntArray(0)
                if (paths.isEmpty()) break
            }
        }
        if (paths.isEmpty() || orient.size != paths.size) return Pair(Level(w, h, emptyList(), mask), -1e9)
        val fin = paths.mapIndexed { i, p -> if (orient[i] == 0) p else p.reversed() }

        // hardness metrics: rounds of simultaneous removal, arrows free at the start
        val occ = IntArray(w * h) { -1 }
        fin.forEachIndexed { i, p -> p.forEach { occ[it] = i } }
        val rem = BooleanArray(fin.size) { true }
        var left = fin.size; var rounds = 0; var first = 0
        while (left > 0) {
            val fr = (0 until fin.size).filter { rem[it] && rayFree(fin[it], 0, occ, w, h) }
            if (fr.isEmpty()) break
            if (rounds == 0) first = fr.size
            for (i in fr) { for (c in fin[i]) occ[c] = -1; rem[i] = false; left-- }
            rounds++
        }
        if (left > 0) return Pair(Level(w, h, emptyList(), mask), -1e9)
        val arrows = fin.map { p ->
            val a = p[p.size - 2]; val b = p[p.size - 1]
            val dx = b % w - a % w; val dy = b / w - a / w
            val dir = when { dy < 0 -> 0; dx > 0 -> 1; dy > 0 -> 2; else -> 3 }
            Arrow(p.map { Pair(it % w, it / w) }, dir)
        }
        return Pair(Level(w, h, arrows, mask), rounds * 4.0 - first * 5.0 + arrows.size * 0.1)
    }

    /** Rectilinear tiling: runs of straight cells joined by right-angle turns (stairs, coils, free). */
    private fun tile(mask: Array<BooleanArray>, w: Int, h: Int, rnd: Random, minL: Int, maxL: Int, runMax: Int): MutableList<List<Int>> {
        val free = Array(h) { y -> BooleanArray(w) { x -> mask[y][x] } }
        fun isFree(x: Int, y: Int) = x in 0 until w && y in 0 until h && free[y][x]
        fun nf(x: Int, y: Int): Int { var k = 0; for (d in 0..3) if (isFree(x + DX[d], y + DY[d])) k++; return k }
        var cnt = 0
        for (y in 0 until h) for (x in 0 until w) if (free[y][x]) cnt++
        val paths = ArrayList<MutableList<Int>>()
        while (cnt > 0) {
            var sx = -1; var sy = -1; var bk = Int.MAX_VALUE
            for (y in 0 until h) for (x in 0 until w) if (free[y][x]) {
                val k = nf(x, y) * 1000 + rnd.nextInt(1000)
                if (k < bk) { bk = k; sx = x; sy = y }
            }
            val path = arrayListOf(sy * w + sx); free[sy][sx] = false; cnt--
            val target = minL + rnd.nextInt(maxL - minL + 1)
            val opts = (0..3).filter { isFree(sx + DX[it], sy + DY[it]) }
            if (opts.isNotEmpty()) {
                fun run(d: Int): Int {
                    var k = 0; var x = sx; var y = sy
                    while (isFree(x + DX[d], y + DY[d])) { x += DX[d]; y += DY[d]; k++ }
                    return k
                }
                var d = opts.maxByOrNull { run(it) + rnd.nextFloat() * 3 }!!
                val style = intArrayOf(0, 1, 1, 2)[rnd.nextInt(4)] // 0 staircase, 1 coil, 2 free
                val tp = if (rnd.nextBoolean()) 1 else 3
                var r = 2 + rnd.nextInt(runMax - 1)
                var flip = tp
                var x = sx; var y = sy
                while (path.size < target) {
                    var steps = 0
                    while (steps < r && path.size < target && isFree(x + DX[d], y + DY[d])) {
                        x += DX[d]; y += DY[d]; path.add(y * w + x); free[y][x] = false; cnt--; steps++
                    }
                    if (path.size >= target) break
                    val tc = intArrayOf(1, 3).filter { isFree(x + DX[(d + it) % 4], y + DY[(d + it) % 4]) }
                    if (tc.isEmpty()) break
                    val t = when (style) {
                        0 -> { flip = 4 - flip; if (flip in tc) flip else tc[0] }
                        1 -> if (tp in tc) tp else tc[0]
                        else -> tc.minByOrNull { tt -> nf(x + DX[(d + tt) % 4], y + DY[(d + tt) % 4]) * 1000 + rnd.nextInt(1000) }!!
                    }
                    d = (d + t) % 4
                    if (style != 0) r = 1 + rnd.nextInt(runMax)
                }
            }
            paths.add(path)
        }
        val out = ArrayList<MutableList<Int>>()
        val singles = ArrayList<Int>()
        for (p in paths) if (p.size == 1) singles.add(p[0]) else out.add(p)
        for (c in singles) {
            var done = false
            for (p in out) {
                if (abs(p[p.size - 1] % w - c % w) + abs(p[p.size - 1] / w - c / w) == 1) { p.add(c); done = true; break }
                if (abs(p[0] % w - c % w) + abs(p[0] / w - c / w) == 1) { p.add(0, c); done = true; break }
            }
            if (!done) mask[c / w][c % w] = false
        }
        return out.map { it.toList() }.toMutableList()
    }

    /** Free only if NO cell (not even the arrow's own body) lies on the exit ray. */
    private fun rayFree(p: List<Int>, orient: Int, occ: IntArray, w: Int, h: Int): Boolean {
        val b = if (orient == 0) p[p.size - 1] else p[0]
        val a = if (orient == 0) p[p.size - 2] else p[1]
        val dx = b % w - a % w; val dy = b / w - a / w
        var x = b % w + dx; var y = b / w + dy
        while (x in 0 until w && y in 0 until h) {
            if (occ[y * w + x] != -1) return false
            x += dx; y += dy
        }
        return true
    }

    /** Removes arrows one by one, choosing head ends that start blocked, so the puzzle has deep dependencies. */
    private fun peel(paths: List<List<Int>>, w: Int, h: Int, rnd: Random): Pair<IntArray, List<Int>> {
        val n = paths.size
        val occ = IntArray(w * h) { -1 }
        paths.forEachIndexed { i, p -> p.forEach { occ[it] = i } }
        val blocked0 = Array(n) { i -> BooleanArray(2) { o -> !rayFree(paths[i], o, occ, w, h) } }
        val rem = BooleanArray(n) { true }
        val orient = IntArray(n)
        var left = n
        while (left > 0) {
            val cand = ArrayList<Int>()
            for (i in 0 until n) if (rem[i]) for (o in 0..1) if (rayFree(paths[i], o, occ, w, h)) cand.add(i * 2 + o)
            if (cand.isEmpty()) break
            val pref = cand.filter { blocked0[it / 2][it % 2] }
            val pool = if (pref.isNotEmpty()) pref else cand
            val pick = pool[rnd.nextInt(pool.size)]
            val i = pick / 2
            for (c in paths[i]) occ[c] = -1
            rem[i] = false; orient[i] = pick % 2; left--
        }
        return Pair(orient, (0 until n).filter { rem[it] })
    }
}
