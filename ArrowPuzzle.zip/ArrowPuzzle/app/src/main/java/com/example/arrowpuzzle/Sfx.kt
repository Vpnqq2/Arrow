package com.example.arrowpuzzle

import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/** Tiny synthesized sound effects - no audio assets needed. */
object Sfx {
    var enabled = true
    private const val RATE = 44100
    private val cache = HashMap<String, ShortArray>()

    private fun gen(f0: Float, f1: Float, ms: Int): ShortArray {
        val n = RATE * ms / 1000
        val s = ShortArray(n)
        var ph = 0.0
        for (i in 0 until n) {
            val t = i / n.toFloat()
            ph += 2 * PI * (f0 + (f1 - f0) * t) / RATE
            val env = (1f - t).pow(1.6f) * min(1f, i / 150f)
            s[i] = (sin(ph) * env * 11000).toInt().toShort()
        }
        return s
    }

    fun tone(f0: Float, f1: Float, ms: Int) = play("$f0-$f1-$ms") { gen(f0, f1, ms) }
    fun win() = play("win") { gen(523f, 523f, 110) + gen(659f, 659f, 110) + gen(784f, 784f, 110) + gen(1046f, 1046f, 380) }

    private fun play(key: String, make: () -> ShortArray) {
        if (!enabled) return
        val d = synchronized(cache) { cache.getOrPut(key, make) }
        Thread {
            try {
                @Suppress("DEPRECATION")
                val at = AudioTrack(AudioManager.STREAM_MUSIC, RATE, AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, d.size * 2, AudioTrack.MODE_STATIC)
                at.write(d, 0, d.size); at.play()
                Thread.sleep(d.size * 1000L / RATE + 80)
                at.release()
            } catch (_: Exception) { }
        }.start()
    }
}
