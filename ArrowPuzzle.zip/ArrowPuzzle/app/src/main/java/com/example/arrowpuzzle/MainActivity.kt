package com.example.arrowpuzzle

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var play: RowBtn
    private lateinit var daily: RowBtn
    private lateinit var coinTv: TextView
    private lateinit var prefs: Prefs

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        styleBars()
        prefs = Prefs(this); Sfx.enabled = prefs.sound
        val sw = resources.displayMetrics.widthPixels
        val root = FrameLayout(this)
        root.addView(BackgroundView(this))
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding((sw * .084f).toInt(), dp(40), (sw * .084f).toInt(), dp(24))
        }
        col.addView(TitleView(this), LinearLayout.LayoutParams(-1, -2))

        play = RowBtn(this, Ic.PLAY, "PLAY", "Level 1", BtnStyle.DARK, chevron = true, divider = true,
            titleSp = 28f, subSp = 16f, radiusDp = 24, iconDp = 22f, minHDp = 70, padHDp = 20, cellDp = 50, ringDp = 2f)
        col.addView(play, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(22) })

        daily = RowBtn(this, Ic.CALENDAR, "Daily\nChallenge", "New every day", BtnStyle.CARD, chevron = true, divider = true,
            titleSp = 14.5f, subSp = 11.5f, radiusDp = 22, iconDp = 26f, minHDp = 62, padHDp = 14, cellDp = 32)
        val levels = RowBtn(this, Ic.BARS, "Levels", "All levels", BtnStyle.CARD, chevron = true, divider = true,
            titleSp = 14.5f, subSp = 11.5f, radiusDp = 22, iconDp = 22f, minHDp = 62, padHDp = 14, cellDp = 28)
        val row = LinearLayout(this)
        row.addView(daily, LinearLayout.LayoutParams(0, -2, 1.28f).apply { rightMargin = dp(4) })
        row.addView(levels, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(4) })
        col.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })

        val settings = RowBtn(this, Ic.GEAR, "Settings", "Game preferences", BtnStyle.CARD, chevron = true, divider = true,
            titleSp = 16f, subSp = 12.5f, radiusDp = 22, iconDp = 26f, minHDp = 58, padHDp = 14, cellDp = 36)
        col.addView(settings, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        root.addView(col, FrameLayout.LayoutParams(-1, -1))

        val (pill, tv) = coinPill { bonus() }; coinTv = tv
        root.addView(pill, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply { setMargins(dp(16), dp(16), 0, 0) })
        setContentView(root)

        play.setOnClickListener { start(prefs.unlocked, false) }
        daily.setOnClickListener { start(1, true) }
        levels.setOnClickListener { startActivity(Intent(this, LevelsActivity::class.java)) }
        settings.setOnClickListener { showSettings() }
    }

    private fun bonus() {
        val t = today()
        if (prefs.bonusDay != t) {
            prefs.bonusDay = t; prefs.coins += 50; coinTv.text = "${prefs.coins}"; Sfx.win()
            Popup.show(this, "Daily Bonus", "+50 coins", icon = Ic.STAR,
                buttons = listOf(Popup.Btn("Awesome!", true, Ic.CHECK)))
        } else Popup.show(this, "Come back tomorrow", "You already claimed today's bonus.", icon = Ic.STAR,
            buttons = listOf(Popup.Btn("OK", true, Ic.CHECK)))
    }

    private fun showSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun sw(label: String, on: Boolean, f: (Boolean) -> Unit) = Switch(this).apply {
            text = label; textSize = 17f; isChecked = on; setTextColor(C.INK); setPadding(dp(4), dp(10), dp(4), dp(10))
            styleSwitch(this); setOnCheckedChangeListener { _, v -> f(v) }
        }
        box.addView(sw("Sound", prefs.sound) { prefs.sound = it; Sfx.enabled = it })
        box.addView(sw("Vibration", prefs.haptics) { prefs.haptics = it })
        Popup.show(this, "Settings", icon = Ic.GEAR, content = box, buttons = listOf(Popup.Btn("Done", true, Ic.CHECK)))
    }

    private fun today() = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

    override fun onResume() {
        super.onResume()
        play.subTv?.text = "Level ${prefs.unlocked}"
        val done = prefs.dailyDone == today()
        daily.titleTv.text = if (done) "Daily\nCompleted" else "Daily\nChallenge"
        daily.subTv?.text = if (done) "Come back soon" else "New every day"
        coinTv.text = "${prefs.coins}"
    }

    private fun start(level: Int, isDaily: Boolean) {
        startActivity(Intent(this, GameActivity::class.java).putExtra("level", level).putExtra("daily", isDaily))
    }
}
