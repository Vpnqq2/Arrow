package com.example.arrowpuzzle

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var play: TextView
    private lateinit var daily: TextView
    private lateinit var coinTv: TextView
    private lateinit var prefs: Prefs

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        styleBars()
        prefs = Prefs(this); Sfx.enabled = prefs.sound
        val root = FrameLayout(this)
        root.addView(BackgroundView(this))
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(32), dp(24), dp(32), dp(24))
        }
        col.addView(TitleView(this), LinearLayout.LayoutParams(-1, -2))
        play = gradBtn("", C.BLUE, C.VIOLET, 24f)
        col.addView(play, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        val row = LinearLayout(this)
        daily = gradBtn("", C.ORANGE, C.GOLD, 16f)
        val levels = softBtn("Levels")
        row.addView(daily, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(8) })
        row.addView(levels, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(8) })
        col.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
        val settings = softBtn("Settings")
        col.addView(settings, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
        root.addView(col, FrameLayout.LayoutParams(-1, -1))
        val (pill, tv) = coinPill(); coinTv = tv
        root.addView(pill, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply { setMargins(0, dp(16), dp(16), 0) })
        setContentView(root)

        play.setOnClickListener { start(prefs.unlocked, false) }
        daily.setOnClickListener { start(1, true) }
        levels.setOnClickListener { startActivity(Intent(this, LevelsActivity::class.java)) }
        settings.setOnClickListener { showSettings() }
    }

    private fun showSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun sw(label: String, on: Boolean, f: (Boolean) -> Unit) = Switch(this).apply {
            text = label; textSize = 17f; isChecked = on; setTextColor(C.INK); setPadding(dp(4), dp(10), dp(4), dp(10))
            setOnCheckedChangeListener { _, v -> f(v) }
        }
        box.addView(sw("Sound", prefs.sound) { prefs.sound = it; Sfx.enabled = it })
        box.addView(sw("Vibration", prefs.haptics) { prefs.haptics = it })
        Popup.show(this, "Settings", content = box, buttons = listOf(Popup.Btn("Done", true)))
    }

    private fun today() = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

    override fun onResume() {
        super.onResume()
        play.text = "▶  PLAY  ·  Level ${prefs.unlocked}"
        daily.text = if (prefs.dailyDone == today()) "Daily ✓" else "Daily Challenge"
        coinTv.text = "${prefs.coins}"
    }

    private fun start(level: Int, isDaily: Boolean) {
        startActivity(Intent(this, GameActivity::class.java).putExtra("level", level).putExtra("daily", isDaily))
    }
}
