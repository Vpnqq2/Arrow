package com.example.arrowpuzzle

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var play: TextView
    private lateinit var daily: TextView
    private lateinit var prefs: Prefs

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = Prefs(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setBackgroundColor(Color.WHITE); setPadding(dp(32), dp(32), dp(32), dp(32))
        }
        root.addView(TextView(this).apply {
            text = "➚ Arrow\nPuzzle"; textSize = 42f; gravity = Gravity.CENTER
            setTextColor(0xFF2B3A67.toInt()); setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "Tap arrows to clear the board and escape every maze!"
            gravity = Gravity.CENTER; setTextColor(0xFF6B7794.toInt()); setPadding(0, dp(12), 0, dp(40))
        })
        play = pill("", 22f); daily = pill("", 18f)
        val levels = pill("Select Level", 18f)
        val lp = { LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(16) } }
        play.setOnClickListener { start(prefs.unlocked, false) }
        daily.setOnClickListener { start(1, true) }
        levels.setOnClickListener {
            val n = prefs.unlocked
            val names = Array(n) { "Level ${it + 1}" }
            AlertDialog.Builder(this).setTitle("Select Level")
                .setItems(names) { _, i -> start(i + 1, false) }.show()
        }
        root.addView(play, lp()); root.addView(daily, lp()); root.addView(levels, lp())
        setContentView(root)
    }

    private fun today() = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

    override fun onResume() {
        super.onResume()
        play.text = "▶  Play  –  Level ${prefs.unlocked}"
        daily.text = if (prefs.dailyDone == today()) "📅  Daily Challenge ✓" else "📅  Daily Challenge"
    }

    private fun start(level: Int, isDaily: Boolean) {
        startActivity(Intent(this, GameActivity::class.java).putExtra("level", level).putExtra("daily", isDaily))
    }
}
