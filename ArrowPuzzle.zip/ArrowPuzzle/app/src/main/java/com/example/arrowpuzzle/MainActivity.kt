package com.example.arrowpuzzle

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var play: RowBtn
    private lateinit var daily: RowBtn
    private lateinit var coinTv: TextView
    private lateinit var prefs: Prefs

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        styleBars()
        prefs = Prefs(this); Sfx.enabled = prefs.sound
        val sw = resources.displayMetrics.widthPixels
        val root = FrameLayout(this)
        root.addView(BackgroundView(this))
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding((sw * .094f).toInt(), dp(48), (sw * .094f).toInt(), dp(24))
        }
        col.addView(TitleView(this), LinearLayout.LayoutParams(-1, -2))
        play = RowBtn(this, Ic.PLAY, "PLAY", "Level 1", BtnStyle.PRIMARY, center = true, divider = true,
            titleSp = 30f, iconDp = 30f, minHDp = 66, padHDp = 16)
        col.addView(play, LinearLayout.LayoutParams((sw * .59f).toInt(), -2).apply { topMargin = dp(16) })

        daily = RowBtn(this, Ic.CALENDAR, "Daily\nChallenge", null, BtnStyle.AMBER, chevron = true,
            titleSp = 15f, radiusDp = 20, iconDp = 28f, minHDp = 56, padHDp = 14, cellDp = 32)
        val levels = RowBtn(this, Ic.BARS, "Levels", null, BtnStyle.WHITE, chevron = true,
            titleSp = 16f, radiusDp = 20, iconDp = 26f, minHDp = 56, padHDp = 14, cellDp = 32)
        val row = LinearLayout(this)
        row.addView(daily, LinearLayout.LayoutParams(0, -2, 1.15f).apply { rightMargin = dp(7) })
        row.addView(levels, LinearLayout.LayoutParams(0, -2, .85f).apply { leftMargin = dp(7) })
        col.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(22) })

        val settings = RowBtn(this, Ic.GEAR, "Settings", null, BtnStyle.WHITE, chevron = true,
            titleSp = 16f, radiusDp = 20, iconDp = 24f, minHDp = 46, padHDp = 14, cellDp = 32)
        col.addView(settings, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })
        root.addView(col, FrameLayout.LayoutParams(-1, -1))

        val (pill, tv) = coinPill { bonus() }; coinTv = tv
        root.addView(pill, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply { setMargins(dp(18), dp(16), 0, 0) })
        setContentView(root)

        play.setOnClickListener { start(prefs.unlocked, false) }
        daily.setOnClickListener { start(1, true) }
        levels.setOnClickListener { startActivity(Intent(this, LevelsActivity::class.java)) }
        settings.setOnClickListener { showSettings() }
    }

    private fun bonus() {
        val t = today()
        if (prefs.bonusDay != t) {
            prefs.bonusDay = t; prefs.coins += 50; coinTv.text = "${prefs.coins}"; Sfx.win()
            Popup.show(this, "Daily Bonus", "+50 coins", icon = Ic.STAR,
                buttons = listOf(Popup.Btn("Awesome!", true, Ic.CHECK)))
        } else Popup.show(this, "Come back tomorrow", "You already claimed today's bonus.", icon = Ic.STAR,
            buttons = listOf(Popup.Btn("OK", true, Ic.CHECK)))
    }

    private fun showSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun sw(label: String, on: Boolean, f: (Boolean) -> Unit) = Switch(this).apply {
            text = label; textSize = 17f; isChecked = on; setTextColor(C.INK); setPadding(dp(4), dp(10), dp(4), dp(10))
            setOnCheckedChangeListener { _, v -> f(v) }
        }
        box.addView(sw("Sound", prefs.sound) { prefs.sound = it; Sfx.enabled = it })
        box.addView(sw("Vibration", prefs.haptics) { prefs.haptics = it })
        Popup.show(this, "Settings", icon = Ic.GEAR, content = box, buttons = listOf(Popup.Btn("Done", true, Ic.CHECK)))
    }

    private fun today() = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

    override fun onResume() {
        super.onResume()
        play.subTv?.text = "Level ${prefs.unlocked}"
        daily.titleTv.text = if (prefs.dailyDone == today()) "Daily\nCompleted ✓" else "Daily\nChallenge"
        coinTv.text = "${prefs.coins}"
    }

    private fun start(level: Int, isDaily: Boolean) {
        startActivity(Intent(this, GameActivity::class.java).putExtra("level", level).putExtra("daily", isDaily))
    }
}
