package com.example.arrowpuzzle

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.animation.OvershootInterpolator
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.*

fun starPath(cx: Float, cy: Float, r: Float): Path {
    val p = Path()
    for (i in 0 until 10) {
        val a = -PI / 2 + i * PI / 5
        val rr = if (i % 2 == 0) r else r * 0.46f
        val x = (cx + rr * cos(a)).toFloat(); val y = (cy + rr * sin(a)).toFloat()
        if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
    }
    p.close(); return p
}

fun heartPath(cx: Float, cy: Float, r: Float): Path = Path().apply {
    moveTo(cx, cy + r * 0.95f)
    cubicTo(cx + r * 1.5f, cy + r * 0.1f, cx + r * 0.95f, cy - r * 1.05f, cx, cy - r * 0.35f)
    cubicTo(cx - r * 0.95f, cy - r * 1.05f, cx - r * 1.5f, cy + r * 0.1f, cx, cy + r * 0.95f)
    close()
}

fun drawArrowShape(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, w: Float, p: Paint) {
    val d = hypot(x2 - x1, y2 - y1); val ux = (x2 - x1) / d; val uy = (y2 - y1) / d
    p.style = Paint.Style.STROKE; p.strokeWidth = w; p.strokeCap = Paint.Cap.ROUND
    c.drawLine(x1, y1, x2 - ux * w, y2 - uy * w, p)
    p.style = Paint.Style.FILL
    val bx = x2 - ux * w * 0.9f; val by = y2 - uy * w * 0.9f; val hw = w * 1.4f
    c.drawPath(Path().apply {
        moveTo(x2 + ux * w * 0.9f, y2 + uy * w * 0.9f)
        lineTo(bx - uy * hw, by + ux * hw); lineTo(bx + uy * hw, by - ux * hw); close()
    }, p)
}

enum class Ic { PAUSE, RESTART, HINT, GRID, BACK, PLAY, MENU, GEAR, CALENDAR, BARS, CHEVRON, PLUS, CHECK, STAR, HEART }

/** Draws an icon whose half-extent is about [half] pixels, centered at (cx, cy). */
fun drawIcon(c: Canvas, ic: Ic, cx: Float, cy: Float, half: Float, color: Int, p: Paint) {
    val s = half * 2.5f
    p.pathEffect = null; p.shader = null
    p.color = color; p.style = Paint.Style.STROKE; p.strokeWidth = half * 0.3f
    p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
    when (ic) {
        Ic.PAUSE -> {
            p.style = Paint.Style.FILL
            c.drawRoundRect(cx - s * .36f, cy - s * .4f, cx - s * .08f, cy + s * .4f, s * .1f, s * .1f, p)
            c.drawRoundRect(cx + s * .08f, cy - s * .4f, cx + s * .36f, cy + s * .4f, s * .1f, s * .1f, p)
        }
        Ic.RESTART -> {
            val r = s * .38f
            c.drawArc(RectF(cx - r, cy - r, cx + r, cy + r), -50f, 270f, false, p)
            val a = Math.toRadians(220.0)
            val ex = cx + r * cos(a).toFloat(); val ey = cy + r * sin(a).toFloat()
            val tx = -sin(a).toFloat(); val ty = cos(a).toFloat(); val hs = s * .28f
            p.style = Paint.Style.FILL
            c.drawPath(Path().apply {
                moveTo(ex + tx * hs, ey + ty * hs)
                lineTo(ex - ty * hs * .8f, ey + tx * hs * .8f); lineTo(ex + ty * hs * .8f, ey - tx * hs * .8f); close()
            }, p)
        }
        Ic.HINT -> {
            p.style = Paint.Style.FILL; p.color = C.GOLD
            c.drawCircle(cx, cy - s * .1f, s * .34f, p)
            p.color = color
            c.drawRoundRect(cx - s * .17f, cy + s * .22f, cx + s * .17f, cy + s * .42f, s * .07f, s * .07f, p)
        }
        Ic.GRID -> {
            p.style = Paint.Style.FILL
            for (x in floatArrayOf(-.4f, .06f)) for (y in floatArrayOf(-.4f, .06f))
                c.drawRoundRect(cx + s * x, cy + s * y, cx + s * (x + .34f), cy + s * (y + .34f), s * .08f, s * .08f, p)
        }
        Ic.BACK -> c.drawPath(Path().apply {
            moveTo(cx + s * .14f, cy - s * .4f); lineTo(cx - s * .2f, cy); lineTo(cx + s * .14f, cy + s * .4f)
        }, p)
        Ic.PLAY -> {
            p.style = Paint.Style.FILL; p.pathEffect = CornerPathEffect(s * .1f)
            c.drawPath(Path().apply {
                moveTo(cx - s * .26f, cy - s * .42f); lineTo(cx - s * .26f, cy + s * .42f); lineTo(cx + s * .42f, cy); close()
            }, p)
            p.pathEffect = null
        }
        Ic.MENU -> {
            p.strokeWidth = half * .32f
            for (y in floatArrayOf(-.3f, 0f, .3f)) c.drawLine(cx - s * .36f, cy + s * y, cx + s * .36f, cy + s * y, p)
        }
        Ic.GEAR -> {
            p.style = Paint.Style.FILL
            for (i in 0 until 8) {
                c.save(); c.rotate(i * 45f, cx, cy)
                c.drawRoundRect(cx - s * .075f, cy - s * .44f, cx + s * .075f, cy - s * .22f, s * .04f, s * .04f, p)
                c.restore()
            }
            p.style = Paint.Style.STROKE; p.strokeWidth = s * .17f
            c.drawCircle(cx, cy, s * .25f, p)
        }
        Ic.CALENDAR -> {
            p.strokeWidth = s * .1f
            c.drawRoundRect(cx - s * .36f, cy - s * .3f, cx + s * .36f, cy + s * .38f, s * .1f, s * .1f, p)
            c.drawLine(cx - s * .18f, cy - s * .42f, cx - s * .18f, cy - s * .2f, p)
            c.drawLine(cx + s * .18f, cy - s * .42f, cx + s * .18f, cy - s * .2f, p)
            p.style = Paint.Style.FILL
            for ((dx, dy) in listOf(-.2f to -.04f, .02f to -.04f, -.2f to .17f))
                c.drawRoundRect(cx + s * dx, cy + s * dy, cx + s * (dx + .13f), cy + s * (dy + .13f), s * .03f, s * .03f, p)
            p.color = color; c.drawCircle(cx + s * .3f, cy + s * .3f, s * .2f, p)
            p.color = C.AMBER; p.pathEffect = CornerPathEffect(s * .03f)
            c.drawPath(starPath(cx + s * .3f, cy + s * .3f, s * .13f), p); p.pathEffect = null
        }
        Ic.BARS -> {
            p.style = Paint.Style.FILL
            val cols = intArrayOf(0xFF4F8BFF.toInt(), 0xFF6A6CFF.toInt(), 0xFF8A5CFF.toInt())
            val hs = floatArrayOf(.45f, .7f, .95f)
            for (i in 0..2) {
                p.color = cols[i]; val x = cx + s * (-.3f + .3f * i)
                c.drawRoundRect(x - s * .1f, cy + s * .45f - s * hs[i], x + s * .1f, cy + s * .45f, s * .06f, s * .06f, p)
            }
        }
        Ic.CHEVRON -> c.drawPath(Path().apply {
            moveTo(cx - s * .14f, cy - s * .36f); lineTo(cx + s * .2f, cy); lineTo(cx - s * .14f, cy + s * .36f)
        }, p)
        Ic.PLUS -> {
            p.strokeWidth = half * .36f
            c.drawLine(cx - s * .3f, cy, cx + s * .3f, cy, p); c.drawLine(cx, cy - s * .3f, cx, cy + s * .3f, p)
        }
        Ic.CHECK -> c.drawPath(Path().apply {
            moveTo(cx - s * .34f, cy); lineTo(cx - s * .1f, cy + s * .26f); lineTo(cx + s * .36f, cy - s * .28f)
        }, p)
        Ic.STAR -> {
            p.style = Paint.Style.FILL; p.pathEffect = CornerPathEffect(s * .05f)
            c.drawPath(starPath(cx, cy, s * .46f), p); p.pathEffect = null
        }
        Ic.HEART -> { p.style = Paint.Style.FILL; c.drawPath(heartPath(cx, cy, s * .32f), p) }
    }
}

class IconView(ctx: Context, var ic: Ic, var tint: Int, private val iconDp: Float) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        drawIcon(c, ic, width / 2f, height / 2f, iconDp * resources.displayMetrics.density / 2f, tint, p)
    }
}

class IconButton(ctx: Context, private val ic: Ic) : View(ctx) {
    var badge: String? = null; set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = ctx.resources.displayMetrics.density

    init {
        background = GradientDrawable().apply { cornerRadius = 16 * d; setColor(Color.WHITE) }
        elevation = 4 * d; pressable()
    }

    override fun onDraw(c: Canvas) {
        drawIcon(c, ic, width / 2f, height / 2f, min(width, height) * .23f, C.INK, p)
        badge?.let {
            p.style = Paint.Style.FILL; p.textSize = 11 * d; p.typeface = Typeface.DEFAULT_BOLD; p.textAlign = Paint.Align.CENTER
            val tw = max(19 * d, p.measureText(it) + 10 * d)
            val r = RectF(width - tw - 1 * d, 1 * d, width - 1 * d, 20 * d)
            p.color = C.BLUE; c.drawRoundRect(r, 10 * d, 10 * d, p)
            p.color = Color.WHITE; c.drawText(it, r.centerX(), r.centerY() + 4f * d, p)
        }
    }
}

enum class BtnStyle { PRIMARY, AMBER, WHITE }

class RowBtn(
    ctx: Context, icon: Ic?, title: String, sub: String?, style: BtnStyle,
    chevron: Boolean = false, divider: Boolean = false, center: Boolean = false,
    titleSp: Float = 17f, radiusDp: Int = 100, iconDp: Float = 22f, minHDp: Int = 0,
    padHDp: Int = 20, cellDp: Int = 36
) : LinearLayout(ctx) {
    val titleTv: TextView
    val subTv: TextView?

    init {
        val d = ctx.resources.displayMetrics.density
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL or (if (center) Gravity.CENTER_HORIZONTAL else Gravity.START)
        val fg = if (style == BtnStyle.WHITE) C.INK else Color.WHITE
        val g = when (style) {
            BtnStyle.PRIMARY -> GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(C.GRAD1, C.GRAD2))
            BtnStyle.AMBER -> GradientDrawable().apply { setColor(C.AMBER) }
            BtnStyle.WHITE -> GradientDrawable().apply { setColor(Color.WHITE); setStroke(max(1, (1.2f * d).toInt()), 0xFFE0E7F4.toInt()) }
        }
        g.cornerRadius = radiusDp * d
        background = g
        setPadding((padHDp * d).toInt(), (8 * d).toInt(), (padHDp * d).toInt(), (8 * d).toInt())
        minimumHeight = (minHDp * d).toInt()
        if (icon != null) {
            addView(IconView(ctx, icon, fg, iconDp), LayoutParams((cellDp * d).toInt(), (cellDp * d).toInt()))
            if (divider) addView(View(ctx).apply {
                setBackgroundColor(if (style == BtnStyle.WHITE) 0xFFD6DCEA.toInt() else 0x66FFFFFF)
            }, LayoutParams(max(1, d.toInt()), (26 * d).toInt()).apply { setMargins((6 * d).toInt(), 0, (14 * d).toInt(), 0) })
        }
        val col = LinearLayout(ctx).apply { orientation = VERTICAL }
        titleTv = TextView(ctx).apply {
            text = title; setTextSize(TypedValue.COMPLEX_UNIT_SP, titleSp); setTextColor(fg)
            typeface = if (sub != null) Typeface.DEFAULT_BOLD else medium()
        }
        col.addView(titleTv)
        subTv = if (sub != null) TextView(ctx).apply {
            text = sub; setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f); setTextColor(fg); alpha = .85f
        }.also { col.addView(it) } else null
        val lm = if (icon != null && !divider) (8 * d).toInt() else 0
        addView(col, if (chevron) LayoutParams(0, -2, 1f).apply { leftMargin = lm } else LayoutParams(-2, -2).apply { leftMargin = lm })
        if (chevron) addView(IconView(ctx, Ic.CHEVRON, if (style == BtnStyle.WHITE) 0xFF9AA5BD.toInt() else 0xCCFFFFFF.toInt(), 14f),
            LayoutParams((18 * d).toInt(), (18 * d).toInt()))
        elevation = (if (style == BtnStyle.WHITE) 3 else 6) * d
        if (style == BtnStyle.PRIMARY && Build.VERSION.SDK_INT >= 28) outlineSpotShadowColor = 0xFF5B6CFF.toInt()
        pressable()
    }
}

class HeartsView(ctx: Context) : View(ctx) {
    private var lives = 3; private var popI = -1; private var t = 1f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = ctx.resources.displayMetrics.density

    fun setLives(n: Int) {
        if (n < lives) {
            popI = n
            ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 450; addUpdateListener { t = it.animatedValue as Float; invalidate() }; start()
            }
        }
        lives = n; invalidate()
    }

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension((114 * d).toInt(), (28 * d).toInt())

    override fun onDraw(c: Canvas) {
        for (i in 0..2) {
            val k = if (i == popI && t < 1f) 1f + 0.45f * sin(PI.toFloat() * t) else 1f
            p.color = if (i < lives) C.RED else 0xFFD9E0EE.toInt()
            c.drawPath(heartPath((19 + 38 * i) * d, 14 * d, 10 * d * k), p)
        }
    }
}

class ProgressView(ctx: Context) : View(ctx) {
    private var shown = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    fun set(target: Float, animate: Boolean = true) {
        if (!animate) { shown = target; invalidate(); return }
        ValueAnimator.ofFloat(shown, target).apply {
            duration = 350; addUpdateListener { shown = it.animatedValue as Float; invalidate() }; start()
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        p.shader = null; p.color = 0xFFDCE4F2.toInt()
        c.drawRoundRect(0f, 0f, w, h, h / 2, h / 2, p)
        if (shown > 0.001f) {
            p.shader = LinearGradient(0f, 0f, w, 0f, 0xFF6FA0FF.toInt(), 0xFF8DB4FF.toInt(), Shader.TileMode.CLAMP)
            c.drawRoundRect(0f, 0f, max(h, w * shown), h, h / 2, h / 2, p); p.shader = null
        }
    }
}

class StarsView(ctx: Context, private val n: Int) : View(ctx) {
    private var v = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { pathEffect = CornerPathEffect(6f) }
    private val ease = OvershootInterpolator(2.5f)
    private val d = ctx.resources.displayMetrics.density

    init {
        ValueAnimator.ofFloat(0f, 3f).apply {
            startDelay = 250; duration = 1100; addUpdateListener { v = it.animatedValue as Float; invalidate() }; start()
        }
    }

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension((3 * 64 * d).toInt(), (68 * d).toInt())

    override fun onDraw(c: Canvas) {
        for (i in 0..2) {
            val cx = (32 + 64 * i) * d; val cy = 35 * d
            p.color = 0xFFDDE3F2.toInt(); c.drawPath(starPath(cx, cy, 26 * d), p)
            if (i < n && v > i) {
                val sc = ease.getInterpolation((v - i).coerceIn(0f, 1f))
                p.color = C.GOLD; c.drawPath(starPath(cx, cy, 26 * d * sc), p)
            }
        }
    }
}

class CoinView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val r = min(width, height) / 2f
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, width.toFloat(), height.toFloat(), C.GOLD, 0xFFFFA000.toInt(), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r, p); p.shader = null
        p.color = 0xFFFFB82E.toInt(); c.drawCircle(cx, cy, r * .74f, p)
        p.color = 0xFFFFE27A.toInt(); p.pathEffect = CornerPathEffect(r * .08f)
        c.drawPath(starPath(cx, cy, r * .5f), p); p.pathEffect = null
    }
}

class BackgroundView(ctx: Context) : View(ctx) {
    private class Item(val x: Float, val y: Float, val sp: Float, val ph: Float, val sz: Float, val col: Int)
    private val items = listOf(
        Item(.88f, .30f, .020f, .10f, 1.25f, 0xFF4F8BFF.toInt()), Item(.10f, .55f, .016f, .55f, 1.0f, 0xFF4F8BFF.toInt()),
        Item(.90f, .62f, .018f, .35f, .9f, 0xFFA06BFF.toInt()), Item(.80f, .98f, .022f, .75f, .8f, 0xFF4F8BFF.toInt()),
        Item(.30f, .90f, .017f, .20f, .7f, 0xFFA06BFF.toInt()), Item(.55f, .15f, .015f, .90f, .6f, 0xFF4F8BFF.toInt()))
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = ctx.resources.displayMetrics.density

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, 0f, h, C.BG1, C.BG2, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p); p.shader = null
        p.color = 0x244F8BFF; c.drawCircle(0f, h * .03f, w * .32f, p)
        p.color = 0x264F8BFF; c.drawCircle(w * .02f, h, w * .30f, p)
        p.color = 0x28A06BFF; c.drawCircle(w, h, w * .27f, p)
        val t = System.nanoTime() / 1e9f
        val sa = sin(Math.toRadians(35.0)).toFloat(); val ca = cos(Math.toRadians(35.0)).toFloat()
        for (i in items) {
            val f = (t * i.sp + i.ph) % 1f
            val x = i.x * w + f * h * .25f * sa; val y = i.y * h - f * h * .25f * ca
            c.save(); c.translate(x, y); c.rotate(35f)
            val a = (sin(PI * f).toFloat() * 0x55).toInt()
            p.color = (i.col and 0x00FFFFFF) or (a shl 24)
            drawArrowShape(c, 0f, 45 * d * i.sz, 0f, -45 * d * i.sz, 7 * d * i.sz, p)
            c.restore()
        }
        postInvalidateOnAnimation()
    }
}

class TitleView(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(MeasureSpec.getSize(w), (204 * d).toInt())

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val s = 86 * d
        val r = RectF(cx - s / 2, 4 * d, cx + s / 2, 4 * d + s)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(r.left, r.top, r.right, r.bottom, C.GRAD1, C.GRAD2, Shader.TileMode.CLAMP)
        c.drawRoundRect(r, s * .3f, s * .3f, p); p.shader = null
        p.color = Color.WHITE
        drawArrowShape(c, r.centerX() - s * .2f, r.centerY() + s * .2f, r.centerX() + s * .2f, r.centerY() - s * .2f, s * .11f, p)
        p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.DEFAULT_BOLD
        p.letterSpacing = 0.06f; p.textSize = 40 * d; p.color = C.INK
        val b1 = r.bottom + 42 * d
        c.drawText("ARROW", cx, b1, p)
        p.shader = LinearGradient(cx - 90 * d, 0f, cx + 90 * d, 0f, C.GRAD1, C.GRAD2, Shader.TileMode.CLAMP)
        c.drawText("PUZZLE", cx, b1 + 36 * d, p); p.shader = null
        p.letterSpacing = 0.3f; p.textSize = 11 * d; p.color = C.MUTED; p.typeface = medium()
        c.drawText("THINK  •  AIM  •  SOLVE", cx, b1 + 60 * d, p)
        p.letterSpacing = 0f
    }
}
