package com.example.arrowpuzzle

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.animation.OvershootInterpolator
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.*

fun starPath(cx: Float, cy: Float, r: Float): Path {
    val p = Path()
    for (i in 0 until 10) {
        val a = -PI / 2 + i * PI / 5
        val rr = if (i % 2 == 0) r else r * 0.46f
        val x = (cx + rr * cos(a)).toFloat(); val y = (cy + rr * sin(a)).toFloat()
        if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
    }
    p.close(); return p
}

fun heartPath(cx: Float, cy: Float, r: Float): Path = Path().apply {
    moveTo(cx, cy + r * 0.95f)
    cubicTo(cx + r * 1.5f, cy + r * 0.1f, cx + r * 0.95f, cy - r * 1.05f, cx, cy - r * 0.35f)
    cubicTo(cx - r * 0.95f, cy - r * 1.05f, cx - r * 1.5f, cy + r * 0.1f, cx, cy + r * 0.95f)
    close()
}

fun drawArrowShape(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, w: Float, p: Paint) {
    val d = hypot(x2 - x1, y2 - y1); val ux = (x2 - x1) / d; val uy = (y2 - y1) / d
    p.style = Paint.Style.STROKE; p.strokeWidth = w; p.strokeCap = Paint.Cap.ROUND
    c.drawLine(x1, y1, x2 - ux * w, y2 - uy * w, p)
    p.style = Paint.Style.FILL
    val bx = x2 - ux * w * 0.9f; val by = y2 - uy * w * 0.9f; val hw = w * 1.4f
    c.drawPath(Path().apply {
        moveTo(x2 + ux * w * 0.9f, y2 + uy * w * 0.9f)
        lineTo(bx - uy * hw, by + ux * hw); lineTo(bx + uy * hw, by - ux * hw); close()
    }, p)
}

enum class Ic { PAUSE, RESTART, HINT, GRID, BACK, PLAY, MENU, GEAR, CALENDAR, BARS, CHEVRON, PLUS, CHECK, STAR, HEART, ZOOM_IN, ZOOM_OUT }

/** Draws an icon whose half-extent is about [half] pixels, centered at (cx, cy). */
fun drawIcon(c: Canvas, ic: Ic, cx: Float, cy: Float, half: Float, color: Int, p: Paint) {
    val s = half * 2.5f
    p.pathEffect = null; p.shader = null
    p.color = color; p.style = Paint.Style.STROKE; p.strokeWidth = half * 0.3f
    p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
    when (ic) {
        Ic.PAUSE -> {
            p.style = Paint.Style.FILL
            c.drawRoundRect(cx - s * .36f, cy - s * .4f, cx - s * .08f, cy + s * .4f, s * .1f, s * .1f, p)
            c.drawRoundRect(cx + s * .08f, cy - s * .4f, cx + s * .36f, cy + s * .4f, s * .1f, s * .1f, p)
        }
        Ic.RESTART -> {
            val r = s * .38f
            c.drawArc(RectF(cx - r, cy - r, cx + r, cy + r), -50f, 270f, false, p)
            val a = Math.toRadians(220.0)
            val ex = cx + r * cos(a).toFloat(); val ey = cy + r * sin(a).toFloat()
            val tx = -sin(a).toFloat(); val ty = cos(a).toFloat(); val hs = s * .28f
            p.style = Paint.Style.FILL
            c.drawPath(Path().apply {
                moveTo(ex + tx * hs, ey + ty * hs)
                lineTo(ex - ty * hs * .8f, ey + tx * hs * .8f); lineTo(ex + ty * hs * .8f, ey - tx * hs * .8f); close()
            }, p)
        }
        Ic.HINT -> {
            p.style = Paint.Style.FILL; p.color = C.GOLD
            c.drawCircle(cx, cy - s * .1f, s * .34f, p)
            p.color = color
            c.drawRoundRect(cx - s * .17f, cy + s * .22f, cx + s * .17f, cy + s * .42f, s * .07f, s * .07f, p)
        }
        Ic.GRID -> {
            p.style = Paint.Style.FILL
            for (x in floatArrayOf(-.4f, .06f)) for (y in floatArrayOf(-.4f, .06f))
                c.drawRoundRect(cx + s * x, cy + s * y, cx + s * (x + .34f), cy + s * (y + .34f), s * .08f, s * .08f, p)
        }
        Ic.BACK -> c.drawPath(Path().apply {
            moveTo(cx + s * .14f, cy - s * .4f); lineTo(cx - s * .2f, cy); lineTo(cx + s * .14f, cy + s * .4f)
        }, p)
        Ic.PLAY -> {
            p.style = Paint.Style.FILL; p.pathEffect = CornerPathEffect(s * .1f)
            c.drawPath(Path().apply {
                moveTo(cx - s * .26f, cy - s * .42f); lineTo(cx - s * .26f, cy + s * .42f); lineTo(cx + s * .42f, cy); close()
            }, p)
            p.pathEffect = null
        }
        Ic.MENU -> {
            p.strokeWidth = half * .32f
            for (y in floatArrayOf(-.3f, 0f, .3f)) c.drawLine(cx - s * .36f, cy + s * y, cx + s * .36f, cy + s * y, p)
        }
        Ic.GEAR -> {
            p.style = Paint.Style.FILL
            for (i in 0 until 8) {
                c.save(); c.rotate(i * 45f, cx, cy)
                c.drawRoundRect(cx - s * .075f, cy - s * .44f, cx + s * .075f, cy - s * .22f, s * .04f, s * .04f, p)
                c.restore()
            }
            p.style = Paint.Style.STROKE; p.strokeWidth = s * .17f
            c.drawCircle(cx, cy, s * .25f, p)
        }
        Ic.CALENDAR -> {
            p.strokeWidth = s * .1f
            c.drawRoundRect(cx - s * .36f, cy - s * .3f, cx + s * .36f, cy + s * .38f, s * .1f, s * .1f, p)
            c.drawLine(cx - s * .18f, cy - s * .42f, cx - s * .18f, cy - s * .2f, p)
            c.drawLine(cx + s * .18f, cy - s * .42f, cx + s * .18f, cy - s * .2f, p)
            p.style = Paint.Style.FILL
            for ((dx, dy) in listOf(-.2f to -.04f, .02f to -.04f, -.2f to .17f))
                c.drawRoundRect(cx + s * dx, cy + s * dy, cx + s * (dx + .13f), cy + s * (dy + .13f), s * .03f, s * .03f, p)
            p.color = color; c.drawCircle(cx + s * .3f, cy + s * .3f, s * .2f, p)
            p.color = Color.WHITE; p.pathEffect = CornerPathEffect(s * .03f)
            c.drawPath(starPath(cx + s * .3f, cy + s * .3f, s * .13f), p); p.pathEffect = null
        }
        Ic.BARS -> {
            p.style = Paint.Style.FILL
            val cols = intArrayOf(0xFF6B7595.toInt(), 0xFF3F4B70.toInt(), 0xFF1E2A4A.toInt())
            val hs = floatArrayOf(.45f, .7f, .95f)
            for (i in 0..2) {
                p.color = cols[i]; val x = cx + s * (-.3f + .3f * i)
                c.drawRoundRect(x - s * .1f, cy + s * .45f - s * hs[i], x + s * .1f, cy + s * .45f, s * .06f, s * .06f, p)
            }
        }
        Ic.CHEVRON -> c.drawPath(Path().apply {
            moveTo(cx - s * .14f, cy - s * .36f); lineTo(cx + s * .2f, cy); lineTo(cx - s * .14f, cy + s * .36f)
        }, p)
        Ic.PLUS -> {
            p.strokeWidth = half * .36f
            c.drawLine(cx - s * .3f, cy, cx + s * .3f, cy, p); c.drawLine(cx, cy - s * .3f, cx, cy + s * .3f, p)
        }
        Ic.CHECK -> c.drawPath(Path().apply {
            moveTo(cx - s * .34f, cy); lineTo(cx - s * .1f, cy + s * .26f); lineTo(cx + s * .36f, cy - s * .28f)
        }, p)
        Ic.STAR -> {
            p.style = Paint.Style.FILL; p.pathEffect = CornerPathEffect(s * .05f)
            c.drawPath(starPath(cx, cy, s * .46f), p); p.pathEffect = null
        }
        Ic.HEART -> { p.style = Paint.Style.FILL; c.drawPath(heartPath(cx, cy, s * .32f), p) }
        Ic.ZOOM_IN, Ic.ZOOM_OUT -> {
            val r = s * .3f; val mx = cx - s * .08f; val my = cy - s * .08f
            c.drawCircle(mx, my, r, p)
            c.drawLine(mx + r * .72f, my + r * .72f, cx + s * .38f, cy + s * .38f, p)
            p.strokeWidth = half * .24f
            c.drawLine(mx - r * .5f, my, mx + r * .5f, my, p)
            if (ic == Ic.ZOOM_IN) c.drawLine(mx, my - r * .5f, mx, my + r * .5f, p)
        }
    }
}

class IconView(ctx: Context, var ic: Ic, var tint: Int, private val iconDp: Float, private val ringDp: Float = 0f) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        val d = resources.displayMetrics.density
        if (ringDp > 0f) {
            p.style = Paint.Style.STROKE; p.strokeWidth = ringDp * d; p.color = tint
            c.drawCircle(width / 2f, height / 2f, min(width, height) / 2f - ringDp * d / 2f, p)
        }
        drawIcon(c, ic, width / 2f, height / 2f, iconDp * d / 2f, tint, p)
    }
}

class IconButton(ctx: Context, private val ic: Ic) : View(ctx) {
    var badge: String? = null; set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = ctx.resources.displayMetrics.density

    init {
        background = GradientDrawable().apply { cornerRadius = 16 * d; setColor(Color.WHITE); setStroke(max(1, d.toInt()), C.LINE) }
        pressable()
    }

    override fun onDraw(c: Canvas) {
        drawIcon(c, ic, width / 2f, height / 2f, min(width, height) * .23f, C.INK, p)
        badge?.let {
            p.style = Paint.Style.FILL; p.textSize = 11 * d; p.typeface = Typeface.DEFAULT_BOLD; p.textAlign = Paint.Align.CENTER
            val tw = max(19 * d, p.measureText(it) + 10 * d)
            val r = RectF(width - tw - 1 * d, 1 * d, width - 1 * d, 20 * d)
            p.color = C.INK; c.drawRoundRect(r, 10 * d, 10 * d, p)
            p.color = Color.WHITE; c.drawText(it, r.centerX(), r.centerY() + 4f * d, p)
        }
    }
}

enum class BtnStyle { DARK, CARD }

class RowBtn(
    ctx: Context, icon: Ic?, title: String, sub: String?, style: BtnStyle,
    chevron: Boolean = false, divider: Boolean = false, center: Boolean = false,
    titleSp: Float = 17f, radiusDp: Int = 22, iconDp: Float = 22f, minHDp: Int = 0,
    padHDp: Int = 18, cellDp: Int = 40, ringDp: Float = 0f, subSp: Float = 13f
) : LinearLayout(ctx) {
    val titleTv: TextView
    val subTv: TextView?

    init {
        val d = ctx.resources.displayMetrics.density
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL or (if (center) Gravity.CENTER_HORIZONTAL else Gravity.START)
        val dark = style == BtnStyle.DARK
        val fg = if (dark) Color.WHITE else C.INK
        val g = if (dark) GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(C.INK2, C.INK))
        else GradientDrawable().apply { setColor(Color.WHITE); setStroke(max(1, d.toInt()), C.LINE) }
        g.cornerRadius = radiusDp * d
        background = g
        setPadding((padHDp * d).toInt(), (8 * d).toInt(), (padHDp * d).toInt(), (8 * d).toInt())
        minimumHeight = (minHDp * d).toInt()
        if (icon != null) {
            addView(IconView(ctx, icon, fg, iconDp, ringDp), LayoutParams((cellDp * d).toInt(), (cellDp * d).toInt()))
            if (divider) addView(View(ctx).apply { setBackgroundColor(if (dark) 0x33FFFFFF else C.LINE) },
                LayoutParams(max(1, d.toInt()), ((if (sub != null) 30 else 22) * d).toInt()).apply { setMargins((8 * d).toInt(), 0, (12 * d).toInt(), 0) })
        }
        val col = LinearLayout(ctx).apply { orientation = VERTICAL }
        titleTv = TextView(ctx).apply {
            text = title; setTextSize(TypedValue.COMPLEX_UNIT_SP, titleSp); setTextColor(fg)
            typeface = if (sub != null) Typeface.DEFAULT_BOLD else medium()
        }
        col.addView(titleTv)
        subTv = if (sub != null) TextView(ctx).apply {
            text = sub; setTextSize(TypedValue.COMPLEX_UNIT_SP, subSp); setTextColor(if (dark) 0xFFB4BCCF.toInt() else C.MUTED)
        }.also { col.addView(it) } else null
        val lm = if (icon != null && !divider) (6 * d).toInt() else 0
        addView(col, if (chevron) LayoutParams(0, -2, 1f).apply { leftMargin = lm } else LayoutParams(-2, -2).apply { leftMargin = lm })
        if (chevron) addView(IconView(ctx, Ic.CHEVRON, if (dark) Color.WHITE else C.INK, 13f), LayoutParams((16 * d).toInt(), (20 * d).toInt()))
        pressable()
    }
}

class HeartsView(ctx: Context) : View(ctx) {
    private var lives = 3; private var popI = -1; private var t = 1f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = ctx.resources.displayMetrics.density

    fun setLives(n: Int) {
        if (n < lives) {
            popI = n
            ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 450; addUpdateListener { t = it.animatedValue as Float; invalidate() }; start()
            }
        }
        lives = n; invalidate()
    }

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension((114 * d).toInt(), (28 * d).toInt())

    override fun onDraw(c: Canvas) {
        for (i in 0..2) {
            val k = if (i == popI && t < 1f) 1f + 0.45f * sin(PI.toFloat() * t) else 1f
            p.color = if (i < lives) C.RED else 0xFFD9E0EE.toInt()
            c.drawPath(heartPath((19 + 38 * i) * d, 14 * d, 10 * d * k), p)
        }
    }
}

class ProgressView(ctx: Context) : View(ctx) {
    private var shown = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    fun set(target: Float, animate: Boolean = true) {
        if (!animate) { shown = target; invalidate(); return }
        ValueAnimator.ofFloat(shown, target).apply {
            duration = 350; addUpdateListener { shown = it.animatedValue as Float; invalidate() }; start()
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        p.shader = null; p.color = 0xFFDDE2EA.toInt()
        c.drawRoundRect(0f, 0f, w, h, h / 2, h / 2, p)
        if (shown > 0.001f) {
            p.color = C.INK
            c.drawRoundRect(0f, 0f, max(h, w * shown), h, h / 2, h / 2, p)
        }
    }
}

class StarsView(ctx: Context, private val n: Int) : View(ctx) {
    private var v = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { pathEffect = CornerPathEffect(6f) }
    private val ease = OvershootInterpolator(2.5f)
    private val d = ctx.resources.displayMetrics.density

    init {
        ValueAnimator.ofFloat(0f, 3f).apply {
            startDelay = 250; duration = 1100; addUpdateListener { v = it.animatedValue as Float; invalidate() }; start()
        }
    }

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension((3 * 64 * d).toInt(), (68 * d).toInt())

    override fun onDraw(c: Canvas) {
        for (i in 0..2) {
            val cx = (32 + 64 * i) * d; val cy = 35 * d
            p.color = 0xFFDDE3F2.toInt(); c.drawPath(starPath(cx, cy, 26 * d), p)
            if (i < n && v > i) {
                val sc = ease.getInterpolation((v - i).coerceIn(0f, 1f))
                p.color = C.GOLD; c.drawPath(starPath(cx, cy, 26 * d * sc), p)
            }
        }
    }
}

class BackgroundView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, 0f, h, C.BG1, C.BG2, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p); p.shader = null
        p.color = 0xFFE8EBF0.toInt(); c.drawCircle(-w * .02f, h * 1.02f, w * .26f, p)
        p.color = C.INK; c.drawCircle(-w * .01f, -h * .01f, w * .27f, p)
        c.drawCircle(w * 1.01f, h * 1.01f, w * .27f, p)
    }
}

class TitleView(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val logo = BitmapFactory.decodeResource(ctx.resources, R.drawable.logo_white)

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(MeasureSpec.getSize(w), (210 * d).toInt())

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val s = 100 * d
        val r = RectF(cx - s / 2, 4 * d, cx + s / 2, 4 * d + s)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(r.left, r.top, r.right, r.bottom, C.INK2, C.INK, Shader.TileMode.CLAMP)
        c.drawRoundRect(r, s * .22f, s * .22f, p); p.shader = null
        val ls = s * .68f
        c.drawBitmap(logo, null, RectF(r.centerX() - ls / 2, r.centerY() - ls / 2, r.centerX() + ls / 2, r.centerY() + ls / 2), p)
        p.textAlign = Paint.Align.CENTER; p.color = C.INK
        p.typeface = Typeface.create("sans-serif-black", Typeface.NORMAL); p.letterSpacing = 0.04f; p.textSize = 40 * d
        val b1 = r.bottom + 40 * d
        c.drawText("ARROW", cx, b1, p)
        p.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL); p.letterSpacing = 0.14f; p.textSize = 38 * d
        c.drawText("PUZZLE", cx, b1 + 35 * d, p)
        p.typeface = medium(); p.letterSpacing = 0.32f; p.textSize = 11 * d; p.color = C.MUTED
        c.drawText("THINK  •  AIM  •  SOLVE", cx, b1 + 60 * d, p)
        p.letterSpacing = 0f
    }
}
