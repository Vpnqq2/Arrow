package com.example.arrowpuzzle

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.view.animation.OvershootInterpolator
import kotlin.math.*

fun starPath(cx: Float, cy: Float, r: Float): Path {
    val p = Path()
    for (i in 0 until 10) {
        val a = -PI / 2 + i * PI / 5
        val rr = if (i % 2 == 0) r else r * 0.46f
        val x = (cx + rr * cos(a)).toFloat(); val y = (cy + rr * sin(a)).toFloat()
        if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
    }
    p.close(); return p
}

fun heartPath(cx: Float, cy: Float, r: Float): Path = Path().apply {
    moveTo(cx, cy + r * 0.95f)
    cubicTo(cx + r * 1.5f, cy + r * 0.1f, cx + r * 0.95f, cy - r * 1.05f, cx, cy - r * 0.35f)
    cubicTo(cx - r * 0.95f, cy - r * 1.05f, cx - r * 1.5f, cy + r * 0.1f, cx, cy + r * 0.95f)
    close()
}

fun drawArrowShape(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, w: Float, p: Paint) {
    val d = hypot(x2 - x1, y2 - y1); val ux = (x2 - x1) / d; val uy = (y2 - y1) / d
    p.style = Paint.Style.STROKE; p.strokeWidth = w; p.strokeCap = Paint.Cap.ROUND
    c.drawLine(x1, y1, x2 - ux * w, y2 - uy * w, p)
    p.style = Paint.Style.FILL
    val bx = x2 - ux * w * 0.9f; val by = y2 - uy * w * 0.9f; val hw = w * 1.4f
    val path = Path().apply {
        moveTo(x2 + ux * w * 0.9f, y2 + uy * w * 0.9f)
        lineTo(bx - uy * hw, by + ux * hw); lineTo(bx + uy * hw, by - ux * hw); close()
    }
    c.drawPath(path, p)
}

enum class Ic { PAUSE, RESTART, HINT, GRID, BACK }

class IconButton(ctx: Context, private val ic: Ic) : View(ctx) {
    var badge: String? = null; set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = ctx.resources.displayMetrics.density

    init {
        background = GradientDrawable().apply { cornerRadius = 20 * d; setColor(Color.WHITE) }
        elevation = 5 * d; pressable()
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val s = min(width, height) * 0.5f
        p.color = C.INK; p.style = Paint.Style.STROKE; p.strokeWidth = s * 0.15f
        p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
        when (ic) {
            Ic.PAUSE -> {
                p.style = Paint.Style.FILL
                c.drawRoundRect(cx - s * .38f, cy - s * .4f, cx - s * .1f, cy + s * .4f, s * .08f, s * .08f, p)
                c.drawRoundRect(cx + s * .1f, cy - s * .4f, cx + s * .38f, cy + s * .4f, s * .08f, s * .08f, p)
            }
            Ic.RESTART -> {
                val r = s * .42f
                c.drawArc(RectF(cx - r, cy - r, cx + r, cy + r), -50f, 270f, false, p)
                val a = Math.toRadians(220.0)
                val ex = cx + r * cos(a).toFloat(); val ey = cy + r * sin(a).toFloat()
                val tx = -sin(a).toFloat(); val ty = cos(a).toFloat(); val hs = s * .3f
                p.style = Paint.Style.FILL
                c.drawPath(Path().apply {
                    moveTo(ex + tx * hs, ey + ty * hs)
                    lineTo(ex - ty * hs * .8f, ey + tx * hs * .8f); lineTo(ex + ty * hs * .8f, ey - tx * hs * .8f); close()
                }, p)
            }
            Ic.HINT -> {
                p.style = Paint.Style.FILL; p.color = C.GOLD
                c.drawCircle(cx, cy - s * .1f, s * .36f, p)
                p.color = C.INK
                c.drawRoundRect(cx - s * .19f, cy + s * .22f, cx + s * .19f, cy + s * .42f, s * .08f, s * .08f, p)
            }
            Ic.GRID -> {
                for (o in floatArrayOf(-.17f, .17f)) {
                    c.drawLine(cx + s * o, cy - s * .4f, cx + s * o, cy + s * .4f, p)
                    c.drawLine(cx - s * .4f, cy + s * o, cx + s * .4f, cy + s * o, p)
                }
            }
            Ic.BACK -> c.drawPath(Path().apply {
                moveTo(cx + s * .14f, cy - s * .4f); lineTo(cx - s * .2f, cy); lineTo(cx + s * .14f, cy + s * .4f)
            }, p)
        }
        badge?.let {
            p.style = Paint.Style.FILL; p.textSize = 10 * d; p.typeface = Typeface.DEFAULT_BOLD; p.textAlign = Paint.Align.CENTER
            val tw = p.measureText(it) + 12 * d
            val r = RectF(width - tw - 2 * d, 2 * d, width - 2 * d, 20 * d)
            p.color = C.BLUE; c.drawRoundRect(r, 9 * d, 9 * d, p)
            p.color = Color.WHITE; c.drawText(it, r.centerX(), r.centerY() + 3.6f * d, p)
        }
    }
}

class HeartsView(ctx: Context) : View(ctx) {
    private var lives = 3; private var popI = -1; private var t = 1f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = ctx.resources.displayMetrics.density

    fun setLives(n: Int) {
        if (n < lives) {
            popI = n
            ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 450; addUpdateListener { t = it.animatedValue as Float; invalidate() }; start()
            }
        }
        lives = n; invalidate()
    }

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension((3 * 40 * d).toInt(), (38 * d).toInt())

    override fun onDraw(c: Canvas) {
        for (i in 0..2) {
            val k = if (i == popI && t < 1f) 1f + 0.45f * sin(PI.toFloat() * t) else 1f
            p.color = if (i < lives) C.RED else 0xFFCBD3E6.toInt()
            c.drawPath(heartPath((20 + 40 * i) * d, 19 * d, 13 * d * k), p)
        }
    }
}

class ProgressView(ctx: Context) : View(ctx) {
    private var shown = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    fun set(target: Float, animate: Boolean = true) {
        if (!animate) { shown = target; invalidate(); return }
        ValueAnimator.ofFloat(shown, target).apply {
            duration = 350; addUpdateListener { shown = it.animatedValue as Float; invalidate() }; start()
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        p.shader = null; p.color = 0x1F1F2A44
        c.drawRoundRect(0f, 0f, w, h, h / 2, h / 2, p)
        if (shown > 0.001f) {
            p.shader = LinearGradient(0f, 0f, w, 0f, C.BLUE, C.VIOLET, Shader.TileMode.CLAMP)
            c.drawRoundRect(0f, 0f, max(h, w * shown), h, h / 2, h / 2, p); p.shader = null
        }
    }
}

class StarsView(ctx: Context, private val n: Int) : View(ctx) {
    private var v = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { pathEffect = CornerPathEffect(6f) }
    private val ease = OvershootInterpolator(2.5f)
    private val d = ctx.resources.displayMetrics.density

    init {
        ValueAnimator.ofFloat(0f, 3f).apply {
            startDelay = 250; duration = 1100; addUpdateListener { v = it.animatedValue as Float; invalidate() }; start()
        }
    }

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension((3 * 70 * d).toInt(), (74 * d).toInt())

    override fun onDraw(c: Canvas) {
        for (i in 0..2) {
            val cx = (35 + 70 * i) * d; val cy = 38 * d
            p.color = 0xFFDDE3F2.toInt(); c.drawPath(starPath(cx, cy, 28 * d), p)
            if (i < n && v > i) {
                val sc = ease.getInterpolation((v - i).coerceIn(0f, 1f))
                p.color = C.GOLD; c.drawPath(starPath(cx, cy, 28 * d * sc), p)
            }
        }
    }
}

class BackgroundView(ctx: Context) : View(ctx) {
    private class Item(val x: Float, val ph: Float, val sp: Float, val sz: Float, val col: Int, val rot: Float)
    private val rnd = java.util.Random(7)
    private val items = List(14) {
        Item(rnd.nextFloat(), rnd.nextFloat(), 0.02f + rnd.nextFloat() * 0.04f, 0.6f + rnd.nextFloat(), C.PALETTE[it % 6], (rnd.nextFloat() - .5f) * 60f)
    }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = ctx.resources.displayMetrics.density

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, 0f, h, C.BG1, C.BG2, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p); p.shader = null
        val t = System.nanoTime() / 1e9f
        for (i in items) {
            val y = h + 60 * d - ((t * i.sp + i.ph) % 1f) * (h + 120 * d)
            c.save(); c.translate(i.x * w, y); c.rotate(i.rot)
            p.color = (i.col and 0x00FFFFFF) or 0x33000000
            drawArrowShape(c, 0f, 34 * d * i.sz, 0f, -34 * d * i.sz, 8 * d * i.sz, p)
            c.restore()
        }
        postInvalidateOnAnimation()
    }
}

class TitleView(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(MeasureSpec.getSize(w), (270 * d).toInt())

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val s = 100 * d
        val r = RectF(cx - s / 2, 8 * d, cx + s / 2, 8 * d + s)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(r.left, r.top, r.right, r.bottom, C.BLUE, C.VIOLET, Shader.TileMode.CLAMP)
        c.drawRoundRect(r, 30 * d, 30 * d, p); p.shader = null
        p.color = Color.WHITE
        drawArrowShape(c, r.centerX() - s * .2f, r.centerY() + s * .2f, r.centerX() + s * .2f, r.centerY() - s * .2f, s * .11f, p)
        p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.DEFAULT_BOLD
        p.letterSpacing = 0.12f; p.textSize = 44 * d; p.color = C.INK
        c.drawText("ARROW", cx, r.bottom + 62 * d, p)
        p.shader = LinearGradient(cx - 120 * d, 0f, cx + 120 * d, 0f, C.BLUE, C.VIOLET, Shader.TileMode.CLAMP)
        c.drawText("PUZZLE", cx, r.bottom + 112 * d, p); p.shader = null
    }
}
