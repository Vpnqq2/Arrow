package com.example.arrowpuzzle

import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.*

class GameActivity : Activity(), GameView.Listener {
    private lateinit var game: GameView
    private lateinit var levelTv: TextView
    private lateinit var remainTv: TextView
    private lateinit var coinTv: TextView
    private lateinit var hearts: HeartsView
    private lateinit var progress: ProgressView
    private lateinit var hintBtn: IconButton
    private lateinit var prefs: Prefs
    private var level = 1
    private var daily = false
    private var hintsUsed = 0
    private val maxLevel = 500
    private val hintCost = 25

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        styleBars()
        prefs = Prefs(this); Sfx.enabled = prefs.sound
        level = intent.getIntExtra("level", 1); daily = intent.getBooleanExtra("daily", false)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = bgGradient(); setPadding(dp(16), dp(14), dp(16), dp(16))
        }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val pause = IconButton(this, Ic.PAUSE)
        levelTv = TextView(this).apply {
            textSize = 20f; typeface = Typeface.DEFAULT_BOLD; setTextColor(C.INK); gravity = Gravity.CENTER; letterSpacing = 0.08f
        }
        val (pill, tv) = coinPill(); coinTv = tv
        top.addView(pause, LinearLayout.LayoutParams(dp(48), dp(48)))
        top.addView(levelTv, LinearLayout.LayoutParams(0, -2, 1f)); top.addView(pill)
        root.addView(top)

        hearts = HeartsView(this)
        root.addView(hearts, LinearLayout.LayoutParams(-2, -2).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(10) })

        val prow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        progress = ProgressView(this)
        remainTv = TextView(this).apply { textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setTextColor(C.MUTED); gravity = Gravity.END }
        prow.addView(progress, LinearLayout.LayoutParams(0, dp(12), 1f))
        prow.addView(remainTv, LinearLayout.LayoutParams(dp(44), -2))
        root.addView(prow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        game = GameView(this).apply { listener = this@GameActivity; sound = prefs.sound; haptics = prefs.haptics }
        root.addView(game, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(8); bottomMargin = dp(8) })

        val bottom = LinearLayout(this).apply { gravity = Gravity.CENTER }
        val restart = IconButton(this, Ic.RESTART)
        hintBtn = IconButton(this, Ic.HINT)
        val grid = IconButton(this, Ic.GRID)
        for (v in listOf(restart, hintBtn, grid))
            bottom.addView(v, LinearLayout.LayoutParams(dp(68), dp(68)).apply { setMargins(dp(10), 0, dp(10), 0) })
        root.addView(bottom)
        setContentView(root)

        pause.setOnClickListener { showPause() }
        restart.setOnClickListener { startLevel(level) }
        grid.setOnClickListener { game.showGrid = !game.showGrid }
        hintBtn.setOnClickListener {
            val free = hintsUsed == 0
            if (!free && prefs.coins < hintCost) {
                Sfx.tone(260f, 120f, 200); Toast.makeText(this, "Not enough coins", Toast.LENGTH_SHORT).show()
            } else if (game.hint()) {
                if (!free) prefs.coins -= hintCost
                hintsUsed++; refreshHud()
            }
        }
        game.post {
            startLevel(level)
            if (!prefs.seenHelp) {
                prefs.seenHelp = true
                val tvh = TextView(this).apply {
                    text = "•  Tap an arrow to send it flying out of the board.\n•  An arrow only moves if its path is clear.\n" +
                        "•  Tapping a blocked arrow costs a heart.\n•  Clear every arrow to win - fewer mistakes, more stars!"
                    textSize = 15f; setTextColor(C.INK); setLineSpacing(0f, 1.2f)
                }
                Popup.show(this, "How to Play", content = tvh, buttons = listOf(Popup.Btn("Got it!", true)))
            }
        }
    }

    private fun today() = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

    private fun refreshHud() {
        hintBtn.badge = if (hintsUsed == 0) "FREE" else "$hintCost"
        coinTv.text = "${prefs.coins}"
    }

    private fun startLevel(n: Int) {
        level = n; hintsUsed = 0; refreshHud()
        levelTv.text = if (daily) "DAILY" else "LEVEL $n"
        val seed = if (daily) today().toLong() else n * 7919L + 13
        game.load(LevelGen.make(seed, if (daily) 35 else n))
        progress.set(0f, false)
    }

    private fun showPause() {
        Popup.show(this, "Paused", buttons = listOf(
            Popup.Btn("Resume", true),
            Popup.Btn("Restart") { startLevel(level) },
            Popup.Btn("Menu") { finish() }))
    }

    override fun onState(remaining: Int, total: Int, lives: Int) {
        remainTv.text = "$remaining"
        progress.set(if (total == 0) 0f else (total - remaining) / total.toFloat())
        hearts.setLives(lives)
    }

    override fun onWin(lives: Int) {
        val reward = if (daily) 30 else lives * 10
        prefs.coins += reward; refreshHud()
        if (daily) prefs.dailyDone = today()
        else { prefs.setStars(level, lives); if (level + 1 > prefs.unlocked) prefs.unlocked = minOf(level + 1, maxLevel) }
        val btns = mutableListOf<Popup.Btn>()
        if (!daily && level < maxLevel) btns.add(Popup.Btn("Next Level", true) { startLevel(level + 1) })
        btns.add(Popup.Btn("Replay") { startLevel(level) })
        btns.add(Popup.Btn("Menu") { finish() })
        Popup.show(this, "Level Complete!", "+$reward coins", stars = lives, cancelable = false, buttons = btns)
    }

    override fun onLose() {
        Popup.show(this, "Out of Lives", "Don't give up - try again!", cancelable = false, buttons = listOf(
            Popup.Btn("Try Again", true) { startLevel(level) },
            Popup.Btn("Menu") { finish() }))
    }
}
