package com.example.arrowpuzzle

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.*

class GameActivity : Activity(), GameView.Listener {
    private lateinit var game: GameView
    private lateinit var levelTv: TextView
    private lateinit var remainTv: TextView
    private lateinit var coinTv: TextView
    private lateinit var hearts: HeartsView
    private lateinit var progress: ProgressView
    private lateinit var hintBtn: IconButton
    private lateinit var prefs: Prefs
    private var level = 1
    private var daily = false
    private var hintsUsed = 0
    private val maxLevel = 500
    private val hintCost = 25

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        styleBars()
        prefs = Prefs(this); Sfx.enabled = prefs.sound
        level = intent.getIntExtra("level", 1); daily = intent.getBooleanExtra("daily", false)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = bgGradient(); setPadding(dp(18), dp(12), dp(18), dp(20))
        }
        val top = FrameLayout(this)
        val pause = IconButton(this, Ic.PAUSE)
        top.addView(pause, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.START or Gravity.CENTER_VERTICAL))
        levelTv = TextView(this).apply { textSize = 22f; typeface = medium(); setTextColor(C.INK); letterSpacing = 0.1f }
        top.addView(levelTv, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        val (pill, tv) = coinPill(); coinTv = tv
        top.addView(pill, FrameLayout.LayoutParams(-2, -2, Gravity.END or Gravity.CENTER_VERTICAL))
        root.addView(top, LinearLayout.LayoutParams(-1, dp(48)))

        hearts = HeartsView(this)
        root.addView(hearts, LinearLayout.LayoutParams(-2, -2).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(8) })

        val prow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        progress = ProgressView(this)
        remainTv = TextView(this).apply { textSize = 17f; typeface = medium(); setTextColor(C.MUTED); gravity = Gravity.END }
        prow.addView(progress, LinearLayout.LayoutParams(0, dp(8), 1f))
        prow.addView(remainTv, LinearLayout.LayoutParams(dp(44), -2))
        root.addView(prow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

        game = GameView(this).apply { listener = this@GameActivity; sound = prefs.sound; haptics = prefs.haptics }
        root.addView(game, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(16); bottomMargin = dp(16) })

        val bottom = LinearLayout(this).apply { gravity = Gravity.CENTER }
        val restart = IconButton(this, Ic.RESTART)
        hintBtn = IconButton(this, Ic.HINT)
        val grid = IconButton(this, Ic.GRID)
        for (v in listOf(restart, hintBtn, grid))
            bottom.addView(v, LinearLayout.LayoutParams(dp(54), dp(54)).apply { setMargins(dp(11), 0, dp(11), 0) })
        root.addView(bottom)
        setContentView(root)

        pause.setOnClickListener { showPause() }
        restart.setOnClickListener { startLevel(level) }
        grid.setOnClickListener { game.showGrid = !game.showGrid }
        hintBtn.setOnClickListener {
            val free = hintsUsed == 0
            if (!free && prefs.coins < hintCost) {
                Sfx.tone(260f, 120f, 200); Toast.makeText(this, "Not enough coins", Toast.LENGTH_SHORT).show()
            } else if (game.hint()) {
                if (!free) prefs.coins -= hintCost
                hintsUsed++; refreshHud()
            }
        }
        game.post {
            startLevel(level)
            if (!prefs.seenHelp) {
                prefs.seenHelp = true
                val tvh = TextView(this).apply {
                    text = "•  Tap an arrow to send it flying out of the board.\n•  An arrow only moves if its path is clear.\n" +
                        "•  Tapping a blocked arrow costs a heart.\n•  Clear every arrow to win - fewer mistakes, more stars!"
                    textSize = 15f; setTextColor(C.INK); setLineSpacing(0f, 1.2f)
                }
                Popup.show(this, "How to Play", icon = Ic.HINT, content = tvh, buttons = listOf(Popup.Btn("Got it!", true, Ic.CHECK)))
            }
        }
    }

    private fun today() = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

    private fun refreshHud() {
        hintBtn.badge = if (hintsUsed == 0) "FREE" else "$hintCost"
        coinTv.text = "${prefs.coins}"
    }

    private fun startLevel(n: Int) {
        level = n; hintsUsed = 0; refreshHud()
        levelTv.text = if (daily) "DAILY" else "LEVEL $n"
        val seed = if (daily) today().toLong() else n * 7919L + 13
        game.load(if (daily) LevelGen.make(seed, 35, today().takeLast(2).toInt()) else LevelGen.make(seed, n))
        progress.set(0f, false)
    }

    private fun showPause() {
        Popup.show(this, "Paused", icon = Ic.PAUSE, buttons = listOf(
            Popup.Btn("Resume", true, Ic.PLAY),
            Popup.Btn("Restart", false, Ic.RESTART) { startLevel(level) },
            Popup.Btn("Menu", false, Ic.MENU) { finish() }))
    }

    override fun onState(remaining: Int, total: Int, lives: Int) {
        remainTv.text = "$remaining"
        progress.set(if (total == 0) 0f else (total - remaining) / total.toFloat())
        hearts.setLives(lives)
    }

    override fun onWin(lives: Int) {
        val reward = if (daily) 30 else lives * 10
        prefs.coins += reward; refreshHud()
        if (daily) prefs.dailyDone = today()
        else { prefs.setStars(level, lives); if (level + 1 > prefs.unlocked) prefs.unlocked = minOf(level + 1, maxLevel) }
        val btns = mutableListOf<Popup.Btn>()
        if (!daily && level < maxLevel) btns.add(Popup.Btn("Next Level", true, Ic.PLAY) { startLevel(level + 1) })
        btns.add(Popup.Btn("Replay", false, Ic.RESTART) { startLevel(level) })
        btns.add(Popup.Btn("Menu", false, Ic.MENU) { finish() })
        Popup.show(this, "Level Complete!", "+$reward coins", stars = lives, cancelable = false, buttons = btns)
    }

    override fun onLose() {
        Popup.show(this, "Out of Lives", "Don't give up - try again!", icon = Ic.HEART, cancelable = false, buttons = listOf(
            Popup.Btn("Try Again", true, Ic.RESTART) { startLevel(level) },
            Popup.Btn("Menu", false, Ic.MENU) { finish() }))
    }
}
