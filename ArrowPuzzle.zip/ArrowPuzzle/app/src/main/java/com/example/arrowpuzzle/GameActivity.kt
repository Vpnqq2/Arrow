package com.example.arrowpuzzle

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.*

class GameActivity : Activity(), GameView.Listener {
    private lateinit var game: GameView
    private lateinit var remainingTv: TextView
    private lateinit var heartsTv: TextView
    private lateinit var levelTv: TextView
    private lateinit var hintBtn: TextView
    private lateinit var prefs: Prefs
    private var level = 1
    private var daily = false
    private var hints = 3

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = Prefs(this)
        level = intent.getIntExtra("level", 1)
        daily = intent.getBooleanExtra("daily", false)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE)
            setPadding(dp(12), dp(28), dp(12), dp(16))
        }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val pause = pill("⏸"); remainingTv = pill("➚ 0"); levelTv = pill("")
        heartsTv = TextView(this).apply { textSize = 22f; gravity = Gravity.CENTER }
        top.addView(pause); top.addView(remainingTv, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })
        top.addView(heartsTv, LinearLayout.LayoutParams(0, -2, 1f)); top.addView(levelTv)
        root.addView(top)

        game = GameView(this).apply { listener = this@GameActivity }
        root.addView(game, LinearLayout.LayoutParams(-1, 0, 1f))

        val bottom = LinearLayout(this).apply { gravity = Gravity.CENTER }
        val restart = pill("⟳", 26f); hintBtn = pill("💡 3", 22f); val grid = pill("#", 26f)
        for (v in listOf(restart, hintBtn, grid))
            bottom.addView(v, LinearLayout.LayoutParams(dp(92), dp(60)).apply { setMargins(dp(8), 0, dp(8), 0) })
        root.addView(bottom)
        setContentView(root)

        pause.setOnClickListener {
            AlertDialog.Builder(this).setTitle("Paused")
                .setPositiveButton("Resume", null)
                .setNeutralButton("Restart") { _, _ -> startLevel(level) }
                .setNegativeButton("Menu") { _, _ -> finish() }.show()
        }
        restart.setOnClickListener { startLevel(level) }
        grid.setOnClickListener { game.showGrid = !game.showGrid }
        hintBtn.setOnClickListener {
            if (hints > 0 && game.hint()) { hints--; hintBtn.text = "💡 $hints" }
        }
        game.post { startLevel(level) }
    }

    private fun today() = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

    private fun startLevel(n: Int) {
        level = n; hints = 3; hintBtn.text = "💡 3"
        levelTv.text = if (daily) "Daily" else "Level $n"
        val seed = if (daily) today().toLong() else n * 7919L + 13
        val diff = if (daily) 35 else n
        game.load(LevelGen.make(seed, diff))
    }

    override fun onState(remaining: Int, lives: Int) {
        remainingTv.text = "➚ $remaining"
        heartsTv.text = "❤️".repeat(lives) + "🖤".repeat(3 - lives)
    }

    override fun onWin() {
        if (daily) prefs.dailyDone = today() else if (level + 1 > prefs.unlocked) prefs.unlocked = level + 1
        val b = AlertDialog.Builder(this).setTitle("🎉 Level Complete!").setCancelable(false)
            .setNegativeButton("Menu") { _, _ -> finish() }
        if (!daily) b.setPositiveButton("Next Level") { _, _ -> startLevel(level + 1) }
        b.show()
    }

    override fun onLose() {
        AlertDialog.Builder(this).setTitle("💔 Out of lives").setCancelable(false)
            .setPositiveButton("Try Again") { _, _ -> startLevel(level) }
            .setNegativeButton("Menu") { _, _ -> finish() }.show()
    }
}
