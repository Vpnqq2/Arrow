package com.example.arrowpuzzle

import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

class GameView(ctx: Context) : View(ctx) {
    interface Listener { fun onState(remaining: Int, lives: Int); fun onWin(); fun onLose() }

    var listener: Listener? = null
    var lives = 3; private set
    var showGrid = false; set(v) { field = v; invalidate() }

    private var level: Level? = null
    private val alive = mutableListOf<Arrow>()
    private var cs = 0f; private var ox = 0f; private var oy = 0f
    private var over = false
    private var last = 0L
    private var hintArrow: Arrow? = null; private var hintUntil = 0L
    private val shakes = HashMap<Arrow, Long>()

    private class Slide(val pts: List<PointF>, val cum: FloatArray, val len: Float, var d: Float)
    private val slides = mutableListOf<Slide>()

    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFD5DCE8.toInt() }

    fun load(l: Level) {
        level = l; alive.clear(); alive.addAll(l.arrows)
        slides.clear(); shakes.clear(); hintArrow = null
        lives = 3; over = false
        layoutBoard(); notifyState(); invalidate()
    }

    fun remaining() = alive.size

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { layoutBoard() }

    private fun layoutBoard() {
        val l = level ?: return
        if (width == 0) return
        cs = min(width / (l.w + 1f), height / (l.h + 1f))
        ox = (width - cs * l.w) / 2f; oy = (height - cs * l.h) / 2f
    }

    private fun pt(c: Pair<Int, Int>) = PointF(ox + (c.first + .5f) * cs, oy + (c.second + .5f) * cs)
    private fun notifyState() { listener?.onState(alive.size, lives) }

    private fun canRemove(a: Arrow): Boolean {
        val l = level ?: return false
        val occ = HashSet<Int>()
        for (o in alive) if (o !== a) for (c in o.cells) occ.add(c.second * 100 + c.first)
        var x = a.cells.last().first + LevelGen.DX[a.dir]
        var y = a.cells.last().second + LevelGen.DY[a.dir]
        while (x in 0 until l.w && y in 0 until l.h) {
            if ((y * 100 + x) in occ) return false
            x += LevelGen.DX[a.dir]; y += LevelGen.DY[a.dir]
        }
        return true
    }

    fun hint(): Boolean {
        val a = alive.firstOrNull { canRemove(it) } ?: return false
        hintArrow = a; hintUntil = SystemClock.uptimeMillis() + 1500; invalidate(); return true
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action != MotionEvent.ACTION_DOWN) return true
        if (over) return true
        var best: Arrow? = null; var bd = cs * 0.45f
        for (a in alive) for (i in 0 until a.cells.size - 1) {
            val d = distSeg(e.x, e.y, pt(a.cells[i]), pt(a.cells[i + 1]))
            if (d < bd) { bd = d; best = a }
        }
        best?.let { tap(it) }
        return true
    }

    private fun distSeg(px: Float, py: Float, a: PointF, b: PointF): Float {
        val vx = b.x - a.x; val vy = b.y - a.y
        val t = (((px - a.x) * vx + (py - a.y) * vy) / (vx * vx + vy * vy)).coerceIn(0f, 1f)
        return hypot(px - (a.x + vx * t), py - (a.y + vy * t))
    }

    private fun tap(a: Arrow) {
        if (canRemove(a)) {
            alive.remove(a); startSlide(a); notifyState()
            if (alive.isEmpty()) { over = true; postDelayed({ listener?.onWin() }, 700) }
        } else {
            lives--; shakes[a] = SystemClock.uptimeMillis(); notifyState()
            if (lives <= 0) { over = true; postDelayed({ listener?.onLose() }, 700) }
        }
        invalidate()
    }

    private fun startSlide(a: Arrow) {
        val l = level!!
        val pts = a.cells.map { pt(it) }.toMutableList()
        var n = 0; var x = a.cells.last().first; var y = a.cells.last().second
        while (x in 0 until l.w && y in 0 until l.h) { x += LevelGen.DX[a.dir]; y += LevelGen.DY[a.dir]; n++ }
        val h = pts.last()
        val bodyLen = cumLen(pts).last()
        pts.add(PointF(h.x + LevelGen.DX[a.dir] * (n + 1) * cs, h.y + LevelGen.DY[a.dir] * (n + 1) * cs))
        slides.add(Slide(pts, cumLen(pts), bodyLen, 0f))
    }

    private fun cumLen(p: List<PointF>): FloatArray {
        val c = FloatArray(p.size)
        for (i in 1 until p.size) c[i] = c[i - 1] + hypot(p[i].x - p[i - 1].x, p[i].y - p[i - 1].y)
        return c
    }

    private fun slice(p: List<PointF>, cum: FloatArray, a: Float, b: Float): List<PointF> {
        fun at(s0: Float): PointF {
            val s = s0.coerceIn(0f, cum.last())
            var i = 1
            while (i < cum.size - 1 && cum[i] < s) i++
            val t = ((s - cum[i - 1]) / max(cum[i] - cum[i - 1], 1e-3f)).coerceIn(0f, 1f)
            return PointF(p[i - 1].x + (p[i].x - p[i - 1].x) * t, p[i - 1].y + (p[i].y - p[i - 1].y) * t)
        }
        val out = arrayListOf(at(a))
        for (i in 1 until cum.size - 1) if (cum[i] > a && cum[i] < b) out.add(PointF(p[i].x, p[i].y))
        out.add(at(b))
        return out
    }

    private fun drawArrow(p: List<PointF>, color: Int, dx: Float = 0f) {
        if (p.size < 2) return
        line.color = color; fill.color = color; line.strokeWidth = cs * 0.13f
        val path = Path()
        p.forEachIndexed { i, q -> if (i == 0) path.moveTo(q.x + dx, q.y) else path.lineTo(q.x + dx, q.y) }
        canvas?.drawPath(path, line)
        val e = p.last(); var s = p[p.size - 2]
        var k = p.size - 2
        while (k > 0 && hypot(e.x - s.x, e.y - s.y) < 1f) { k--; s = p[k] }
        val d = hypot(e.x - s.x, e.y - s.y); if (d < 1f) return
        val ux = (e.x - s.x) / d; val uy = (e.y - s.y) / d
        val tipX = e.x + dx + ux * cs * 0.30f; val tipY = e.y + uy * cs * 0.30f
        val bx = e.x + dx - ux * cs * 0.05f; val by = e.y - uy * cs * 0.05f
        val hw = cs * 0.22f
        val tri = Path().apply {
            moveTo(tipX, tipY); lineTo(bx - uy * hw, by + ux * hw); lineTo(bx + uy * hw, by - ux * hw); close()
        }
        canvas?.drawPath(tri, fill)
    }

    private var canvas: Canvas? = null

    override fun onDraw(c: Canvas) {
        canvas = c
        val l = level ?: return
        val now = SystemClock.uptimeMillis()
        val dt = if (last == 0L) 0f else min((now - last) / 1000f, 0.05f)
        last = now
        c.clipRect(0, 0, width, height)
        if (showGrid) for (y in 0 until l.h) for (x in 0 until l.w) {
            val q = pt(Pair(x, y)); c.drawCircle(q.x, q.y, cs * 0.06f, dot)
        }
        var animating = false
        for (a in alive) {
            var color = 0xFF111111.toInt(); var dx = 0f
            val sh = shakes[a]
            if (sh != null) {
                val t = now - sh
                if (t < 450) { color = 0xFFE53935.toInt(); dx = sin(t / 30f) * cs * 0.10f; animating = true } else shakes.remove(a)
            }
            if (a === hintArrow && now < hintUntil) { color = 0xFF2196F3.toInt(); animating = true }
            drawArrow(a.cells.map { pt(it) }, color, dx)
        }
        val it = slides.iterator()
        while (it.hasNext()) {
            val s = it.next()
            s.d += cs * 20f * dt
            val total = s.cum.last()
            if (s.d >= total) { it.remove(); continue }
            drawArrow(slice(s.pts, s.cum, s.d, min(s.d + s.len, total)), 0xFF111111.toInt())
            animating = true
        }
        if (animating) postInvalidateOnAnimation() else last = 0L
    }
}
