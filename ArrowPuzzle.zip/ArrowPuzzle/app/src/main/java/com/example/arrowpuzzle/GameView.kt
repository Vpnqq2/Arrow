package com.example.arrowpuzzle

import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.animation.OvershootInterpolator
import kotlin.math.*
import kotlin.random.Random

class GameView(ctx: Context) : View(ctx) {
    interface Listener { fun onState(remaining: Int, total: Int, lives: Int); fun onWin(lives: Int); fun onLose() }

    var listener: Listener? = null
    var lives = 3; private set
    var showGrid = false; set(v) { field = v; invalidate() }
    var sound = true; var haptics = true

    private var level: Level? = null
    private val alive = mutableListOf<Arrow>()
    private val order = HashMap<Arrow, Int>()
    private var total = 0
    private var cs = 0f; private var ox = 0f; private var oy = 0f
    private var over = false; private var last = 0L; private var loadT = 0L; private var combo = 0
    private var hintArrow: Arrow? = null; private var hintUntil = 0L; private var flashUntil = 0L
    private val shakes = HashMap<Arrow, Long>()
    private val ease = OvershootInterpolator(2f)

    private class Slide(val pts: List<PointF>, val cum: FloatArray, val len: Float, var d: Float, var v: Float, val color: Int)
    private class Part(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Float,
                       val max: Float, val color: Int, val size: Float, val g: Float)
    private val slides = mutableListOf<Slide>()
    private val parts = mutableListOf<Part>()

    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val cardR = RectF()

    fun load(l: Level) {
        level = l; alive.clear(); alive.addAll(l.arrows)
        order.clear(); l.arrows.forEachIndexed { i, a -> order[a] = i }
        total = l.arrows.size
        slides.clear(); parts.clear(); shakes.clear(); hintArrow = null
        lives = 3; over = false; combo = 0; loadT = SystemClock.uptimeMillis()
        layoutBoard(); notifyState(); invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { layoutBoard() }

    private fun layoutBoard() {
        val l = level ?: return
        if (width == 0) return
        cs = min(width / (l.w + 1f), height / (l.h + 1f))
        ox = (width - cs * l.w) / 2f; oy = (height - cs * l.h) / 2f
        cardR.set(ox - cs * .45f, oy - cs * .45f, ox + cs * l.w + cs * .45f, oy + cs * l.h + cs * .45f)
    }

    private fun pt(c: Pair<Int, Int>) = PointF(ox + (c.first + .5f) * cs, oy + (c.second + .5f) * cs)
    private fun notifyState() { listener?.onState(alive.size, total, lives) }
    private fun col(a: Arrow) = C.PALETTE[(order[a] ?: 0) % C.PALETTE.size]

    private fun canRemove(a: Arrow): Boolean {
        val l = level ?: return false
        val occ = HashSet<Int>()
        for (o in alive) if (o !== a) for (c in o.cells) occ.add(c.second * 100 + c.first)
        var x = a.cells.last().first + LevelGen.DX[a.dir]; var y = a.cells.last().second + LevelGen.DY[a.dir]
        while (x in 0 until l.w && y in 0 until l.h) {
            if ((y * 100 + x) in occ) return false
            x += LevelGen.DX[a.dir]; y += LevelGen.DY[a.dir]
        }
        return true
    }

    fun hint(): Boolean {
        val a = alive.firstOrNull { canRemove(it) } ?: return false
        hintArrow = a; hintUntil = SystemClock.uptimeMillis() + 1800; invalidate(); return true
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action != MotionEvent.ACTION_DOWN || over) return true
        var best: Arrow? = null; var bd = cs * 0.45f
        for (a in alive) for (i in 0 until a.cells.size - 1) {
            val d = distSeg(e.x, e.y, pt(a.cells[i]), pt(a.cells[i + 1]))
            if (d < bd) { bd = d; best = a }
        }
        best?.let { tap(it) }
        return true
    }

    private fun distSeg(px: Float, py: Float, a: PointF, b: PointF): Float {
        val vx = b.x - a.x; val vy = b.y - a.y
        val t = (((px - a.x) * vx + (py - a.y) * vy) / (vx * vx + vy * vy)).coerceIn(0f, 1f)
        return hypot(px - (a.x + vx * t), py - (a.y + vy * t))
    }

    private fun tap(a: Arrow) {
        val now = SystemClock.uptimeMillis()
        if (canRemove(a)) {
            combo++
            val c = col(a)
            alive.remove(a); startSlide(a, c); burst(a, c)
            if (sound) Sfx.tone(440f + 40f * min(combo, 12), 760f + 40f * min(combo, 12), 110)
            if (haptics) performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            notifyState()
            if (alive.isEmpty()) {
                over = true; confetti(); if (sound) Sfx.win()
                postDelayed({ listener?.onWin(lives) }, 1100)
            }
        } else {
            combo = 0; lives--; shakes[a] = now; flashUntil = now + 350
            if (sound) Sfx.tone(260f, 110f, 260)
            if (haptics) performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            notifyState()
            if (lives <= 0) { over = true; postDelayed({ listener?.onLose() }, 800) }
        }
        invalidate()
    }

    private fun startSlide(a: Arrow, color: Int) {
        val l = level!!
        val pts = a.cells.map { pt(it) }.toMutableList()
        var n = 0; var x = a.cells.last().first; var y = a.cells.last().second
        while (x in 0 until l.w && y in 0 until l.h) { x += LevelGen.DX[a.dir]; y += LevelGen.DY[a.dir]; n++ }
        val h = pts.last(); val bodyLen = cumLen(pts).last()
        pts.add(PointF(h.x + LevelGen.DX[a.dir] * (n + 1) * cs, h.y + LevelGen.DY[a.dir] * (n + 1) * cs))
        slides.add(Slide(pts, cumLen(pts), bodyLen, 0f, cs * 5f, color))
    }

    private fun burst(a: Arrow, color: Int) {
        val h = pt(a.cells.last())
        val base = atan2(LevelGen.DY[a.dir].toFloat(), LevelGen.DX[a.dir].toFloat())
        repeat(10) {
            val ang = base + (Random.nextFloat() - .5f) * 2.2f; val sp = cs * (3f + Random.nextFloat() * 5f)
            val life = .5f + Random.nextFloat() * .3f
            parts.add(Part(h.x, h.y, cos(ang) * sp, sin(ang) * sp, life, life, color, cs * (.05f + Random.nextFloat() * .06f), 0f))
        }
    }

    private fun confetti() {
        repeat(90) {
            val life = 1.6f + Random.nextFloat() * 1.2f
            parts.add(Part(Random.nextFloat() * width, -cs * Random.nextFloat() * 3, (Random.nextFloat() - .5f) * cs * 3,
                cs * (3f + Random.nextFloat() * 4f), life, life, C.PALETTE[Random.nextInt(C.PALETTE.size)],
                cs * (.1f + Random.nextFloat() * .1f), cs * 6f))
        }
    }

    private fun cumLen(p: List<PointF>): FloatArray {
        val c = FloatArray(p.size)
        for (i in 1 until p.size) c[i] = c[i - 1] + hypot(p[i].x - p[i - 1].x, p[i].y - p[i - 1].y)
        return c
    }

    private fun slice(p: List<PointF>, cum: FloatArray, a: Float, b: Float): List<PointF> {
        fun at(s0: Float): PointF {
            val s = s0.coerceIn(0f, cum.last()); var i = 1
            while (i < cum.size - 1 && cum[i] < s) i++
            val t = ((s - cum[i - 1]) / max(cum[i] - cum[i - 1], 1e-3f)).coerceIn(0f, 1f)
            return PointF(p[i - 1].x + (p[i].x - p[i - 1].x) * t, p[i - 1].y + (p[i].y - p[i - 1].y) * t)
        }
        val out = arrayListOf(at(a))
        for (i in 1 until cum.size - 1) if (cum[i] > a && cum[i] < b) out.add(PointF(p[i].x, p[i].y))
        out.add(at(b)); return out
    }

    private fun drawArrow(c: Canvas, p: List<PointF>, color: Int, dx: Float = 0f) {
        if (p.size < 2) return
        line.strokeWidth = cs * 0.14f
        val path = Path()
        p.forEachIndexed { i, q -> if (i == 0) path.moveTo(q.x, q.y) else path.lineTo(q.x, q.y) }
        c.save(); c.translate(dx, 0f)
        line.color = 0x26000000; c.save(); c.translate(0f, cs * 0.05f); c.drawPath(path, line); c.restore()
        line.color = color; fill.color = color; c.drawPath(path, line)
        val e = p.last(); var k = p.size - 2; var s = p[k]
        while (k > 0 && hypot(e.x - s.x, e.y - s.y) < 1f) { k--; s = p[k] }
        val d = hypot(e.x - s.x, e.y - s.y)
        if (d >= 1f) {
            val ux = (e.x - s.x) / d; val uy = (e.y - s.y) / d
            val bx = e.x - ux * cs * .02f; val by = e.y - uy * cs * .02f; val hw = cs * .24f
            c.drawPath(Path().apply {
                moveTo(e.x + ux * cs * .34f, e.y + uy * cs * .34f)
                lineTo(bx - uy * hw, by + ux * hw); lineTo(bx + uy * hw, by - ux * hw); close()
            }, fill)
        }
        c.restore()
    }

    override fun onDraw(c: Canvas) {
        val l = level ?: return
        val now = SystemClock.uptimeMillis()
        val dt = if (last == 0L) 0f else min((now - last) / 1000f, 0.05f)
        last = now
        var animating = false

        for (i in 3 downTo 1) {
            fill.color = Color.argb(10, 31, 42, 68)
            val r = RectF(cardR); r.inset(-i * cs * .05f, -i * cs * .05f); r.offset(0f, i * cs * .07f)
            c.drawRoundRect(r, cs * .5f, cs * .5f, fill)
        }
        fill.color = Color.WHITE; c.drawRoundRect(cardR, cs * .5f, cs * .5f, fill)
        if (now < flashUntil) {
            fill.color = Color.argb((70 * (flashUntil - now) / 350f).toInt(), 255, 84, 112)
            c.drawRoundRect(cardR, cs * .5f, cs * .5f, fill); animating = true
        }
        if (showGrid) {
            fill.color = 0xFFD5DCE8.toInt()
            for (y in 0 until l.h) for (x in 0 until l.w) { val q = pt(Pair(x, y)); c.drawCircle(q.x, q.y, cs * .06f, fill) }
        }

        for (a in alive) {
            var color = col(a); var dx = 0f
            shakes[a]?.let {
                val t = now - it
                if (t < 450) { color = C.RED; dx = sin(t / 30f) * cs * .10f; animating = true } else shakes.remove(a)
            }
            if (a === hintArrow && now < hintUntil) {
                if (((now / 160).toInt() and 1) == 0) color = C.BLUE
                animating = true
            }
            val sp = ((now - loadT) - (order[a] ?: 0) * 18L) / 280f
            val sc = if (sp >= 1f) 1f else ease.getInterpolation(sp.coerceIn(0f, 1f))
            if (sp < 1f) animating = true
            if (sc < 0.01f) continue
            val pts = a.cells.map { pt(it) }
            if (sc != 1f) {
                val m = pts[pts.size / 2]; c.save(); c.scale(sc, sc, m.x, m.y); drawArrow(c, pts, color, dx); c.restore()
            } else drawArrow(c, pts, color, dx)
        }

        val it = slides.iterator()
        while (it.hasNext()) {
            val s = it.next()
            s.v += cs * 70f * dt; s.d += s.v * dt
            val tot = s.cum.last()
            if (s.d >= tot) { it.remove(); continue }
            drawArrow(c, slice(s.pts, s.cum, s.d, min(s.d + s.len, tot)), s.color)
            animating = true
        }

        val pi = parts.iterator()
        while (pi.hasNext()) {
            val p = pi.next()
            p.vy += p.g * dt; p.x += p.vx * dt; p.y += p.vy * dt; p.life -= dt
            if (p.life <= 0f || p.y > height + 40) { pi.remove(); continue }
            fill.color = (p.color and 0x00FFFFFF) or ((p.life / p.max).coerceIn(0f, 1f) * 255).toInt().shl(24)
            c.drawCircle(p.x, p.y, p.size, fill); animating = true
        }

        if (animating) postInvalidateOnAnimation() else last = 0L
    }
}
