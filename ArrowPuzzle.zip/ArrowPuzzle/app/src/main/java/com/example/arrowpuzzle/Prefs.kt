package com.example.arrowpuzzle

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("arrow_puzzle", Context.MODE_PRIVATE)
    var unlocked: Int
        get() = sp.getInt("unlocked", 1)
        set(v) = sp.edit().putInt("unlocked", v).apply()
    var dailyDone: String
        get() = sp.getString("daily", "") ?: ""
        set(v) = sp.edit().putString("daily", v).apply()
    var coins: Int
        get() = sp.getInt("coins", 50)
        set(v) = sp.edit().putInt("coins", v).apply()
    var sound: Boolean
        get() = sp.getBoolean("sound", true)
        set(v) = sp.edit().putBoolean("sound", v).apply()
    var haptics: Boolean
        get() = sp.getBoolean("haptics", true)
        set(v) = sp.edit().putBoolean("haptics", v).apply()
    var seenHelp: Boolean
        get() = sp.getBoolean("help", false)
        set(v) = sp.edit().putBoolean("help", v).apply()
    var bonusDay: String
        get() = sp.getString("bonus", "") ?: ""
        set(v) = sp.edit().putString("bonus", v).apply()
    fun stars(n: Int) = sp.getInt("s$n", 0)
    fun setStars(n: Int, v: Int) { if (v > stars(n)) sp.edit().putInt("s$n", v).apply() }
}
