package com.example.arrowpuzzle

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("arrow_puzzle", Context.MODE_PRIVATE)
    var unlocked: Int
        get() = sp.getInt("unlocked", 1)
        set(v) = sp.edit().putInt("unlocked", v).apply()
    var dailyDone: String
        get() = sp.getString("daily", "") ?: ""
        set(v) = sp.edit().putString("daily", v).apply()
}
