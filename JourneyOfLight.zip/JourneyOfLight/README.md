# Journey of Light  (رحلة الضوء)

A calm, mysterious 2D platformer for Android. No combat: just running, jumping,
exploring, and finding hidden secrets, guided by a golden halo.

## Open in Android Studio
1. File > Open > select the `JourneyOfLight` folder.
2. Wait for Gradle sync (it downloads Gradle 8.9 + Android Gradle Plugin 8.7.3 automatically).
3. Run on a device/emulator (landscape, Android 8.0+).

No external libraries and no asset files: everything (graphics, piano music,
wind, crickets, sound effects) is drawn / synthesised in code.

## Controls
- Left side: arrow buttons to move left / right
- Anywhere on the right half: jump (hold = higher jump)
- Top-right speaker icon: mute
- Keyboard (emulator): arrows or A/D to move, Space/W/Up to jump

## Content
1. The Whispering Forest  - 2. Shadow Peaks  - 3. The Heart of Light
Each chapter has light orbs, a checkpoint system, and 2 secret stars
(hidden rooms behind `H` walls, and ghost ledges revealed by your light).

## Where to tweak
- `Levels.kt`  : level layouts (ASCII-like tile builder, legend at the top)
- `Game.kt`    : physics constants (RUN, JUMP, GRAV, BOUNCE)
- `Renderer.kt`: colours (Theme list), halo, fog, parallax layers
- `AudioEngine.kt`: music scales, tempo, volumes
