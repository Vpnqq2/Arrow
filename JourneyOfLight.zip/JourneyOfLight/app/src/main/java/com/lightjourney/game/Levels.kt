package com.lightjourney.game

class Whisper(val x: Float, val y: Float, val text: String)

/**
 * Tile legend:
 *  '#' solid rock        '=' one-way ledge      'g' ghost ledge (revealed by light)
 *  '^' crystal thorns    '*' light orb          's' secret star
 *  'C' checkpoint        'B' bounce mushroom (replaces a ground tile)
 *  'H' hidden wall (walk through)   'r' hidden room interior
 *  'P' player start      'E' exit portal
 */
class LevelData(
    val name: String,
    val theme: Int,
    val w: Int,
    val h: Int,
    val grid: Array<CharArray>,
    val whispers: List<Whisper>,
    val root: Int,
    val scale: IntArray
) {
    var startC = 1
    var startR = 1
    var totalOrbs = 0
    var totalStars = 0

    init {
        for (r in 0 until h) for (c in 0 until w) {
            when (grid[r][c]) {
                'P' -> { startC = c; startR = r; grid[r][c] = ' ' }
                '*' -> totalOrbs++
                's' -> totalStars++
            }
        }
    }
}

private class LB(val w: Int, val h: Int) {
    val g = Array(h) { CharArray(w) { ' ' } }
    val wh = ArrayList<Whisper>()
    fun put(c: Int, r: Int, ch: Char) { if (c in 0 until w && r in 0 until h) g[r][c] = ch }
    fun rect(c1: Int, r1: Int, c2: Int, r2: Int, ch: Char) {
        for (r in r1..r2) for (c in c1..c2) put(c, r, ch)
    }
    fun ground(c1: Int, c2: Int) = rect(c1, h - 2, c2, h - 1, '#')
    fun orbs(c1: Int, c2: Int, r: Int) = rect(c1, r, c2, r, '*')
    fun whisper(c: Int, r: Int, text: String) { wh.add(Whisper(c + 0.5f, r + 0.5f, text)) }
    fun done(name: String, theme: Int, root: Int, scale: IntArray) =
        LevelData(name, theme, w, h, g, wh, root, scale)
}

object Levels {
    private val PENT_MINOR = intArrayOf(0, 3, 5, 7, 10)
    private val DORIAN = intArrayOf(0, 2, 3, 5, 7, 9, 10)
    private val PENT_MAJOR = intArrayOf(0, 2, 4, 7, 9)

    fun all(): List<LevelData> = listOf(forest(), peaks(), heart())

    // ---------------------------------------------------------------- 1
    private fun forest(): LevelData {
        val b = LB(84, 14)
        b.ground(0, 15); b.ground(19, 30); b.ground(35, 54); b.ground(59, 83)
        b.put(2, 11, 'P')
        b.whisper(3, 8, "Follow the light...")
        b.orbs(6, 12, 11)
        b.orbs(16, 18, 9)
        b.orbs(21, 23, 10)
        b.rect(24, 11, 26, 11, '#'); b.orbs(24, 26, 9)
        b.whisper(29, 7, "Even the dark has a gentle side")
        b.put(32, 11, '='); b.put(33, 11, '='); b.orbs(32, 33, 9)
        b.put(38, 11, 'C')
        b.orbs(36, 40, 10)
        b.rect(42, 11, 43, 11, '#')
        b.rect(44, 10, 45, 11, '#')
        b.put(48, 11, '^'); b.put(49, 11, '^'); b.orbs(47, 50, 9)
        b.rect(48, 8, 50, 8, '='); b.put(49, 7, 's')
        b.orbs(52, 53, 11)
        b.put(56, 11, '='); b.put(57, 11, '='); b.orbs(55, 58, 9)
        b.put(60, 11, 'C')
        b.rect(62, 10, 63, 11, '#')
        b.whisper(63, 5, "Some walls are only shadows")
        // secret room
        b.rect(66, 8, 75, 11, '#')
        b.rect(68, 9, 73, 11, 'r')
        b.rect(66, 9, 67, 11, 'H')
        b.put(71, 11, 's'); b.orbs(69, 70, 11); b.orbs(72, 73, 11)
        b.orbs(66, 75, 7)
        b.put(80, 11, 'E')
        return b.done("The Whispering Forest", 0, 57, PENT_MINOR)
    }

    // ---------------------------------------------------------------- 2
    private fun peaks(): LevelData {
        val b = LB(100, 16)
        b.ground(0, 12)
        b.put(2, 13, 'P')
        b.whisper(3, 10, "The mountains remember every step")
        b.orbs(5, 10, 13)
        b.rect(15, 12, 17, 12, '='); b.orbs(15, 17, 11)
        b.rect(20, 10, 22, 10, '='); b.orbs(20, 22, 9)
        b.rect(25, 8, 27, 8, '='); b.orbs(25, 27, 7)
        b.rect(30, 8, 40, 15, '#')
        b.put(31, 7, 'C')
        b.orbs(33, 39, 7)
        b.whisper(31, 2, "Light reveals what is hidden")
        b.rect(33, 6, 34, 6, 'g'); b.orbs(33, 34, 5)
        b.rect(37, 4, 38, 4, 'g'); b.put(38, 3, 's')
        b.rect(41, 10, 44, 15, '#'); b.orbs(41, 44, 9)
        b.rect(45, 12, 48, 15, '#'); b.orbs(45, 48, 11)
        b.ground(49, 60)
        b.orbs(49, 51, 13)
        b.put(53, 13, '^'); b.put(54, 13, '^'); b.put(55, 13, '^'); b.orbs(52, 56, 11)
        b.put(58, 13, 'C')
        b.whisper(55, 8, "Let the mushroom carry you")
        b.put(60, 14, 'B'); b.orbs(61, 65, 9)
        b.ground(66, 99)
        b.put(66, 13, 'C')
        b.put(69, 13, '^'); b.put(70, 13, '^'); b.orbs(68, 71, 11)
        b.rect(72, 12, 74, 15, '#'); b.orbs(72, 74, 11)
        b.rect(77, 10, 80, 15, '#'); b.orbs(77, 80, 9)
        b.rect(83, 8, 95, 15, '#'); b.orbs(83, 95, 7)
        b.whisper(84, 5, "Not every path is lit")
        // secret chamber
        b.rect(88, 11, 92, 13, 'r')
        b.rect(93, 13, 95, 13, 'H')
        b.put(90, 13, 's'); b.orbs(88, 89, 13); b.orbs(91, 92, 13)
        b.put(98, 13, 'E')
        return b.done("Shadow Peaks", 1, 50, DORIAN)
    }

    // ---------------------------------------------------------------- 3
    private fun heart(): LevelData {
        val b = LB(100, 18)
        b.ground(0, 10)
        b.put(2, 15, 'P')
        b.whisper(3, 12, "The heart of light is close")
        b.orbs(5, 9, 15)
        b.rect(13, 14, 14, 14, '='); b.orbs(13, 14, 13)
        b.rect(18, 12, 19, 12, '='); b.orbs(18, 19, 11)
        b.rect(23, 10, 24, 10, '='); b.orbs(23, 24, 9)
        b.rect(28, 12, 29, 12, '='); b.orbs(28, 29, 11)
        b.rect(33, 14, 34, 14, '='); b.orbs(33, 34, 13)
        b.ground(38, 48)
        b.put(40, 15, 'C')
        b.put(43, 15, '^'); b.put(44, 15, '^'); b.put(45, 15, '^'); b.orbs(42, 46, 13)
        b.put(48, 16, 'B')
        b.orbs(49, 53, 11)
        b.ground(54, 99)
        b.put(55, 15, 'C')
        b.rect(58, 14, 60, 14, '='); b.orbs(58, 60, 13)
        b.rect(63, 12, 65, 12, '='); b.orbs(63, 65, 11)
        b.rect(58, 10, 60, 10, '='); b.orbs(58, 60, 9)
        b.rect(63, 8, 65, 8, '='); b.orbs(63, 65, 7)
        b.rect(68, 6, 76, 7, '#')
        b.put(69, 5, 'C')
        b.orbs(70, 76, 5)
        b.whisper(70, 2, "Look higher. Light hides in the sky")
        b.rect(72, 4, 73, 4, 'g')
        b.rect(77, 2, 78, 2, 'g'); b.put(78, 1, 's')
        b.rect(80, 14, 81, 15, '#')
        b.rect(82, 12, 83, 15, '#')
        b.rect(84, 11, 92, 15, '#')
        b.rect(86, 12, 90, 15, 'r')
        b.rect(91, 15, 92, 15, 'H')
        b.put(88, 15, 's'); b.orbs(86, 87, 15); b.orbs(89, 90, 15)
        b.orbs(84, 92, 10)
        b.whisper(93, 11, "You carried the light all along")
        b.put(97, 15, 'E')
        return b.done("The Heart of Light", 2, 55, PENT_MAJOR)
    }
}
