package com.lightjourney.game

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.random.Random

object Sfx {
    const val JUMP = 1
    const val LAND = 2
    const val ORB = 3
    const val STAR = 4
    const val CHECK = 5
    const val BOUNCE = 6
    const val RESPAWN = 7
    const val SECRET = 8
    const val EXIT = 9
}

private val W5 = floatArrayOf(0f, 1f, 0.5f, 0.28f, 0.16f, 0.09f)
private val BR = floatArrayOf(1f, 2.76f, 5.4f, 8.93f)
private val BW = floatArrayOf(1f, 0.55f, 0.3f, 0.15f)

/**
 * Fully procedural audio: soft piano notes, pads, wind and crickets are
 * synthesised in real time, so the project needs no audio asset files.
 */
class AudioEngine {
    private val sr = 22050
    private var thread: Thread? = null
    @Volatile private var running = false
    @Volatile var muted = false
    @Volatile private var theme = 0
    @Volatile private var root = 57
    @Volatile private var scale = intArrayOf(0, 3, 5, 7, 10)
    private val sfxQueue = ConcurrentLinkedQueue<Int>()

    fun setMood(theme: Int, root: Int, scale: IntArray) {
        this.theme = theme
        this.root = root
        this.scale = scale
    }

    fun sfx(id: Int) {
        if (!muted && running) sfxQueue.add(id)
    }

    @Synchronized
    fun start() {
        if (running) return
        running = true
        thread = Thread({ runLoop() }, "light-audio").also { it.start() }
    }

    @Synchronized
    fun stop() {
        running = false
        try { thread?.join(800) } catch (_: InterruptedException) {}
        thread = null
        sfxQueue.clear()
    }

    private class Voice(
        val kind: Int,
        val f: Float,
        val amp: Float,
        val decay: Float,
        val f2: Float = f,
        val dur: Float = 1f,
        delay: Int = 0
    ) {
        var age = 0f
        var wait = delay
        var alive = true
        val ph = FloatArray(6)
        var lp = 0f

        fun next(dt: Float, rnd: Random): Float {
            if (wait > 0) { wait--; return 0f }
            age += dt
            var out = 0f
            when (kind) {
                0 -> { // piano
                    val env = if (age < 0.006f) age / 0.006f else exp(-decay * (age - 0.006f))
                    if (age > 0.2f && env < 0.001f) alive = false
                    for (k in 1..5) {
                        ph[k] += TAU * f * k * (1f + 0.0006f * k * k) * dt
                        if (ph[k] > TAU) ph[k] -= TAU
                        out += sin(ph[k]) * W5[k] * exp(-age * 0.9f * (k - 1))
                    }
                    out *= env * amp
                }
                1 -> { // bell
                    val env = if (age < 0.003f) age / 0.003f else exp(-decay * (age - 0.003f))
                    if (age > 0.1f && env < 0.001f) alive = false
                    for (k in 0..3) {
                        ph[k] += TAU * f * BR[k] * dt
                        if (ph[k] > TAU) ph[k] -= TAU
                        out += sin(ph[k]) * BW[k] * exp(-age * decay * 0.4f * k)
                    }
                    out *= env * amp
                }
                2 -> { // sweep
                    val u = min(age / dur, 1f)
                    val fr = f + (f2 - f) * u
                    ph[0] += TAU * fr * dt
                    if (ph[0] > TAU) ph[0] -= TAU
                    out = sin(ph[0]) * sin(3.1415927f * u) * amp
                    if (age > dur) alive = false
                }
                3 -> { // pad
                    val env = min(age / 1.8f, 1f) * exp(-max(0f, age - 3f) * 0.8f)
                    if (age > 9f) alive = false
                    ph[0] += TAU * f * dt
                    ph[1] += TAU * f * 2.003f * dt
                    if (ph[0] > TAU) ph[0] -= TAU
                    if (ph[1] > TAU) ph[1] -= TAU
                    out = (sin(ph[0]) + 0.25f * sin(ph[1])) * env * amp
                }
                4 -> { // thump
                    val env = exp(-decay * age)
                    if (age > 0.4f) alive = false
                    val n = rnd.nextFloat() * 2f - 1f
                    lp += 0.12f * (n - lp)
                    ph[0] += TAU * 80f * dt
                    if (ph[0] > TAU) ph[0] -= TAU
                    out = (lp * 1.6f + sin(ph[0]) * 0.8f) * env * amp
                }
                else -> alive = false
            }
            return out
        }
    }

    private fun midi(n: Int): Float = 440f * 2f.pow((n - 69) / 12f)

    private fun spawnSfx(id: Int, v: ArrayList<Voice>) {
        when (id) {
            Sfx.JUMP -> v.add(Voice(2, 330f, 0.14f, 0f, 620f, 0.16f))
            Sfx.LAND -> v.add(Voice(4, 0f, 0.25f, 28f))
            Sfx.ORB -> {
                v.add(Voice(1, 1318f, 0.11f, 5f))
                v.add(Voice(1, 1760f, 0.08f, 6f, delay = sr / 12))
            }
            Sfx.STAR -> {
                val n = intArrayOf(72, 76, 79, 84)
                for (i in n.indices) v.add(Voice(1, midi(n[i]), 0.1f, 3f, delay = i * sr / 9))
            }
            Sfx.CHECK -> {
                val n = intArrayOf(67, 71, 74)
                for (i in n.indices) v.add(Voice(1, midi(n[i]), 0.09f, 2.5f, delay = i * sr / 8))
            }
            Sfx.BOUNCE -> v.add(Voice(2, 220f, 0.18f, 0f, 900f, 0.25f))
            Sfx.RESPAWN -> v.add(Voice(2, 600f, 0.12f, 0f, 150f, 0.4f))
            Sfx.SECRET -> {
                val n = intArrayOf(67, 72, 76, 79, 84)
                for (i in n.indices) v.add(Voice(1, midi(n[i]), 0.09f, 2.2f, delay = i * sr / 7))
            }
            Sfx.EXIT -> {
                val n = intArrayOf(60, 64, 67, 72, 76)
                for (i in n.indices) v.add(Voice(3, midi(n[i]), 0.07f, 0f, delay = i * sr / 6))
                v.add(Voice(1, midi(84), 0.1f, 1.5f))
            }
        }
    }

    private fun runLoop() {
        val minBuf = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val track = try {
            AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sr)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
                )
                .setBufferSizeInBytes(max(minBuf, 4096))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
        } catch (e: Exception) {
            running = false
            return
        }
        try { track.play() } catch (e: Exception) { running = false; track.release(); return }

        val chunk = 512
        val buf = ShortArray(chunk)
        val rnd = Random(1234)
        val voices = ArrayList<Voice>()
        val dt = 1f / sr
        var noteCountdown = sr
        var step = 0
        var degree = 3
        var w1 = 0f
        var w2 = 0f
        var tm = 0f
        var cph = 0f
        val comb1 = FloatArray(1499)
        val comb2 = FloatArray(2113)
        var i1 = 0
        var i2 = 0

        while (running) {
            while (true) {
                val id = sfxQueue.poll() ?: break
                spawnSfx(id, voices)
            }
            val th = theme
            val rt = root
            val sc = scale
            if (muted) {
                voices.clear()
                java.util.Arrays.fill(buf, 0.toShort())
                track.write(buf, 0, chunk)
                continue
            }
            for (n in 0 until chunk) {
                noteCountdown--
                if (noteCountdown <= 0) {
                    noteCountdown = ((0.55f + rnd.nextFloat() * 0.95f) * sr).toInt()
                    step++
                    if (step % 8 == 1) {
                        voices.add(Voice(0, midi(rt - 12), 0.22f, 0.9f))
                        voices.add(Voice(3, midi(rt), 0.05f, 0f))
                        voices.add(Voice(3, midi(rt + 7), 0.04f, 0f))
                        voices.add(Voice(3, midi(rt + 12), 0.03f, 0f))
                    }
                    if (rnd.nextFloat() < 0.78f) {
                        degree = (degree + rnd.nextInt(-2, 3)).coerceIn(0, sc.size * 2 - 1)
                        val note = rt + 12 * (degree / sc.size + 1) + sc[degree % sc.size]
                        voices.add(Voice(0, midi(note), 0.17f, 1.6f))
                        if (rnd.nextFloat() < 0.22f)
                            voices.add(Voice(0, midi(note + 12), 0.07f, 2f, delay = (0.18f * sr).toInt()))
                        if (th == 2 && rnd.nextFloat() < 0.3f)
                            voices.add(Voice(1, midi(note + 24), 0.05f, 2.5f))
                    }
                    while (voices.size > 28) voices.removeAt(0)
                }
                var s = 0f
                var j = voices.size - 1
                while (j >= 0) {
                    val v = voices[j]
                    s += v.next(dt, rnd)
                    if (!v.alive) voices.removeAt(j)
                    j--
                }
                tm += dt
                // wind
                val noise = rnd.nextFloat() * 2f - 1f
                w1 += 0.06f * (noise - w1)
                w2 += 0.06f * (w1 - w2)
                val windGain = (if (th == 0) 0.9f else 1.5f) * (0.55f + 0.45f * sin(TAU * 0.06f * tm))
                s += w2 * windGain * 0.55f
                // crickets (forest only)
                if (th == 0) {
                    cph += TAU * 4300f * dt
                    if (cph > TAU) cph -= TAU
                    val u = tm % 2.3f
                    if (u < 0.42f) {
                        val p = (u * 26f) % 1f
                        if (p < 0.55f) s += sin(cph) * sin(3.1415927f * p / 0.55f) * 0.011f
                    }
                }
                // tiny reverb
                val c1 = comb1[i1]
                val c2 = comb2[i2]
                comb1[i1] = s + c1 * 0.62f
                comb2[i2] = s + c2 * 0.58f
                i1 = (i1 + 1) % comb1.size
                i2 = (i2 + 1) % comb2.size
                val o = ((s + 0.22f * (c1 + c2)) * 0.85f).coerceIn(-1f, 1f)
                buf[n] = (o * 32767f).toInt().toShort()
            }
            track.write(buf, 0, chunk)
        }
        try { track.stop() } catch (_: Exception) {}
        track.release()
    }
}
