package com.lightjourney.game

import android.content.Context
import android.graphics.Canvas
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

class GameView(ctx: Context, private val audio: AudioEngine) : View(ctx) {
    private val levels = Levels.all()
    private val game = Game(audio, levels)
    private val ren = Renderer(game)
    private val prefs = ctx.getSharedPreferences("journey_of_light", Context.MODE_PRIVATE)
    private var unlocked = prefs.getInt("unlocked", 0).coerceIn(0, levels.size - 1)

    // 0 = title, 1 = playing, 2 = chapter complete, 3 = ending
    private var state = 0
    private var stateT = 0f
    private var fade = 1f
    private var last = 0L

    private var tl = false
    private var tr = false
    private var tj = false
    private var kl = false
    private var kr = false
    private var kj = false

    init {
        isFocusable = true
        keepScreenOn = true
        audio.muted = prefs.getBoolean("muted", false)
        game.load(0)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        ren.onSize(w, h)
        game.updateCamera(w / ren.tile, h / ren.tile, 0f, true)
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        last = 0L
    }

    fun onPauseGame() {
        tl = false; tr = false; tj = false
        kl = false; kr = false; kj = false
        last = 0L
    }

    override fun onDraw(canvas: Canvas) {
        val now = System.nanoTime()
        var dt = if (last == 0L) 0.016f else (now - last) / 1e9f
        last = now
        dt = dt.coerceIn(0.001f, 0.033f)
        step(dt)
        render(canvas)
        postInvalidateOnAnimation()
    }

    private fun step(dt: Float) {
        stateT += dt
        fade = max(0f, fade - dt * 1.2f)
        when (state) {
            1 -> {
                val dir = (if (tr || kr) 1 else 0) - (if (tl || kl) 1 else 0)
                game.update(dt, dir, tj || kj)
                if (game.finished && game.finishT > 1.6f) finishLevel()
            }
            else -> game.update(dt, 0, false)
        }
        game.updateCamera(ren.W / ren.tile, ren.H / ren.tile, dt, false)
    }

    private fun render(canvas: Canvas) {
        ren.drawScene(canvas)
        when (state) {
            0 -> ren.drawTitle(canvas, unlocked, stateT)
            1 -> {
                ren.drawHud(canvas, audio.muted)
                ren.drawControls(canvas, tl || kl, tr || kr, tj || kj)
            }
            2 -> ren.drawComplete(canvas, stateT, false)
            3 -> ren.drawEnding(canvas, stateT)
        }
        ren.drawFade(canvas, fade)
    }

    // ------------------------------------------------------------ flow
    private fun startLevel(i: Int) {
        game.load(i)
        game.updateCamera(ren.W / ren.tile, ren.H / ren.tile, 0f, true)
        state = 1
        stateT = 0f
        fade = 1f
        tl = false; tr = false; tj = false
    }

    private fun finishLevel() {
        val idx = game.levelIndex
        if (idx + 1 < levels.size) {
            unlocked = max(unlocked, min(idx + 1, levels.size - 1))
            prefs.edit().putInt("unlocked", unlocked).apply()
            state = 2
        } else {
            unlocked = levels.size - 1
            prefs.edit().putInt("unlocked", unlocked).apply()
            state = 3
        }
        stateT = 0f
        tl = false; tr = false; tj = false
    }

    private fun toTitle() {
        game.load(0)
        game.updateCamera(ren.W / ren.tile, ren.H / ren.tile, 0f, true)
        state = 0
        stateT = 0f
        fade = 1f
    }

    private fun toggleMute() {
        audio.muted = !audio.muted
        prefs.edit().putBoolean("muted", audio.muted).apply()
    }

    // ------------------------------------------------------------ input
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val act = e.actionMasked
        when (state) {
            0 -> if (act == MotionEvent.ACTION_DOWN && stateT > 0.6f) {
                val x = e.x
                val y = e.y
                if (!ren.btn2.isEmpty && ren.btn2.contains(x, y)) {
                    unlocked = 0
                    prefs.edit().putInt("unlocked", 0).apply()
                    startLevel(0)
                } else {
                    startLevel(unlocked)
                }
            }
            2 -> if (act == MotionEvent.ACTION_DOWN && stateT > 0.9f) startLevel(game.levelIndex + 1)
            3 -> if (act == MotionEvent.ACTION_DOWN && stateT > 2.5f) toTitle()
            1 -> handlePlayTouch(e)
        }
        return true
    }

    private fun handlePlayTouch(e: MotionEvent) {
        val act = e.actionMasked
        if (act == MotionEvent.ACTION_DOWN || act == MotionEvent.ACTION_POINTER_DOWN) {
            val i = e.actionIndex
            if (hypot(e.getX(i) - ren.muteX, e.getY(i) - ren.muteY) < ren.muteR * 1.4f) toggleMute()
        }
        var l = false
        var r = false
        var j = false
        if (act != MotionEvent.ACTION_UP && act != MotionEvent.ACTION_CANCEL) {
            for (i in 0 until e.pointerCount) {
                if (act == MotionEvent.ACTION_POINTER_UP && i == e.actionIndex) continue
                val x = e.getX(i)
                val y = e.getY(i)
                if (hypot(x - ren.muteX, y - ren.muteY) < ren.muteR * 1.4f) continue
                when {
                    hypot(x - ren.leftX, y - ren.btnY) < ren.btnR * 1.25f -> l = true
                    hypot(x - ren.rightX, y - ren.btnY) < ren.btnR * 1.25f -> r = true
                    x > ren.W * 0.5f -> j = true
                }
            }
        }
        tl = l; tr = r; tj = j
    }

    fun handleKey(code: Int, down: Boolean): Boolean {
        when (code) {
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_A -> kl = down
            KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_D -> kr = down
            KeyEvent.KEYCODE_SPACE, KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_W,
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_BUTTON_A -> {
                kj = down
                if (down && state == 0 && stateT > 0.6f) startLevel(unlocked)
                else if (down && state == 2 && stateT > 0.9f) startLevel(game.levelIndex + 1)
                else if (down && state == 3 && stateT > 2.5f) toTitle()
            }
            else -> return false
        }
        return true
    }
}
