package com.lightjourney.game

import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

const val TAU = 6.2831855f

object Col {
    val GOLD = 0xFFFFD27A.toInt()
    val PALE = 0xFFFFF1C9.toInt()
    val VIOLET = 0xFFB59CFF.toInt()
    val CYAN = 0xFF9FE8FF.toInt()
}

class Game(private val audio: AudioEngine, val levels: List<LevelData>) {
    companion object {
        const val HW = 0.27f        // half width of the character
        const val BH = 0.85f        // height of the character
        const val RUN = 6.3f
        const val GRAV = 40f
        const val JUMP = 15.8f
        const val BOUNCE = 23.5f
        const val MAXFALL = 22f
    }

    lateinit var lv: LevelData
    lateinit var grid: Array<CharArray>
    lateinit var hAlpha: FloatArray
    private lateinit var revealed: BooleanArray
    private var hidden = IntArray(0)
    val lit = HashSet<Int>()
    val particles = Particles()
    private val rnd = Random(7)

    var levelIndex = 0
    var time = 0f
    var levelT = 0f
    var px = 0f
    var py = 0f
    var vx = 0f
    var vy = 0f
    var onGround = false
    var facing = 1
    var orbs = 0
    var stars = 0
    var rx = 0f
    var ry = 0f
    var finished = false
    var finishT = 0f
    var flash = 0f
    var squash = 0f
    var bounceT = 0f
    var bounceC = -1
    var bounceR = -1
    var haloX = 0f
    var haloY = 0f
    var haloR = 2.2f
    var haloKick = 0f
    var ringT = 0f
    var camX = 0f
    var camY = 0f
    var viewW = 25f
    var viewH = 11.5f

    val moteN = 60
    val mx = FloatArray(moteN)
    val my = FloatArray(moteN)
    val mp = FloatArray(moteN) { rnd.nextFloat() * TAU }
    val ms = FloatArray(moteN) { 0.6f + rnd.nextFloat() }
    private var needMotes = true

    private var coyote = 0f
    private var jumpBuf = 0f
    private var prevJump = false
    private var jumpCut = false
    private var trailT = 0f

    fun load(i: Int) {
        levelIndex = i
        lv = levels[i]
        grid = Array(lv.h) { lv.grid[it].clone() }
        val hl = ArrayList<Int>()
        for (r in 0 until lv.h) for (c in 0 until lv.w) {
            if (grid[r][c] == 'H' || grid[r][c] == 'r') hl.add(r * lv.w + c)
        }
        hidden = hl.toIntArray()
        revealed = BooleanArray(lv.w * lv.h)
        hAlpha = FloatArray(lv.w * lv.h) { 1f }
        lit.clear()
        orbs = 0; stars = 0
        px = lv.startC + 0.5f
        py = (lv.startR + 1).toFloat()
        rx = px; ry = py
        vx = 0f; vy = 0f
        onGround = false; facing = 1
        finished = false; finishT = 0f
        flash = 0f; squash = 0f; bounceT = 0f
        coyote = 0f; jumpBuf = 0f; jumpCut = false; prevJump = false
        haloX = px; haloY = py - 0.45f; haloR = 2.2f; haloKick = 0f; ringT = 0f
        levelT = 0f
        particles.clear()
        needMotes = true
        audio.setMood(lv.theme, lv.root, lv.scale)
    }

    fun isRevealed(k: Int) = revealed[k]

    fun tile(c: Int, r: Int): Char {
        if (c < 0 || c >= lv.w) return '#'
        if (r < 0 || r >= lv.h) return ' '
        return grid[r][c]
    }

    private fun approach(v: Float, t: Float, a: Float) = if (v < t) min(v + a, t) else max(v - a, t)

    fun update(dt: Float, dirIn: Int, jumpIn: Boolean) {
        time += dt
        levelT += dt
        flash = max(0f, flash - dt * 1.6f)
        squash = max(0f, squash - dt * 5f)
        bounceT = max(0f, bounceT - dt)
        ringT = max(0f, ringT - dt * 1.3f)
        haloKick = max(0f, haloKick - dt * 1.6f)
        val dir = if (finished) 0 else dirIn
        val jump = if (finished) false else jumpIn
        if (finished) finishT += dt

        vx = approach(vx, dir * RUN, (if (onGround) 60f else 34f) * dt)
        if (dir != 0) facing = dir

        if (jump && !prevJump) jumpBuf = 0.13f else jumpBuf -= dt
        prevJump = jump
        if (onGround) coyote = 0.1f else coyote -= dt
        if (jumpBuf > 0f && coyote > 0f) {
            vy = -JUMP
            onGround = false
            coyote = 0f
            jumpBuf = 0f
            jumpCut = false
            audio.sfx(Sfx.JUMP)
            haloKick = 1f
            ringT = 1f
            particles.burst(px, py - 0.1f, 10, 2.2f, Col.GOLD, 0.7f, 0.07f)
        }
        if (!jump && vy < -5f && !jumpCut) {
            vy *= 0.5f
            jumpCut = true
        }
        vy = min(vy + GRAV * dt, MAXFALL)

        moveX(dt)
        moveY(dt)
        interact(dt)
        if (py > lv.h + 3f) respawn()

        // halo: smooth, lags behind the body and spreads when running / jumping
        val speed = abs(vx) / RUN
        val targetR = 2.1f + 0.55f * speed + (if (!onGround) 0.45f else 0f) + 1.1f * haloKick
        haloR += (targetR - haloR) * (1f - exp(-dt * 6f))
        haloX += (px - haloX) * (1f - exp(-dt * 9f))
        haloY += ((py - 0.45f) - haloY) * (1f - exp(-dt * 9f))

        // trail sparks
        trailT -= dt
        if (trailT <= 0f) {
            if (onGround && abs(vx) > 2.5f) {
                trailT = 0.05f
                particles.spawn(px - facing * 0.2f + (rnd.nextFloat() - 0.5f) * 0.2f, py - 0.05f,
                    -vx * 0.08f, -0.6f - rnd.nextFloat(), 0.7f, 0.055f, Col.GOLD)
            } else if (!onGround) {
                trailT = 0.04f
                particles.spawn(px + (rnd.nextFloat() - 0.5f) * 0.3f, py - 0.4f,
                    (rnd.nextFloat() - 0.5f) * 0.6f, 0.4f, 0.6f, 0.05f, Col.PALE)
            }
        }

        for (k in hidden) {
            if (revealed[k]) hAlpha[k] = max(0f, hAlpha[k] - dt * 1.2f)
        }
        particles.update(dt)
        updateMotes(dt)
    }

    private fun moveX(dt: Float) {
        var nx = px + vx * dt
        val top = floor(py - BH + 0.05f).toInt()
        val bot = floor(py - 0.05f).toInt()
        if (vx > 0f) {
            val c = floor(nx + HW).toInt()
            for (r in top..bot) if (tile(c, r) == '#') { nx = c - HW - 0.001f; vx = 0f; break }
        } else if (vx < 0f) {
            val c = floor(nx - HW).toInt()
            for (r in top..bot) if (tile(c, r) == '#') { nx = c + 1f + HW + 0.001f; vx = 0f; break }
        }
        px = nx
    }

    private fun moveY(dt: Float) {
        val prev = py
        var ny = py + vy * dt
        val wasGround = onGround
        onGround = false
        val c0 = floor(px - HW + 0.03f).toInt()
        val c1 = floor(px + HW - 0.03f).toInt()
        if (vy >= 0f) {
            val rs = ceil(prev - 0.002f).toInt()
            val re = floor(ny).toInt()
            var landed = false
            var landTile = ' '
            var landC = 0
            var landR = 0
            var r = rs
            while (r <= re && !landed) {
                for (c in c0..c1) {
                    val t = tile(c, r)
                    if (t == '#' || t == '=' || t == 'g' || t == 'B') {
                        landed = true; landTile = t; landC = c; landR = r
                        break
                    }
                }
                if (!landed) r++
            }
            if (landed) {
                val impact = vy
                ny = r.toFloat()
                if (landTile == 'B') {
                    vy = -BOUNCE
                    jumpCut = true
                    bounceT = 0.3f; bounceC = landC; bounceR = landR
                    haloKick = 1f; ringT = 1f
                    audio.sfx(Sfx.BOUNCE)
                    particles.burst(px, ny, 14, 3f, Col.VIOLET, 0.8f, 0.07f)
                } else {
                    onGround = true
                    vy = 0f
                    if (impact > 7f && !wasGround) {
                        squash = min(1f, impact / 20f)
                        audio.sfx(Sfx.LAND)
                        particles.burst(px, ny, 6, 1.6f, Col.PALE, 0.5f, 0.05f)
                    }
                }
            }
        } else {
            val r = floor(ny - BH).toInt()
            for (c in c0..c1) {
                if (tile(c, r) == '#') { ny = r + 1f + BH + 0.001f; vy = 0f; break }
            }
        }
        py = ny
    }

    private fun interact(dt: Float) {
        val cx = px
        val cy = py - BH * 0.5f
        val c0 = floor(cx).toInt()
        val r0 = floor(cy).toInt()
        val here = tile(c0, r0)
        if ((here == 'H' || here == 'r') && c0 in 0 until lv.w && r0 in 0 until lv.h) reveal(c0, r0)
        for (r in r0 - 1..r0 + 1) for (c in c0 - 1..c0 + 1) {
            if (c < 0 || c >= lv.w || r < 0 || r >= lv.h) continue
            val ch = grid[r][c]
            val dx = c + 0.5f - cx
            val dy = r + 0.5f - cy
            val d2 = dx * dx + dy * dy
            when (ch) {
                '*' -> if (d2 < 0.5f) {
                    grid[r][c] = ' '
                    orbs++
                    audio.sfx(Sfx.ORB)
                    particles.burst(c + 0.5f, r + 0.5f, 10, 2.5f, Col.GOLD, 0.8f, 0.07f)
                    haloKick = max(haloKick, 0.5f)
                }
                's' -> if (d2 < 0.9f) {
                    grid[r][c] = ' '
                    stars++
                    audio.sfx(Sfx.STAR)
                    particles.burst(c + 0.5f, r + 0.5f, 26, 3.5f, Col.CYAN, 1.1f, 0.08f)
                    haloKick = 1f
                }
                'C' -> if (d2 < 1.2f) {
                    if (lit.add(r * lv.w + c)) {
                        rx = c + 0.5f; ry = (r + 1).toFloat()
                        audio.sfx(Sfx.CHECK)
                        particles.burst(c + 0.5f, r + 0.3f, 24, 3f, Col.GOLD, 1f, 0.07f)
                        haloKick = 0.8f
                    }
                }
                '^' -> {
                    val pl = px - HW + 0.06f
                    val pr = px + HW - 0.06f
                    val pt = py - BH + 0.1f
                    val pb = py - 0.02f
                    if (pr > c + 0.2f && pl < c + 0.8f && pb > r + 0.5f && pt < r + 1f) {
                        respawn()
                        return
                    }
                }
                'E' -> if (!finished && abs(dx) < 0.7f && abs(dy) < 1.3f) {
                    finished = true
                    finishT = 0f
                    audio.sfx(Sfx.EXIT)
                    particles.burst(c + 0.5f, r - 0.2f, 40, 4f, Col.GOLD, 1.4f, 0.09f)
                    haloKick = 1.5f
                }
            }
        }
    }

    private fun reveal(c: Int, r: Int) {
        val w = lv.w
        if (revealed[r * w + c]) return
        val q = java.util.ArrayDeque<Int>()
        q.add(r * w + c)
        revealed[r * w + c] = true
        while (q.isNotEmpty()) {
            val k = q.poll()!!
            val kc = k % w
            val kr = k / w
            val ns = intArrayOf(kc - 1, kr, kc + 1, kr, kc, kr - 1, kc, kr + 1)
            for (i in 0 until 4) {
                val nc = ns[i * 2]
                val nr = ns[i * 2 + 1]
                if (nc < 0 || nc >= w || nr < 0 || nr >= lv.h) continue
                val ch = grid[nr][nc]
                val nk = nr * w + nc
                if ((ch == 'H' || ch == 'r') && !revealed[nk]) {
                    revealed[nk] = true
                    q.add(nk)
                }
            }
        }
        audio.sfx(Sfx.SECRET)
        particles.burst(px, py - 0.5f, 24, 3f, Col.GOLD, 1.2f, 0.07f)
        haloKick = 1.2f
    }

    private fun respawn() {
        particles.burst(px, py - 0.4f, 22, 4f, Col.VIOLET, 0.9f, 0.08f)
        flash = 1f
        audio.sfx(Sfx.RESPAWN)
        px = rx; py = ry
        vx = 0f; vy = 0f
        coyote = 0f; jumpBuf = 0f
        haloX = px; haloY = py - 0.45f
        particles.burst(px, py - 0.4f, 18, 3f, Col.GOLD, 0.9f, 0.07f)
    }

    fun updateCamera(vw: Float, vh: Float, dt: Float, snap: Boolean) {
        viewW = vw
        viewH = vh
        val maxX = max(0f, lv.w - vw)
        val tx = (px + facing * 1.6f - vw / 2f).coerceIn(0f, maxX)
        val maxY = lv.h - vh
        val ty = ((py - 0.4f) - vh * 0.58f).coerceIn(min(0f, maxY), max(0f, maxY))
        val k = if (snap) 1f else 1f - exp(-dt * 4.5f)
        camX += (tx - camX) * k
        camY += (ty - camY) * k
    }

    private fun updateMotes(dt: Float) {
        val x0 = camX - 2f
        val x1 = camX + viewW + 2f
        val y0 = camY - 2f
        val y1 = camY + viewH + 2f
        val rise = if (lv.theme == 2) -0.35f else 0f
        for (i in 0 until moteN) {
            if (needMotes) {
                mx[i] = x0 + rnd.nextFloat() * (x1 - x0)
                my[i] = y0 + rnd.nextFloat() * (y1 - y0)
            }
            mx[i] += sin(time * 0.6f + mp[i]) * 0.25f * dt
            my[i] += (cos(time * 0.5f + mp[i] * 1.3f) * 0.18f + rise) * dt
            if (mx[i] < x0) mx[i] += (x1 - x0) else if (mx[i] > x1) mx[i] -= (x1 - x0)
            if (my[i] < y0) my[i] += (y1 - y0) else if (my[i] > y1) my[i] -= (y1 - y0)
        }
        needMotes = false
    }
}
