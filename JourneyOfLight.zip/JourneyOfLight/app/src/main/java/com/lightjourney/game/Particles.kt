package com.lightjourney.game

import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

class Particles(private val max: Int = 360) {
    val x = FloatArray(max)
    val y = FloatArray(max)
    val vx = FloatArray(max)
    val vy = FloatArray(max)
    val life = FloatArray(max)
    val maxLife = FloatArray(max) { 1f }
    val size = FloatArray(max)
    val grav = FloatArray(max)
    val color = IntArray(max)
    val count get() = max
    private var next = 0
    private val rnd = Random(3)

    fun clear() { life.fill(0f) }

    fun spawn(px: Float, py: Float, pvx: Float, pvy: Float, l: Float, s: Float, c: Int, g: Float = 0f) {
        val i = next
        next = (next + 1) % max
        x[i] = px; y[i] = py; vx[i] = pvx; vy[i] = pvy
        life[i] = l; maxLife[i] = l; size[i] = s; color[i] = c; grav[i] = g
    }

    fun burst(px: Float, py: Float, n: Int, speed: Float, c: Int, l: Float, s: Float, g: Float = 0f) {
        repeat(n) {
            val a = rnd.nextFloat() * TAU
            val sp = speed * (0.3f + 0.7f * rnd.nextFloat())
            spawn(px, py, cos(a) * sp, sin(a) * sp, l * (0.6f + 0.6f * rnd.nextFloat()),
                s * (0.6f + 0.8f * rnd.nextFloat()), c, g)
        }
    }

    fun update(dt: Float) {
        for (i in 0 until max) {
            if (life[i] <= 0f) continue
            life[i] -= dt
            x[i] += vx[i] * dt
            y[i] += vy[i] * dt
            vy[i] += grav[i] * dt
            val d = 1f - 1.5f * dt
            vx[i] *= d
            vy[i] *= d
        }
    }
}
