package com.lightjourney.game

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

class Theme(
    val sky: IntArray, val far: Int, val mid: Int, val near: Int,
    val rock: IntArray, val accent: Int, val mote: Int, val fog: Int, val dark: Float
)

class Renderer(private val g: Game) {
    var W = 1f
    var H = 1f
    var tile = 1f

    private fun col(v: Long) = v.toInt()

    private val themes = listOf(
        // 0: Whispering Forest
        Theme(
            intArrayOf(col(0xFF090612), col(0xFF1A0F30), col(0xFF2C1948)),
            col(0xFF25163F), col(0xFF170D2B), col(0xFF0C0716),
            intArrayOf(col(0xFF1D1333), col(0xFF22183B), col(0xFF191029)),
            col(0xFF7A5CC8), col(0xFFE6E88A), col(0xFF6B4FA8), 0.80f
        ),
        // 1: Shadow Peaks
        Theme(
            intArrayOf(col(0xFF07060F), col(0xFF150E2A), col(0xFF32204F)),
            col(0xFF2A1A47), col(0xFF1A1030), col(0xFF0E0819),
            intArrayOf(col(0xFF231A3A), col(0xFF2A2045), col(0xFF1D1530)),
            col(0xFF8E7BD6), col(0xFFC9B8FF), col(0xFF5A4690), 0.76f
        ),
        // 2: Heart of Light
        Theme(
            intArrayOf(col(0xFF0B0616), col(0xFF26123F), col(0xFF4A2358)),
            col(0xFF3A2160), col(0xFF28164A), col(0xFF170C2D),
            intArrayOf(col(0xFF2A1B46), col(0xFF31214F), col(0xFF241740)),
            col(0xFFE6B85C), col(0xFFFFD98A), col(0xFF8A5CB0), 0.58f
        )
    )

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()
    private var skyPaints: List<Paint> = emptyList()

    private val serif = Typeface.create(Typeface.SERIF, Typeface.NORMAL)
    private val serifBold = Typeface.create(Typeface.SERIF, Typeface.BOLD)
    private val italic = Typeface.create(Typeface.SERIF, Typeface.ITALIC)

    private fun glowPaint(rgb: Int): Paint {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val base = rgb and 0x00FFFFFF
        p.shader = RadialGradient(
            0f, 0f, 1f,
            intArrayOf(base or (255 shl 24), base or (110 shl 24), base),
            floatArrayOf(0f, 0.32f, 1f), Shader.TileMode.CLAMP
        )
        p.xfermode = PorterDuffXfermode(PorterDuff.Mode.SCREEN)
        return p
    }

    private val goldGlow = glowPaint(col(0xFFFFC857))
    private val cyanGlow = glowPaint(col(0xFF8FE3FF))
    private val violetGlow = glowPaint(col(0xFFA58BFF))
    private val whiteGlow = glowPaint(col(0xFFFFF4D6))

    private val fogPaints = themes.map { th ->
        val base = th.fog and 0x00FFFFFF
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(
                0f, 0f, 1f,
                intArrayOf(base or (70 shl 24), base or (30 shl 24), base),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
            )
        }
    }

    private val darkPaint = Paint().apply {
        shader = RadialGradient(
            0f, 0f, 1f,
            intArrayOf(0x0007030F, 0x0007030F, 0xFF07030F.toInt()),
            floatArrayOf(0f, 0.28f, 1f), Shader.TileMode.CLAMP
        )
    }

    private val rnd = Random(11)
    private val sxs = FloatArray(90) { rnd.nextFloat() }
    private val sys = FloatArray(90) { rnd.nextFloat() * 0.62f }
    private val sss = FloatArray(90) { 0.6f + rnd.nextFloat() * 1.6f }
    private val sps = FloatArray(90) { rnd.nextFloat() * TAU }

    // geometry used by the touch handler
    val btnR get() = H * 0.105f
    val leftX get() = btnR * 1.45f
    val rightX get() = btnR * 4.0f
    val btnY get() = H - btnR * 1.5f
    val jumpX get() = W - btnR * 1.8f
    val jumpY get() = H - btnR * 1.6f
    val muteX get() = W - H * 0.07f
    val muteY get() = H * 0.07f
    val muteR get() = H * 0.045f
    val btn1 = RectF()
    val btn2 = RectF()

    fun onSize(w: Int, h: Int) {
        W = w.toFloat(); H = h.toFloat(); tile = H / 11.5f
        skyPaints = themes.map { th ->
            Paint().apply {
                shader = LinearGradient(0f, 0f, 0f, H, th.sky, floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP)
            }
        }
    }

    // ------------------------------------------------------------------ helpers
    private fun setFill(color: Int, a: Float) {
        fill.color = color
        fill.alpha = (Color.alpha(color) * a).toInt().coerceIn(0, 255)
    }

    private fun setStroke(color: Int, a: Float, w: Float) {
        stroke.color = color
        stroke.alpha = (Color.alpha(color) * a).toInt().coerceIn(0, 255)
        stroke.strokeWidth = w
    }

    private fun glow(cv: Canvas, p: Paint, x: Float, y: Float, r: Float, a: Float) {
        p.alpha = (a * 255f).toInt().coerceIn(0, 255)
        cv.save()
        cv.translate(x, y)
        cv.scale(r, r)
        cv.drawCircle(0f, 0f, 1f, p)
        cv.restore()
    }

    private fun hash(a: Int, b: Int): Int {
        var h = a * 73856093 xor b * 19349663
        h = h xor (h ushr 13)
        h *= 0x5bd1e995
        h = h xor (h ushr 15)
        return h and 0x7fffffff
    }

    private fun rockLook(cc: Int, rr: Int): Boolean {
        if (cc < 0 || cc >= g.lv.w) return true
        if (rr < 0 || rr >= g.lv.h) return false
        val ch = g.grid[rr][cc]
        return ch == '#' || ch == 'H' || ch == 'r'
    }

    private fun starPath(cx: Float, cy: Float, r: Float, rot: Float) {
        path.reset()
        for (i in 0..7) {
            val ang = rot + i * 0.7853982f
            val rad = if (i % 2 == 0) r else r * 0.35f
            val x = cx + cos(ang) * rad
            val y = cy + sin(ang) * rad
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
    }

    // ------------------------------------------------------------------ scene
    fun drawScene(cv: Canvas) {
        if (skyPaints.isEmpty()) return
        val idx = g.lv.theme
        val th = themes[idx]
        drawBackground(cv, th, idx)
        drawFog(cv, th, idx, 0)

        cv.save()
        cv.scale(tile, tile)
        cv.translate(-g.camX, -g.camY)
        drawTiles(cv, th)
        drawPlayer(cv)
        cv.restore()

        drawWhispers(cv)
        drawDarkness(cv, th)

        cv.save()
        cv.scale(tile, tile)
        cv.translate(-g.camX, -g.camY)
        drawGlows(cv, th)
        drawHalo(cv)
        cv.restore()

        drawFog(cv, th, idx, 1)
        if (g.flash > 0f) {
            setFill(Col.GOLD, g.flash * 0.45f)
            cv.drawRect(0f, 0f, W, H, fill)
        }
    }

    private fun drawBackground(cv: Canvas, th: Theme, idx: Int) {
        val camPx = g.camX * tile
        val u = H / 1080f
        cv.drawRect(0f, 0f, W, H, skyPaints[idx])
        for (i in sxs.indices) {
            var x = (sxs[i] * W - camPx * 0.03f) % W
            if (x < 0f) x += W
            val tw = 0.5f + 0.5f * sin(g.time * (0.8f + sss[i] * 0.3f) + sps[i])
            setFill(0xFFFFF6E0.toInt(), 0.25f + 0.6f * tw)
            cv.drawCircle(x, sys[i] * H, sss[i] * max(1f, u * 1.4f), fill)
        }
        if (idx < 2) {
            val mx = W * 0.80f - camPx * 0.03f
            val my = H * 0.18f
            glow(cv, violetGlow, mx, my, H * 0.24f, 0.55f)
            setFill(0xFFE9E1FF.toInt(), 0.95f)
            cv.drawCircle(mx, my, H * 0.055f, fill)
            setFill(0xFFB9AEE0.toInt(), 0.5f)
            cv.drawCircle(mx - H * 0.015f, my - H * 0.01f, H * 0.012f, fill)
            cv.drawCircle(mx + H * 0.018f, my + H * 0.014f, H * 0.008f, fill)
        } else {
            val hx = W * 0.68f - camPx * 0.02f
            val hy = H * 0.30f
            val pulse = 0.5f + 0.5f * sin(g.time * 1.3f)
            for (k in 0..4) {
                var bx = (W * (0.1f + 0.2f * k) - camPx * (0.1f + 0.03f * k)) % W
                if (bx < 0f) bx += W
                bx += sin(g.time * 0.3f + k) * 20f * u
                setFill(Col.GOLD, 0.04f + 0.03f * sin(g.time * 0.7f + k * 1.7f))
                path.reset()
                path.moveTo(bx - 8f * u, 0f); path.lineTo(bx + 8f * u, 0f)
                path.lineTo(bx + 90f * u, H); path.lineTo(bx - 90f * u, H)
                path.close()
                cv.drawPath(path, fill)
            }
            glow(cv, goldGlow, hx, hy, H * 0.6f, 0.45f + 0.15f * pulse)
            glow(cv, whiteGlow, hx, hy, H * 0.17f, 0.75f)
        }
        when (idx) {
            0 -> {
                ridge(cv, 0.08f, H * 0.66f, H * 0.22f, 0.0035f, false, th.far, 1f)
                ridge(cv, 0.16f, H * 0.76f, H * 0.20f, 0.005f, false, th.mid, 2.3f)
                trees(cv, 0.30f, 85f * u, H * 0.96f, H * 0.40f, th.mid, 3)
                trees(cv, 0.55f, 150f * u, H * 1.04f, H * 0.68f, th.near, 9)
            }
            1 -> {
                ridge(cv, 0.06f, H * 0.70f, H * 0.45f, 0.0030f, true, th.far, 0.5f)
                ridge(cv, 0.14f, H * 0.84f, H * 0.40f, 0.0040f, true, th.mid, 1.9f)
                ridge(cv, 0.26f, H * 0.98f, H * 0.38f, 0.0055f, true, th.near, 4.2f)
            }
            else -> {
                ridge(cv, 0.06f, H * 0.72f, H * 0.28f, 0.0030f, false, th.far, 0.9f)
                ridge(cv, 0.14f, H * 0.86f, H * 0.30f, 0.0045f, true, th.mid, 2.7f)
                ridge(cv, 0.26f, H * 1.0f, H * 0.30f, 0.0060f, true, th.near, 5.1f)
            }
        }
    }

    private fun ridge(cv: Canvas, par: Float, base: Float, amp: Float, freq: Float, jag: Boolean, color: Int, seed: Float) {
        val off = g.camX * tile * par
        path.reset()
        path.moveTo(0f, H)
        var x = 0f
        while (x <= W + 24f) {
            val wx = x + off
            val h = if (jag)
                abs(sin(wx * freq + seed)) * 0.65f + abs(sin(wx * freq * 2.3f + seed * 1.7f)) * 0.35f
            else
                (sin(wx * freq + seed) * 0.5f + 0.5f) * 0.6f + (sin(wx * freq * 2.7f + seed) * 0.5f + 0.5f) * 0.4f
            path.lineTo(x, base - h * amp)
            x += 24f
        }
        path.lineTo(W + 24f, H)
        path.close()
        setFill(color, 1f)
        cv.drawPath(path, fill)
    }

    private fun trees(cv: Canvas, par: Float, spacing: Float, baseY: Float, hgt: Float, color: Int, seed: Int) {
        val off = g.camX * tile * par
        val i0 = floor(off / spacing).toInt() - 1
        val n = (W / spacing).toInt() + 3
        setFill(color, 1f)
        for (i in i0 until i0 + n) {
            val h = hash(i, seed)
            val x = i * spacing - off + (h % 30 - 15)
            val th = hgt * (0.75f + (h % 40) / 100f)
            path.reset()
            for (tier in 0..2) {
                val ty = baseY - th * tier * 0.28f
                val hw = th * 0.22f * (1f - tier * 0.22f)
                path.moveTo(x - hw, ty)
                path.lineTo(x, ty - th * 0.42f)
                path.lineTo(x + hw, ty)
                path.close()
            }
            cv.drawPath(path, fill)
        }
        cv.drawRect(0f, baseY - 2f, W, H, fill)
    }

    private fun drawFog(cv: Canvas, th: Theme, idx: Int, layer: Int) {
        val camPx = g.camX * tile
        val range = if (layer == 0) 0..3 else 4..6
        val alpha = if (layer == 0) 1f else 0.55f
        val span = W * 1.6f
        for (i in range) {
            var x = (i * 0.23f * W + g.time * (8f + i * 3f) - camPx * (0.35f + 0.05f * i)) % span
            if (x < 0f) x += span
            x -= W * 0.3f
            val y = H * (0.50f + 0.07f * (i % 4))
            val p = fogPaints[idx]
            p.alpha = (alpha * 255).toInt()
            cv.save()
            cv.translate(x, y)
            cv.scale(W * 0.35f, H * 0.12f)
            cv.drawCircle(0f, 0f, 1f, p)
            cv.restore()
        }
    }

    // ------------------------------------------------------------------ tiles
    private fun drawTiles(cv: Canvas, th: Theme) {
        val lv = g.lv
        val c0 = max(0, floor(g.camX).toInt())
        val c1 = min(lv.w - 1, ceil(g.camX + g.viewW).toInt())
        val r0 = max(0, floor(g.camY).toInt())
        val r1 = min(lv.h - 1, ceil(g.camY + g.viewH).toInt())
        val t = g.time
        for (rr in r0..r1) for (cc in c0..c1) {
            when (g.grid[rr][cc]) {
                '#' -> drawRock(cv, th, cc, rr, 1f)
                'H', 'r' -> {
                    val k = rr * lv.w + cc
                    val a = g.hAlpha[k]
                    setFill(0xFF0E0716.toInt(), 1f)
                    cv.drawRect(cc.toFloat(), rr.toFloat(), cc + 1.01f, rr + 1.01f, fill)
                    if (g.isRevealed(k)) {
                        setFill(0xFFFFB45A.toInt(), 0.10f * (1f - a))
                        cv.drawRect(cc.toFloat(), rr.toFloat(), cc + 1.01f, rr + 1.01f, fill)
                    }
                    if (a > 0.01f) drawRock(cv, th, cc, rr, a)
                }
                '=' -> drawLedge(cv, th, cc, rr, 1f, 0xFF3A2466.toInt())
                'g' -> {
                    val d = abs(g.px - (cc + 0.5f)) + abs((g.py - 0.4f) - rr) * 0.8f
                    val a = 0.08f + 0.92f * (1f - d / 6f).coerceIn(0f, 1f)
                    drawLedge(cv, th, cc, rr, a, 0xFFB8A6FF.toInt())
                }
                '^' -> {
                    for (k in 0..2) {
                        val x0 = cc + 0.05f + k * 0.31f
                        path.reset()
                        path.moveTo(x0, rr + 1f)
                        path.lineTo(x0 + 0.15f, rr + 0.46f - 0.06f * (k % 2))
                        path.lineTo(x0 + 0.30f, rr + 1f)
                        path.close()
                        setFill(0xFF7B2C86.toInt(), 1f)
                        cv.drawPath(path, fill)
                        setStroke(0xFFD98BE0.toInt(), 0.8f, 0.03f)
                        cv.drawPath(path, stroke)
                    }
                }
                'C' -> {
                    setFill(0xFF241838.toInt(), 1f)
                    cv.drawRect(cc + 0.32f, rr + 0.5f, cc + 0.68f, rr + 1f, fill)
                    setFill(0xFF3A2A5E.toInt(), 1f)
                    cv.drawRect(cc + 0.25f, rr + 0.9f, cc + 0.75f, rr + 1f, fill)
                }
                'B' -> {
                    setFill(0xFF0E0716.toInt(), 1f)
                    cv.drawRect(cc.toFloat(), rr.toFloat(), cc + 1.01f, rr + 1.01f, fill)
                    val sq = if (g.bounceT > 0f && g.bounceC == cc && g.bounceR == rr) g.bounceT / 0.3f else 0f
                    setFill(0xFFB8A8D8.toInt(), 1f)
                    cv.drawRect(cc + 0.38f, rr + 0.4f, cc + 0.62f, rr + 1f, fill)
                    setFill(0xFF6A3FB0.toInt(), 1f)
                    cv.drawOval(cc + 0.04f, rr + sq * 0.18f, cc + 0.96f, rr + 0.66f, fill)
                    setFill(0xFFD7C6FF.toInt(), 0.85f)
                    cv.drawCircle(cc + 0.3f, rr + 0.3f + sq * 0.1f, 0.06f, fill)
                    cv.drawCircle(cc + 0.62f, rr + 0.24f + sq * 0.1f, 0.05f, fill)
                    cv.drawCircle(cc + 0.78f, rr + 0.4f + sq * 0.1f, 0.04f, fill)
                }
            }
        }
        if (t < 0f) return
    }

    private fun drawRock(cv: Canvas, th: Theme, cc: Int, rr: Int, a: Float) {
        val h = hash(cc, rr)
        setFill(th.rock[h % 3], a)
        cv.drawRect(cc.toFloat(), rr.toFloat(), cc + 1.01f, rr + 1.01f, fill)
        if (h % 4 == 0) {
            setFill(th.accent, 0.10f * a)
            val ox = (h % 5) * 0.12f
            val oy = (h % 3) * 0.2f
            cv.drawRect(cc + 0.15f + ox, rr + 0.2f + oy, cc + 0.35f + ox, rr + 0.28f + oy, fill)
        }
        if (!rockLook(cc, rr - 1)) {
            setFill(th.accent, 0.85f * a)
            cv.drawRect(cc.toFloat(), rr.toFloat(), cc + 1.01f, rr + 0.13f, fill)
            if (g.lv.theme != 2 && a > 0.9f) {
                setStroke(th.accent, 0.75f, 0.035f)
                val sway = sin(g.time * 1.6f + cc) * 0.05f
                for (k in 0..2) {
                    val x = cc + 0.15f + k * 0.35f + (h % 7) * 0.02f
                    cv.drawLine(x, rr + 0.02f, x + sway * (k + 1), rr - 0.14f - ((h shr (k + 2)) % 3) * 0.07f, stroke)
                }
            }
        }
    }

    private fun drawLedge(cv: Canvas, th: Theme, cc: Int, rr: Int, a: Float, tint: Int) {
        setFill(tint, a)
        cv.drawRoundRect(cc.toFloat(), rr.toFloat(), cc + 1.01f, rr + 0.26f, 0.08f, 0.08f, fill)
        setFill(th.accent, 0.9f * a)
        cv.drawRect(cc.toFloat(), rr.toFloat(), cc + 1.01f, rr + 0.07f, fill)
    }

    // ------------------------------------------------------------------ player
    private fun drawPlayer(cv: Canvas) {
        val t = g.time
        val spd = abs(g.vx) / Game.RUN
        val air = !g.onGround
        var sx = 1f
        var sy = 1f
        if (g.squash > 0f) { sx += 0.22f * g.squash; sy -= 0.2f * g.squash }
        if (air && g.vy < -4f) { sx -= 0.07f; sy += 0.10f }
        val bob = if (g.onGround) sin(t * (4f + spd * 10f)) * (0.012f + 0.018f * spd) else 0f
        val wave = sin(t * 5f) * 0.03f * (0.3f + spd)

        cv.save()
        cv.translate(g.px, g.py)
        cv.rotate(g.vx / Game.RUN * 5f)
        cv.scale(g.facing * sx, sy)
        cv.translate(0f, bob)

        // trailing scarf
        val sw = sin(t * 7f) * 0.06f * (0.4f + spd)
        val lift = if (air) (-g.vy * 0.012f) else 0f
        path.reset()
        path.moveTo(-0.14f, -0.56f)
        path.cubicTo(-0.4f - spd * 0.25f, -0.6f + sw, -0.6f - spd * 0.4f, -0.45f - sw,
            -0.78f - spd * 0.5f, -0.5f + sw * 1.5f + lift)
        stroke.strokeCap = Paint.Cap.ROUND
        setStroke(Col.GOLD, 0.6f, 0.05f)
        cv.drawPath(path, stroke)

        // cloak
        path.reset()
        path.moveTo(-0.17f, -0.72f)
        path.quadTo(-0.46f, -0.32f, -0.34f, -0.03f)
        path.quadTo(-0.17f, 0.03f + wave, 0f, -0.05f)
        path.quadTo(0.17f, 0.03f - wave, 0.34f, -0.03f)
        path.quadTo(0.46f, -0.32f, 0.17f, -0.72f)
        path.close()
        setFill(0xFF1C1236.toInt(), 1f)
        cv.drawPath(path, fill)
        setStroke(0xFF6A4DB8.toInt(), 0.9f, 0.025f)
        cv.drawPath(path, stroke)

        // hood
        setFill(0xFF160D2C.toInt(), 1f)
        cv.drawOval(-0.23f, -1.04f, 0.23f, -0.5f, fill)
        setStroke(0xFF6A4DB8.toInt(), 0.9f, 0.022f)
        cv.drawOval(-0.23f, -1.04f, 0.23f, -0.5f, stroke)
        setFill(0xFF04020A.toInt(), 1f)
        cv.drawOval(-0.06f, -0.93f, 0.19f, -0.63f, fill)

        // eyes
        glow(cv, goldGlow, 0.09f, -0.78f, 0.17f, 0.8f)
        setFill(0xFFFFE9A8.toInt(), 1f)
        cv.drawOval(0.03f, -0.81f, 0.075f, -0.74f, fill)
        cv.drawOval(0.11f, -0.81f, 0.155f, -0.74f, fill)
        cv.restore()
    }

    // ------------------------------------------------------------------ lights
    private fun drawDarkness(cv: Canvas, th: Theme) {
        val sx = (g.haloX - g.camX) * tile
        val sy = (g.haloY - g.camY) * tile
        val r = g.haloR * tile * 3.2f
        darkPaint.alpha = (th.dark * 255f).toInt()
        cv.save()
        cv.translate(sx, sy)
        cv.scale(r, r)
        val big = max(W, H) / r * 2f
        cv.drawRect(-big, -big, big, big, darkPaint)
        cv.restore()
    }

    private fun drawGlows(cv: Canvas, th: Theme) {
        val lv = g.lv
        val t = g.time
        val c0 = max(0, floor(g.camX).toInt())
        val c1 = min(lv.w - 1, ceil(g.camX + g.viewW).toInt())
        val r0 = max(0, floor(g.camY).toInt())
        val r1 = min(lv.h - 1, ceil(g.camY + g.viewH).toInt())
        for (rr in r0..r1) for (cc in c0..c1) {
            val ch = g.grid[rr][cc]
            when (ch) {
                '*' -> {
                    val x = cc + 0.5f
                    val y = rr + 0.5f + sin(t * 3f + cc) * 0.07f
                    glow(cv, goldGlow, x, y, 0.8f, 0.85f)
                    setFill(Col.PALE, 1f)
                    cv.drawCircle(x, y, 0.1f, fill)
                    setStroke(Col.GOLD, 0.8f, 0.025f)
                    cv.drawCircle(x, y, 0.16f, stroke)
                }
                's' -> {
                    val x = cc + 0.5f
                    val y = rr + 0.5f + sin(t * 2f + cc) * 0.08f
                    glow(cv, cyanGlow, x, y, 1.5f, 0.9f)
                    starPath(x, y, 0.3f, t * 0.8f)
                    setFill(0xFFEFFFFF.toInt(), 1f)
                    cv.drawPath(path, fill)
                }
                'C' -> {
                    val on = g.lit.contains(rr * lv.w + cc)
                    val x = cc + 0.5f
                    val y = rr + 0.4f
                    if (on) {
                        glow(cv, goldGlow, x, y, 1.9f, 0.7f + 0.15f * sin(t * 4f + cc))
                        setFill(Col.PALE, 1f)
                    } else {
                        glow(cv, violetGlow, x, y, 0.6f, 0.45f)
                        setFill(0xFF8F7BD0.toInt(), 0.9f)
                    }
                    path.reset()
                    path.moveTo(x, y - 0.18f); path.lineTo(x + 0.1f, y)
                    path.lineTo(x, y + 0.18f); path.lineTo(x - 0.1f, y); path.close()
                    cv.drawPath(path, fill)
                }
                'B' -> glow(cv, violetGlow, cc + 0.5f, rr + 0.3f, 1.0f, 0.35f + 0.1f * sin(t * 2f + cc))
                'E' -> drawPortal(cv, cc, rr)
            }
        }
        // ambient motes
        for (i in 0 until g.moteN) {
            val tw = 0.5f + 0.5f * sin(t * (1.2f + g.ms[i]) + g.mp[i])
            glow(cv, goldGlow, g.mx[i], g.my[i], 0.16f * g.ms[i], 0.25f + 0.6f * tw)
            setFill(th.mote, 0.4f + 0.6f * tw)
            cv.drawCircle(g.mx[i], g.my[i], 0.025f * g.ms[i], fill)
        }
        // particles
        val p = g.particles
        for (i in 0 until p.count) {
            if (p.life[i] <= 0f) continue
            val a = (p.life[i] / p.maxLife[i]).coerceIn(0f, 1f)
            setFill(p.color[i], a)
            cv.drawCircle(p.x[i], p.y[i], p.size[i] * (0.4f + 0.6f * a), fill)
        }
        // jump ring
        if (g.ringT > 0f) {
            val rr = (1f - g.ringT) * 2.4f + 0.4f
            setStroke(Col.GOLD, g.ringT * 0.55f, 0.04f)
            cv.drawCircle(g.haloX, g.haloY, rr, stroke)
        }
    }

    private fun drawPortal(cv: Canvas, cc: Int, rr: Int) {
        val t = g.time
        val s = if (g.lv.theme == 2) 1.5f else 1f
        val cx = cc + 0.5f
        val cy = rr + 1f - 1.1f * s
        val pulse = 0.5f + 0.5f * sin(t * 2.2f)
        glow(cv, goldGlow, cx, cy, 3.2f * s, 0.55f + 0.25f * pulse)
        setFill(Col.PALE, 0.22f + 0.12f * pulse)
        cv.drawOval(cx - 0.62f * s, cy - 1.1f * s, cx + 0.62f * s, cy + 1.1f * s, fill)
        setStroke(Col.GOLD, 0.9f, 0.07f * s)
        cv.drawOval(cx - 0.62f * s, cy - 1.1f * s, cx + 0.62f * s, cy + 1.1f * s, stroke)
        setStroke(Col.PALE, 0.5f, 0.03f * s)
        cv.drawOval(cx - 0.45f * s, cy - 0.85f * s, cx + 0.45f * s, cy + 0.85f * s, stroke)
        for (k in 0..5) {
            val ph = (t * 0.5f + k / 6f) % 1f
            val x = cx + sin(t + k * 2f) * 0.4f * s
            val y = cy + 1.1f * s - ph * 2.2f * s
            setFill(Col.PALE, (1f - ph) * 0.9f)
            cv.drawCircle(x, y, 0.04f, fill)
        }
    }

    private fun drawHalo(cv: Canvas) {
        val t = g.time
        val speed = abs(g.vx) / Game.RUN
        val hx = g.haloX
        val hy = g.haloY
        val r = g.haloR * (1f + 0.035f * sin(t * 2.6f))
        glow(cv, goldGlow, hx, hy, r * 1.7f, 0.55f)
        glow(cv, goldGlow, hx, hy, r * 0.9f, 0.7f)
        glow(cv, whiteGlow, hx, hy, r * 0.38f, 0.6f)
        for (k in 0..5) {
            val ang = t * (1.4f + 0.5f * speed) + k * 1.047f
            val rad = 0.55f + 0.25f * sin(t * 2f + k) + 0.4f * speed + (if (!g.onGround) 0.2f else 0f)
            val wx = hx + cos(ang) * rad
            val wy = hy + sin(ang) * rad * 0.8f
            glow(cv, goldGlow, wx, wy, 0.16f, 0.9f)
            setFill(Col.PALE, 0.9f)
            cv.drawCircle(wx, wy, 0.018f, fill)
        }
    }

    private fun drawWhispers(cv: Canvas) {
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.textSize = tile * 0.44f
        textPaint.typeface = italic
        textPaint.letterSpacing = 0.02f
        for (w in g.lv.whispers) {
            val a = (1f - abs(w.x - g.px) / 8f).coerceIn(0f, 1f)
            if (a <= 0.01f) continue
            textPaint.color = 0xFFD9CCFF.toInt()
            textPaint.alpha = (a * 0.85f * 255f).toInt()
            val sx = (w.x - g.camX) * tile
            val sy = (w.y - g.camY) * tile + sin(g.time * 1.2f + w.x) * tile * 0.06f
            cv.drawText(w.text, sx, sy, textPaint)
        }
    }

    // ------------------------------------------------------------------ HUD
    fun drawHud(cv: Canvas, muted: Boolean) {
        val lv = g.lv
        val x = H * 0.05f
        var y = H * 0.075f
        textPaint.typeface = serif
        textPaint.letterSpacing = 0f
        textPaint.textAlign = Paint.Align.LEFT
        textPaint.textSize = H * 0.04f
        glow(cv, goldGlow, x, y, H * 0.035f, 0.9f)
        setFill(Col.PALE, 1f)
        cv.drawCircle(x, y, H * 0.011f, fill)
        textPaint.color = Col.PALE
        cv.drawText("${g.orbs} / ${lv.totalOrbs}", x + H * 0.04f, y + H * 0.014f, textPaint)
        y += H * 0.07f
        starPath(x, y, H * 0.02f, 0f)
        setFill(0xFFDFF8FF.toInt(), 1f)
        cv.drawPath(path, fill)
        textPaint.color = Col.CYAN
        cv.drawText("${g.stars} / ${lv.totalStars}", x + H * 0.04f, y + H * 0.014f, textPaint)

        // mute button
        setStroke(Col.PALE, 0.35f, 2f)
        cv.drawCircle(muteX, muteY, muteR, stroke)
        val s = H * 0.016f
        val mx = muteX
        val my = muteY
        path.reset()
        path.moveTo(mx - s * 1.1f, my - s * 0.5f); path.lineTo(mx - s * 0.4f, my - s * 0.5f)
        path.lineTo(mx + s * 0.3f, my - s * 1.1f); path.lineTo(mx + s * 0.3f, my + s * 1.1f)
        path.lineTo(mx - s * 0.4f, my + s * 0.5f); path.lineTo(mx - s * 1.1f, my + s * 0.5f)
        path.close()
        setFill(Col.PALE, 0.6f)
        cv.drawPath(path, fill)
        if (muted) {
            setStroke(Col.PALE, 0.8f, 3f)
            cv.drawLine(mx - s * 1.4f, my + s * 1.4f, mx + s * 1.4f, my - s * 1.4f, stroke)
        } else {
            setStroke(Col.PALE, 0.5f, 2f)
            rect.set(mx - s * 0.2f, my - s * 0.8f, mx + s * 1.6f, my + s * 0.8f)
            cv.drawArc(rect, -50f, 100f, false, stroke)
        }

        // chapter title
        val lt = g.levelT
        val a = min(min(lt / 0.8f, (4.2f - lt) / 0.8f), 1f)
        if (a > 0f) {
            textPaint.textAlign = Paint.Align.CENTER
            textPaint.typeface = serif
            textPaint.letterSpacing = 0.2f
            textPaint.textSize = H * 0.035f
            textPaint.color = Col.CYAN
            textPaint.alpha = (a * 200).toInt()
            cv.drawText("CHAPTER ${g.levelIndex + 1}", W / 2f, H * 0.2f, textPaint)
            textPaint.typeface = serifBold
            textPaint.letterSpacing = 0.08f
            textPaint.textSize = H * 0.085f
            textPaint.color = Col.PALE
            textPaint.alpha = (a * 255).toInt()
            cv.drawText(lv.name, W / 2f, H * 0.3f, textPaint)
        }
    }

    fun drawControls(cv: Canvas, l: Boolean, r: Boolean, j: Boolean) {
        circleBtn(cv, leftX, btnY, btnR, l)
        circleBtn(cv, rightX, btnY, btnR, r)
        circleBtn(cv, jumpX, jumpY, btnR * 1.1f, j)
        val s = btnR * 0.38f
        setFill(Col.PALE, 0.65f)
        path.reset()
        path.moveTo(leftX - s, btnY); path.lineTo(leftX + s * 0.6f, btnY - s); path.lineTo(leftX + s * 0.6f, btnY + s); path.close()
        cv.drawPath(path, fill)
        path.reset()
        path.moveTo(rightX + s, btnY); path.lineTo(rightX - s * 0.6f, btnY - s); path.lineTo(rightX - s * 0.6f, btnY + s); path.close()
        cv.drawPath(path, fill)
        path.reset()
        path.moveTo(jumpX, jumpY - s * 1.1f); path.lineTo(jumpX - s * 1.1f, jumpY + s * 0.7f); path.lineTo(jumpX + s * 1.1f, jumpY + s * 0.7f); path.close()
        cv.drawPath(path, fill)
    }

    private fun circleBtn(cv: Canvas, x: Float, y: Float, r: Float, down: Boolean) {
        setFill(Col.PALE, if (down) 0.28f else 0.10f)
        cv.drawCircle(x, y, r, fill)
        setStroke(Col.GOLD, if (down) 0.7f else 0.35f, 3f)
        cv.drawCircle(x, y, r, stroke)
    }

    // ------------------------------------------------------------------ screens
    fun drawTitle(cv: Canvas, unlocked: Int, t: Float) {
        val cx = W * 0.60f
        val a = (t / 1.5f).coerceIn(0f, 1f)
        textPaint.textAlign = Paint.Align.CENTER
        glow(cv, goldGlow, cx, H * 0.27f, H * 0.5f, 0.22f * a)
        textPaint.typeface = serifBold
        textPaint.letterSpacing = 0.08f
        textPaint.textSize = H * 0.115f
        textPaint.color = Col.PALE
        textPaint.alpha = (a * 255).toInt()
        cv.drawText("JOURNEY", cx, H * 0.25f, textPaint)
        cv.drawText("OF LIGHT", cx, H * 0.37f, textPaint)
        textPaint.typeface = italic
        textPaint.letterSpacing = 0.04f
        textPaint.textSize = H * 0.04f
        textPaint.color = 0xFFD9CCFF.toInt()
        textPaint.alpha = (a * 220).toInt()
        cv.drawText("A quiet journey through the dark", cx, H * 0.45f, textPaint)

        val bw = H * 0.62f
        val bh = H * 0.11f
        val y1 = if (unlocked > 0) H * 0.58f else H * 0.62f
        btn1.set(cx - bw / 2, y1 - bh / 2, cx + bw / 2, y1 + bh / 2)
        val pulse = 0.5f + 0.5f * sin(t * 2.5f)
        pill(cv, btn1, if (unlocked > 0) "Continue  -  Chapter ${unlocked + 1}" else "Begin the Journey", a * (0.75f + 0.25f * pulse))
        if (unlocked > 0) {
            val y2 = H * 0.74f
            btn2.set(cx - bw / 2, y2 - bh / 2, cx + bw / 2, y2 + bh / 2)
            pill(cv, btn2, "New Journey", a * 0.6f)
        } else btn2.setEmpty()

        textPaint.typeface = serif
        textPaint.letterSpacing = 0.03f
        textPaint.textSize = H * 0.03f
        textPaint.color = Col.PALE
        textPaint.alpha = (a * 130).toInt()
        cv.drawText("Hold the arrows to move  -  tap the right side to jump", cx, H * 0.92f, textPaint)
    }

    private fun pill(cv: Canvas, r: RectF, label: String, a: Float) {
        setFill(Col.PALE, 0.08f * a)
        cv.drawRoundRect(r, r.height() / 2, r.height() / 2, fill)
        setStroke(Col.GOLD, 0.8f * a, 3f)
        cv.drawRoundRect(r, r.height() / 2, r.height() / 2, stroke)
        textPaint.typeface = serif
        textPaint.letterSpacing = 0.06f
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.textSize = H * 0.042f
        textPaint.color = Col.PALE
        textPaint.alpha = (a * 255).toInt().coerceIn(0, 255)
        cv.drawText(label, r.centerX(), r.centerY() + textPaint.textSize * 0.35f, textPaint)
    }

    fun drawComplete(cv: Canvas, t: Float, last: Boolean) {
        val a = (t / 0.6f).coerceIn(0f, 1f)
        setFill(0xFF05020B.toInt(), 0.62f * a)
        cv.drawRect(0f, 0f, W, H, fill)
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.typeface = serifBold
        textPaint.letterSpacing = 0.06f
        textPaint.textSize = H * 0.09f
        textPaint.color = Col.PALE
        textPaint.alpha = (a * 255).toInt()
        cv.drawText("Chapter Complete", W / 2f, H * 0.3f, textPaint)
        textPaint.typeface = italic
        textPaint.letterSpacing = 0.03f
        textPaint.textSize = H * 0.045f
        textPaint.color = 0xFFD9CCFF.toInt()
        textPaint.alpha = (a * 230).toInt()
        cv.drawText(g.lv.name, W / 2f, H * 0.38f, textPaint)
        textPaint.typeface = serif
        textPaint.textSize = H * 0.05f
        textPaint.color = Col.GOLD
        textPaint.alpha = (a * 255).toInt()
        cv.drawText("Light gathered   ${g.orbs} / ${g.lv.totalOrbs}", W / 2f, H * 0.52f, textPaint)
        textPaint.color = Col.CYAN
        textPaint.alpha = (a * 255).toInt()
        cv.drawText("Secrets found   ${g.stars} / ${g.lv.totalStars}", W / 2f, H * 0.6f, textPaint)
        if (t > 0.9f) {
            textPaint.color = Col.PALE
            textPaint.textSize = H * 0.038f
            textPaint.alpha = (140 + 100 * sin(t * 3f)).toInt().coerceIn(0, 255)
            cv.drawText("Tap to continue", W / 2f, H * 0.8f, textPaint)
        }
        if (last) { /* the ending screen follows */ }
    }

    fun drawEnding(cv: Canvas, t: Float) {
        val a = (t / 1.5f).coerceIn(0f, 1f)
        setFill(0xFF05020B.toInt(), 0.82f * a)
        cv.drawRect(0f, 0f, W, H, fill)
        glow(cv, goldGlow, W / 2f, H * 0.5f, H * 0.7f, 0.25f * a)
        val lines = listOf(
            "The light was never lost." to 0.095f,
            "It was only waiting to be carried." to 0.065f,
            "Thank you for walking with it." to 0.065f
        )
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.typeface = italic
        textPaint.letterSpacing = 0.03f
        for ((i, ln) in lines.withIndex()) {
            val la = ((t - 1f - i * 2.4f) / 1.4f).coerceIn(0f, 1f)
            textPaint.textSize = H * ln.second * 0.65f
            textPaint.color = Col.PALE
            textPaint.alpha = (la * 255).toInt()
            cv.drawText(ln.first, W / 2f, H * (0.34f + i * 0.13f), textPaint)
        }
        val sa = ((t - 8.5f) / 1.2f).coerceIn(0f, 1f)
        if (sa > 0f) {
            textPaint.typeface = serif
            textPaint.textSize = H * 0.04f
            textPaint.color = Col.GOLD
            textPaint.alpha = (sa * 230).toInt()
            cv.drawText("Light ${g.orbs} / ${g.lv.totalOrbs}   -   Secrets ${g.stars} / ${g.lv.totalStars}", W / 2f, H * 0.78f, textPaint)
        }
        if (t > 2.5f) {
            textPaint.textSize = H * 0.032f
            textPaint.color = Col.PALE
            textPaint.alpha = (110 + 90 * sin(t * 3f)).toInt().coerceIn(0, 255)
            cv.drawText("Tap to return", W / 2f, H * 0.9f, textPaint)
        }
    }

    fun drawFade(cv: Canvas, a: Float) {
        if (a <= 0.01f) return
        setFill(0xFF000000.toInt(), a)
        cv.drawRect(0f, 0f, W, H, fill)
    }
}
